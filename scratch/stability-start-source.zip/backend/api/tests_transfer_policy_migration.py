"""Exercise authenticated policy requests across the actual schema prerequisite."""
import os
from unittest.mock import Mock, patch

from django.contrib.auth.models import User
from django.db import DatabaseError, connection
from django.db.migrations.executor import MigrationExecutor
from django.test import TransactionTestCase
from rest_framework.test import APIClient

from api.services.transfer_policy_service import VALID_STAGES


class TransferPolicyMigrationRuntimeTests(TransactionTestCase):
    def test_missing_policy_table_is_fixed_by_existing_migration(self):
        executor = MigrationExecutor(connection)
        latest = executor.loader.graph.leaf_nodes()
        self.addCleanup(lambda: MigrationExecutor(connection).migrate(latest))
        executor.migrate([("api", "0058_deliverydraft_cost_center_1_and_more")])
        self.assertNotIn("api_transferpolicyrevision", connection.introspection.table_names())

        admin = User.objects.create_superuser("schema-admin", password="test-only")
        client = APIClient(raise_request_exception=False)
        client.force_login(admin)
        sap = Mock()
        with patch.dict(os.environ, {"TRANSFER_INTERMEDIATE_WAREHOUSES": "INT", "TRANSFER_FRIDGE_WAREHOUSES": "COLD"}), \
                patch("api.transfer_policy_views.SAPServiceLayer", return_value=sap), \
                patch("requests.sessions.Session.request", side_effect=AssertionError("No live SAP requests")):
            paths = ("/api/transfer/policies/", "/api/transfer/policies/effective/")
            for path in paths:
                response = client.get(path)
                self.assertEqual(response.status_code, 500)
                self.assertIsInstance(response.exc_info[1], DatabaseError)
                self.assertIn("api_transferpolicyrevision", str(response.exc_info[1]))

            executor = MigrationExecutor(connection)
            plan = executor.migration_plan([("api", "0059_transfer_policy_revisions")])
            self.assertEqual([(migration.name, backwards) for migration, backwards in plan],
                             [("0059_transfer_policy_revisions", False)])
            executor.migrate([("api", "0059_transfer_policy_revisions")])

            listing = client.get(paths[0])
            effective = client.get(paths[1])
            self.assertEqual(listing.status_code, 200)
            self.assertEqual(listing.data["revisions"], [])
            self.assertEqual(effective.status_code, 200)
            self.assertEqual(effective.data["company_scope"], listing.data["company_scope"])
            self.assertEqual(set(effective.data["stages"]), set(VALID_STAGES))
            self.assertEqual(effective.data["policy_source"], "legacy_deployment")
            for stage in VALID_STAGES:
                defaults = effective.data["administration"][stage]["draft_defaults"]
                self.assertEqual(defaults["route_pairs"], [])
                self.assertEqual(defaults["allowed_destination_bins"], {})
            sap.assert_not_called()
            self.assertEqual(sap.mock_calls, [])
