// Isolated component tests. No browser interception, operational API, or SAP calls.
import assert from 'node:assert/strict';
import React from 'react';
import { renderToString } from 'react-dom/server';
import { createServer } from 'vite';
import { fileURLToPath } from 'node:url';
import { MemoryRouter } from 'react-router-dom';

const root = fileURLToPath(new URL('../', import.meta.url));
const fixture = globalThis.__transferReviewTest = {};
const server = await createServer({ root, server: { middlewareMode: true }, plugins: [{
  name: 'transfer-review-unit-fixtures', enforce: 'pre',
  resolveId(id) { if (id.startsWith('virtual:review-')) return '\0' + id; },
  load(id) {
    if (id === '\0virtual:review-hooks') return `
      export function useState(initial) {
        const f=globalThis.__transferReviewTest, index=f.index++;
        if (!(index in f.states)) f.states[index]=typeof initial==='function'?initial():initial;
        return [f.states[index], value=>{f.states[index]=typeof value==='function'?value(f.states[index]):value;}];
      }
      export function useEffect(callback) { globalThis.__transferReviewTest.effects.push(callback); }
    `;
    if (id === '\0virtual:review-auth') return `export const useAuth=()=>({user:{is_superuser:true}});`;
    if (id === '\0virtual:review-i18n') return `export const useI18n=()=>({lang:'en',t:(key)=>key});`;
  },
  transform(code, id) {
    if (id.endsWith('/contexts/AuthContext.jsx')) return `export const useAuth=()=>({user:{is_superuser:true}});`;
    if (id.endsWith('/contexts/I18nContext.jsx')) return `export const useI18n=()=>({lang:'en',t:(key)=>key});`;
    if (id.endsWith('/services/api.js')) return `export default {get: (...args)=>globalThis.__transferReviewTest.get(...args)};`;
    if (!id.endsWith('/pages/TransferReviewPage.jsx')) return;
    if (fixture.beforeFix) code = code.replace("import { canManageTransfer } from '../utils/roles';", '');
    return code.replace('useRef, useState', 'useRef')
      .replace('useCallback, useEffect,', 'useCallback,')
      .replace("'../contexts/AuthContext'", "'virtual:review-auth'")
      .replace("'../contexts/I18nContext'", "'virtual:review-i18n'")
      + "\nimport {useState,useEffect} from 'virtual:review-hooks';";
  },
}] });

try {
  fixture.beforeFix = true;
  const { default: BrokenPage } = await server.ssrLoadModule('/src/pages/TransferReviewPage.jsx');
  assert.throws(() => renderToString(React.createElement(BrokenPage)), /canManageTransfer is not defined/);
  fixture.beforeFix = false;
  server.moduleGraph.invalidateAll();
  const { default: Page } = await server.ssrLoadModule('/src/pages/TransferReviewPage.jsx');
  const {default:Operations}=await server.ssrLoadModule('/src/pages/TransferReviewOperationsPage.jsx');
  const landing=renderToString(React.createElement(MemoryRouter,null,React.createElement(Operations)));
  assert.ok(landing.includes('href="/transfer-review/internal"'));assert.ok(landing.includes('href="/transfer-review/shipping"'));
  assert.ok(landing.includes('physicalTransfer.internalReview'));assert.ok(!landing.includes('tr-workflow-table'));
  const render = () => { fixture.index = 0; fixture.effects = []; return renderToString(React.createElement(Page)); };
  let checks = 0;
  async function scenario(response, { error = null, reserved = [] } = {}) {
    fixture.states = []; fixture.calls = [];
    fixture.get = async (url, options) => {
      fixture.calls.push([url, options]);
      if (url.includes('/bin-locations/')) return { data: { data: {
        warehouse_code: decodeURIComponent(url.split('/')[2]), requires_bin: true,
        locations: [{ code: 'VALID-DESTINATION-BIN', name: 'Valid destination', absEntry: 42 }],
      } } };
      if (url.includes('reserved-outbound')) return { data: { data: { positions: reserved } } };
      if (error) throw { response: { data: { error } } };
      return { data: response };
    };
    assert.match(render(), /transferReview.title/); // Reproduces the original first-render ReferenceError.
    const effects = [...fixture.effects];
    effects.forEach(effect => effect());
    await new Promise(resolve => setImmediate(resolve));
    const html = render();
    assert.equal(fixture.calls.length, 2);
    assert.equal(fixture.calls[0][1].params.refresh_sources, 'false');
    checks++;
    return html;
  }
  const pending = { id: 1, status: 'PENDING', transfer_stage: 'STAGE_1_TO_INTERMEDIATE',
    from_warehouse: '20203', to_warehouse: '90214', quantity: 6000,
    lines: [{ batch_number: 'PALLET-ONE', item_code: 'ITEM-ONE' }] };
  for (const response of [null, {}, { data: { transfers: null } }, { data: { transfers: [] } }]) {
    assert.match(await scenario(response), /transferReview.empty/);
  }
  assert.match(await scenario({ data: { transfers: [pending] } }), /PALLET-ONE/);
  const stage4={...pending,id:40,transfer_stage:'STAGE_4_TO_DESTINATION',from_warehouse:'SOURCE-4',to_warehouse:'DEST-4',
    lines:[{batch_number:'INTERNAL-PALLET'}],sap_doc_num:444};
  const separated=await scenario({data:{transfers:[stage4,pending]}});
  const internalSection=separated.slice(separated.indexOf('aria-labelledby="internal-transfers-title"'),separated.indexOf('aria-labelledby="sap-review-title"'));
  assert.ok(internalSection.includes('INTERNAL-PALLET'));assert.ok(internalSection.includes('SOURCE-4'));assert.ok(internalSection.includes('DEST-4'));
  assert.ok(!internalSection.includes('PALLET-ONE'));assert.ok(!internalSection.includes('physicalTransfer.container'));
  assert.ok(!separated.includes('physicalTransfer.history'));assert.ok(!separated.includes('physicalTransfer.shippingHall'));
  assert.ok(!separated.includes('shipping-loading-title')); // Shipping history has its own navigation destination.
  const stage2 = { ...pending, id: 2, status: 'POSTED', transfer_stage: 'STAGE_2_TO_FRIDGE',
    from_warehouse: '90214', to_warehouse: '20201', to_bin: 'ACTUAL-SECOND-BIN',
    pallet_position_code: 'ACTUAL-USER-POSITION', sap_doc_entry: 123, sap_doc_num: 456,
    raw_payload_json: { policy: { allowed_destination_bins: {} } } };
  let html = await scenario({ data: { transfers: [stage2] } });
  for (const value of ['transferReview.stage2', 'ACTUAL-USER-POSITION', 'ACTUAL-SECOND-BIN', '123', '456']) assert.ok(html.includes(value));
  html = await scenario({ data: { transfers: [{ ...stage2, id: 3, transfer_stage: 'STAGE_3_FROM_FRIDGE',
    from_warehouse: '20201', to_warehouse: 'DESTINATION', source_pallet_position_code: 'ACTUAL-SOURCE-POSITION',
    pallet_position_code: null, to_bin: null }] } });
  assert.match(html, /transferReview.stage3/); assert.match(html, /ACTUAL-SOURCE-POSITION/);
  html = await scenario({ data: { transfers: [{ id: 4, status: 'POSTED', lines: null, created_at: null,
    created_by: null, sap_doc_num: null, position_reconciliation: { status: null, last_attempt_at: null } }] } });
  assert.match(html, /transferReview.title/);
  html = await scenario(null, { error: 'REAL API FAILURE' });
  assert.match(html, /REAL API FAILURE/); assert.match(html, /common.retry/);
  assert.ok(!html.includes('transferReview.empty'));
  html = await scenario({ data: { transfers: {} } });
  assert.match(html, /transferReview.loadFailed/); assert.ok(!html.includes('transferReview.empty'));
  html = await scenario({ data: { transfers: [null] } });
  assert.match(html, /transferReview.loadFailed/);
  html = await scenario({ data: { transfers: [] } }, { reserved: {} });
  assert.match(html, /transferReview.reservedOutboundLoadFailed/);
  html = await scenario({ data: { transfers: [{ ...stage2, id: 5, status: 'FAILED',
    transfer_stage: 'STAGE_3_FROM_FRIDGE', to_bin: '', error_message: 'Original SAP rejection' }] } });
  fixture.effects[0](); // Resolve warehouse requirements after records load.
  await new Promise(resolve => setImmediate(resolve));
  html = render();
  assert.match(html, /transfer.destinationSapBin/);
  assert.match(html, /Original SAP rejection/);
  assert.match(html, /class="app-button app-button--success tr-post-btn" disabled/);
  console.log(`PASS: ${checks} Transfer Review component scenarios; no operational/SAP calls.`);
} finally {
  await server.close(); delete globalThis.__transferReviewTest;
}
