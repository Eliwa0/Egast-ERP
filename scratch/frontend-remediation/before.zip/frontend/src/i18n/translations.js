import { physicalTransferTranslations } from './physicalTransferTranslations.js';
import { searchTranslations } from './searchTranslations.js';
export const translations = {

  en: {
    searchControl: searchTranslations.en,
    physicalTransfer: physicalTransferTranslations.en,

    common: {

      continue: 'Continue',

      pleaseWait: 'Please wait...',

      errorLoadingData: 'Failed to load data',

      previous: 'Previous',

      remove: 'Remove',

      requiredFields: 'Please fill all required fields',

      saveChanges: 'Save changes',

      status: 'Status',

      typeDelete: 'Type DELETE to confirm',

      save: 'Save',

      cancel: 'Cancel',

      delete: 'Delete',

      deleteDraft: 'Delete Draft',

      edit: 'Edit',

      duplicate: 'Duplicate',

      refresh: 'Refresh',

      review: 'Review',

      rules: 'Rules',

      users: 'Users',

      signOut: 'Sign out',

      admin: 'Admin',

      pending: 'Pending',

      posted: 'Posted',

      failed: 'Failed',

      rejected: 'Rejected',

      ready: 'Ready',

      total: 'Total',

      search: 'Search',

      filter: 'Filter',

      clear: 'Clear',

      done: 'Done',

      back: 'Back',

      next: 'Next',

      loading: 'Loading…',

      saving: 'Saving…',

      submitting: 'Submitting…',

      posting: 'Posting…',

      postingToSap: 'Posting to SAP…',

      creatingInSap: 'Creating in SAP…',

      preparingPrint: 'Preparing document for printing…',

      validating: 'Validating…',

      deleting: 'Deleting…',

      refreshing: 'Refreshing…',

      reconciling: 'Reconciling…',

      systemBusy: 'System is working — please wait…',

      retry: 'Retry',

      accessDenied: 'Access denied. Admin only.',

      noData: 'No data found.',

      confirm: 'Confirm',

      close: 'Close',

      working: 'Working...',

      dismissNotification: 'Dismiss notification',

      selectOption: 'Select option',

      typeToSearch: 'Type to search…',

      noOptions: 'No options found',

      success: 'Success',

      error: 'Error',

      warning: 'Warning',

      info: 'Info',

      open: 'Open →',

      optional: 'Optional',

      actions: 'Actions',

      view: 'View',

    },

    nav: {

      quality: 'Quality Inspection',

      qualityReceiving: 'Receiving Inspection',

      sapWorkflow: 'SAP workflow',

      home: 'Home',

      production: 'Production',

      receiptWizard: 'Receipt wizard',
      issueWizard: 'Issue wizard',

      createUser: 'Create user',

      usersPage: 'Users',
      activityLog: 'Activity Log',

      attributeRules: 'Attribute rules',

      receiptReview: 'Receipt Review',
      issueReview: 'Issue Review',
      productionReview: 'Production Review',

      transfer: 'Transfer',

      productionRules: 'Production Rules',

      transferRules: 'Transfer Rules',

      qualityRules: 'Quality Rules',

      qualityInspectionStages: 'Inspection Stages',

      qualityCategories: 'Quality Categories',

      qualityCriteria: 'Quality Criteria',

      qualityCriteriaMapping: 'Quality Criteria Mapping',

      transferReview: 'Transfer Review',

      qualityReview: 'Quality Review',

      scale: 'Weighbridge / Scale',

      scaleReview: 'Scale Review',

      scaleWeighing: 'Weighing Station',

      scaleDrafts: 'Weighing Drafts',

      scaleDevices: 'Scale Devices',

      scaleItemElements: 'Item Elements',

      scaleReceipt: 'Receipt',

      scaleEntryExitPermits: 'Entry & Exit Permits',

      scaleEntryPermit: 'Entry Permit',

      scaleExitPermit: 'Exit Permit',

      grpo: 'Receiving',

      grpoReview: 'Receiving Review',

      shippingReceiving: 'Shipping & Receiving',

      customizationDelivery: 'Customization & Delivery',

      customization: 'Customization',

      delivery: 'Delivery',

      salesQuotations: 'Sales Quotations',
      salesQuotationsReview: 'Sales Quotations Review',
      salesReview: 'Sales Review',
      salesOrdersReview: 'Sales Orders Review',
      deliveryReview: 'Delivery Review',

      createSalesQuotation: 'New Sales Quotation',

      salesOrders: 'Sales Orders',

      deliveries: 'Deliveries',
      createDelivery: 'New Delivery',

      shippingDelivery: 'Shipping & Delivery',

      purchaseQuotations: 'Shipping Documents',

      purchaseQuotationsReview: 'Shipping Review',

      page: 'Page',

    },



    toolbar: {

      review: '📋 Review',

      rules: '⚙️ Rules',

      users: '👥 Users',

      signOut: 'Sign out',

      switchToDark: 'Switch to dark mode',

      switchToLight: 'Switch to light mode',

      switchToArabic: 'Switch to Arabic',

      switchToEnglish: 'Switch to English',

    },

    login: {

      title: 'Sign in',

      subtitle: 'SAP Workflow · Production',

      username: 'Username',

      password: 'Password',

      signIn: 'Sign in',

      signingIn: 'Signing in…',

      loginFailed: 'Login failed',

    },

    home: {

      production: 'Production',

      productionDesc: 'Manage production receipts and related order operations.',

      transfer: 'Transfer',

      transferDesc: 'Manage warehouse transfers using batch scanning.',

      quality: 'Quality Inspection',

      qualityDesc: 'Perform raw material and finished product quality checks.',

      grpo: 'Receiving',

      grpoDesc: 'Manage incoming goods and receiving operations.',

      shippingReceivingTitle: 'Shipping & Receiving',

      shippingReceivingDesc: 'Manage shipping and receiving operations, vendor goods receipts, and deliveries.',

      customizationDeliveryTitle: 'Customization & Delivery',

      customizationDeliveryDesc: 'Review customer sales quotations and sales orders. Read-only.',

      description: 'Choose the module available for your role. The current workflow and permission checks stay unchanged.',

      open: 'Open →',

    },

    rulesHub: {

      productionTitle: 'Production Rules',

      productionDesc: 'Manage production order, user, and warehouse receipt rules.',

      transferTitle: 'Transfer Rules',

      transferDesc: 'Control transfer From and To warehouse access per user.',

    },

    transfer: {

      headerKicker: 'SAP Inventory Transfer',
      destinationSapBin: 'Destination SAP Bin',
      destinationSapLoadFailed: 'Unable to verify destination SAP bin requirements. Select the warehouse again to retry.',
      destinationSapBinsUnavailable: 'This warehouse requires an SAP bin location, but no valid bins are available.',

      title: 'Transfer',

      stepStage: 'Stage',

      stepSource: 'Source',

      stepBatches: 'Batches',

      stepDestination: 'Destination',

      stepReview: 'Review',

      stepDone: 'Done',

      stage1Badge: 'Stage 1',

      stage2Badge: 'Stage 2',

      stage3Badge: 'Stage 3',

      stage4Badge: 'Stage 4',

      stage5Badge: 'Stage 5',

      stage1Title: 'Station to Intermediate',

      stage2Title: 'Intermediate to Fridge',

      stage3Title: 'From Fridge / Outbound',

      stage4Title: 'Warehouse to Warehouse',

      stage5Title: 'Warehouse to Shipping Container',

      stage1Desc: 'From production / station warehouse to intermediate warehouse',

      stage2Desc: 'From intermediate warehouse to fridge / cold store',

      stage3Desc: 'From fridge / cold store to destination warehouse',

      stage4Desc: 'Transfer between user-selected warehouses allowed by Transfer Rules',

      stage5Desc: 'From selected warehouse to shipping container (local loading)',

      containerNotSapWarehouseNotice: 'Shipping containers record local physical custody only and are not SAP warehouses.',

      intermediateFixedSource: 'Intermediate Warehouse',

      fromStation: 'From Station / Production Warehouse',

      toIntermediate: 'To Intermediate Warehouse',

      fromIntermediate: 'From Intermediate Warehouse',

      toFridge: 'To Fridge Warehouse',

      fromFridge: 'From Fridge Warehouse',

      toDestination: 'To Destination Warehouse',

      fromIntermediateWh: 'From Intermediate Warehouse',

      toShippingHall: 'To Shipping Hall',

      fromShippingHall: 'From Shipping Hall',

      toContainer: 'To Shipping Container',

      containerNumber: 'Container Number',

      enterContainerNumber: 'Enter container number',

      localPhysicalRecorded: 'Local physical movement recorded successfully.',

      localLoadingRecorded: 'Local container loading recorded successfully.',

      confirmArrival: 'Confirm Arrival',

      confirmLoad: 'Confirm Load',

      inShippingHall: 'In Shipping Hall',

      loadedToContainer: 'Loaded to Container',

      alreadyInShippingHall: 'Batch has already arrived at Shipping Hall.',

      alreadyLoadedToContainer: 'Batch is already loaded into a container.',

      selectStageTitle: 'Select Transfer Stage',

      selectSourceTitle: 'Select Source',

      scanBatchesTitle: 'Scan Batches',

      selectDestinationTitle: 'Select Destination',

      reviewSubmitTitle: 'Review & Submit',

      completeTitle: 'Transfer Complete',

      chooseTransferFlow: 'Choose transfer flow',

      selectSourceWarehouse: 'Select source warehouse',

      scanBatchNumbers: 'Scan batch numbers',

      chooseMoveTarget: 'Choose where the inventory will be moved to',

      selectDestinationWarehouse: 'Select destination warehouse',

      confirmTransferDetails: 'Confirm transfer details',

      noWarehouseAccess: 'No Transfer warehouse route is configured. Contact admin.',

      fixedRouteNotConfigured: 'Your transfer route is not configured. Contact admin.',

      fromWarehouse: 'From Warehouse',

      noWarehousesAvailable: 'No warehouses available',

      fromBin: 'From Bin',

      selectSourceBin: 'Select source bin',

      scanPlaceholder: 'Scan or type batch number, then press Enter',

      lookingUp: 'Looking up...',

      addBatch: 'Add Batch',

      colBatchNumber: 'Batch Number',

      colItemCode: 'Item Code',

      colItemName: 'Item Name',

      colSourceStatus: 'Source Status',

      colAvailable: 'Available',

      colUom: 'UOM',

      colExpiry: 'Expiry',

      colQtyToTransfer: 'Qty to Transfer',

      removeLine: 'Remove line',

      removeBatch: (batch) => `Remove batch ${batch}`,

      localReceiptWarning: 'Waiting for receipt approval. Local pending receipt batches can be submitted as transfer requests, but they cannot be posted to SAP until the source receipt is posted.',

      noBatches: 'No batches added yet. Scan a batch number above.',

      destinationType: 'Destination Type',

      option1: 'Option 1',

      option2: 'Option 2',

      intermediateWarehouse: 'Intermediate Warehouse',

      fridgeStockingWarehouse: 'Fridge / Stocking Warehouse',

      intermediateDesc: 'Transfer to another transit / intermediate warehouse. No bin required.',

      fridgeDesc: 'Transfer to a bin-managed cold store or stocking warehouse. Bin required.',

      toFridgeStocking: 'To Fridge / Stocking Warehouse',

      toWarehouse: 'To Warehouse',

      toBin: 'To Bin',

      selectDestinationBin: 'Select destination bin',

      visualMap: 'Visual Storage Map',

      dropdownView: 'Dropdown List',

      mapView: 'Visual Map',

      storageMapTitle: 'Cold Storage Visual Map',

      selectedLocation: 'Selected Location',

      noLocationSelected: 'No location selected. Click a storage bin on the map below.',

      absEntry: 'SAP AbsEntry',

      sublevels: 'Hierarchy',

      clearSelection: 'Clear Selection',

      refreshMap: 'Refresh Map',

      allAreas: 'All Areas',

      directBin: 'Direct / Bulk Storage Bin',

      corridorBin: 'Corridor / Aisle Bin',

      systemBinNotice: 'System bin — non-storable',

      binsCount: (n) => `${n} bins`,

      sectionsCount: (n) => `${n} sections`,

      loadingHierarchy: 'Loading storage hierarchy from SAP...',

      errorLoadingHierarchy: 'Failed to load storage hierarchy.',

      retry: 'Retry',

      emptyHierarchy: 'No storage hierarchy found for this warehouse.',

      rack: 'Rack',

      chamber: 'Chamber / Section',

      level: 'Level',

      generalBin: 'General / Bulk Bin',
      palletPositions: 'Pallet Positions',
      palletPositionsInBin: (n) => `${n} Pallet Positions`,
      position: 'Position',
      capacity: 'Capacity',
      physicalCapacity: 'Physical Capacity',
      unconfiguredCapacity: 'Unconfigured Depth',
      unconfigured: 'Unconfigured',
      sapBinOnly: 'SAP Bin',
      occupancy: 'Occupancy',
      statusAvailable: 'Available',
      statusReserved: 'Reserved',
      statusOccupied: 'Occupied',
      statusReservedOutbound: 'Reserved Outbound',
      statusMaintenance: 'Maintenance',
      statusSelected: 'Selected',
      selectPalletPosition: 'Select Pallet Position',
      selectedPalletPosition: 'Selected Pallet Position',
      sourcePalletPosition: 'Source Pallet Position',
      noPositionSelected: 'Click an available pallet position below',
      reservePosition: 'Reserve Position',
      releaseReservation: 'Release Reservation',
      reservingPosition: 'Reserving...',
      releasingPosition: 'Releasing...',
      positionReservedSuccess: 'Pallet position reserved successfully',
      positionConflictError: 'This pallet position is already reserved or occupied. Please pick another position.',
      positionConflictOutbound: 'The selected pallet position is no longer available for this transfer.',
      loadingLayout: 'Loading physical layout and positions...',
      backToRacks: '← Back to Racks',
      allocatable: 'Allocatable',
      stagingOnly: 'Staging Only',
      nonAllocatable: 'Non-Allocatable',
      binStagingOnlyNotice: 'This location is for transit/staging only and cannot be allocated for storage.',
      binNonAllocatableNotice: 'This location is non-allocatable.',
      binUnconfiguredNotice: 'This location is unconfigured and requires capacity configuration before allocation.',
      physicalPosition: 'Physical Position',
      pleaseSelectPalletPosition: 'Please select a physical pallet position.',
      pleaseSelectSourcePalletPosition: 'Please select a physical pallet position from the cold storage map.',
      batchNumber: 'Batch Number',
      transferRef: 'Transfer Ref',
      sequentialPalletCount: 'Sequential Pallet Placement (Pallet Count):',
      previewSequential: 'Preview Placement',
      confirmSequential: 'Confirm Sequential Placement',
      required: 'Required',
      available: 'Available',
      shortage: 'Shortage',
      sequenceOrder: 'Sequential Order',

      transferStage: 'Transfer Stage',

      reviewId: 'Review ID',

      docEntry: 'Reference Number',

      docNum: 'DocNum',

      movementReference: 'Movement Reference',

      from: 'From',

      to: 'To',

      stage: 'Stage',

      qtyTransferred: 'Qty Transferred',

      createInventoryTransfer: 'Create Inventory Transfer',

      submitForReview: 'Submit for Review',

      postingToSap: 'Posting to SAP...',

      submitting: 'Submitting...',

      submittedForReview: 'Transfer submitted for admin review.',

      mockCreated: 'Mock SAP Inventory Transfer created.',

      postedSuccessfully: 'SAP Inventory Transfer posted successfully.',

      newTransfer: 'New Transfer',

      back: 'Back',

      next: 'Next',

      status: {

        pendingTransferChain: 'Pending Transfer Chain',

        sapAvailable: 'SAP available',

        sapPosted: 'Registered',

        localPendingReceipt: 'Local pending receipt',

        localPostedReceipt: 'Waiting for SAP availability',

        notFound: 'Not found',

        waitingApproval: 'Waiting for receipt approval',

      },

      errors: {

        selectFromWarehouse: 'Select From Warehouse before scanning.',

        enterBatch: 'Enter a batch number to scan.',

        duplicateBatch: (batch) => `Batch "${batch}" is already in the transfer lines.`,

        notFound: (batch, warehouse) => `Not found: Batch "${batch}" was not found in SAP or local receipt batches for warehouse ${warehouse}.`,

        lookupFailed: (batch) => `Batch "${batch}": lookup failed.`,

        transferFailed: 'Transfer failed. Please try again.',

      },

    },

    transferReview: {

      title: 'Transfer Review',

      adminReview: 'Admin Review',

      myTransfers: 'My Transfers',

      refresh: 'Refresh',

      refreshing: 'Refreshing...',

      postSelected: (n) => `Post Selected (${n})`,

      pendingTransfers: 'Pending transfers',

      failedTransfers: 'Failed transfers',

      totalTransfers: 'Total transfers',

      selected: 'Selected',

      status: 'Status',

      pending: 'Pending',

      posted: 'Posted',

      failed: 'Failed',

      allStatuses: 'All statuses',

      search: 'Search',

      searchPlaceholder: 'Batch, item, warehouse, user',

      type: 'Type',

      typeInternal: 'Internal',

      typeShipping: 'Shipping / Delivery',

      toOrContainer: 'To / Container',

      container: 'Container',

      itemAndQty: 'Item / Qty',

      reference: 'Reference',

      allStages: 'All Stages',

      stageFilter: 'Stage',

      loadedToContainer: 'Loaded to Container',

      stage1Short: 'Stage 1',

      stage2Short: 'Stage 2',

      stage3Short: 'Stage 3',

      stage4Short: 'Stage 4',

      stage5Short: 'Stage 5',

      fromFilter: 'From',

      toFilter: 'To',

      allFrom: 'All From',

      allTo: 'All To',

      clear: 'Clear',

      loading: 'Loading transfer requests...',

      empty: 'No transfers to review.',

      loadFailed: 'Failed to load transfer requests.',

      saveFailed: 'Save failed.',

      postFailed: 'Failed to post transfer.',

      deleteFailed: 'Failed to delete transfer.',

      deleteConfirm: (label) => `Delete ${label}?\n\nThis will remove this transfer request. Other transfer requests will not be affected.`,

      deleting: 'Deleting...',

      selectAllPostable: 'Select all postable transfer rows',

      source: 'Source',

      stage: 'Stage',

      fromWh: 'From WH',

      fromBin: 'From Bin',

      toWh: 'To WH',

      toBin: 'To Bin',

      batch: 'Batch',

      itemCode: 'Item Code',

      itemName: 'Item Name',

      qty: 'Qty',

      by: 'By',

      created: 'Created',

      sapDocEntry: 'Reference Number',

      sapDocNum: 'SAP DocNum',

      errorReason: 'Error Reason',

      actions: 'Actions',

      reservedOutboundTitle: 'Reserved outbound positions',

      reservedOutboundDescription: 'Physical positions awaiting SAP success, retry, or transfer cancellation. Oldest reservations appear first.',

      reservedOutboundLoading: 'Loading reserved outbound positions...',

      reservedOutboundEmpty: 'No outbound-reserved positions.',

      reservedOutboundLoadFailed: 'Failed to load outbound-reserved positions.',

      physicalPosition: 'Physical Position',

      reservationReference: 'Reservation Reference',

      reservedBy: 'Reserved By',

      reservedAt: 'Reserved At',

      reconciliationRequired: 'Position reconciliation required',

      reconciliationCompleted: 'Positions reconciled',

      retryReconciliation: 'Retry positions',

      reconciling: 'Retrying...',

      reconciliationFailed: 'Position reconciliation failed.',

      sourcePositionState: 'Source position',

      destinationPositionState: 'Destination position',

      sourceSapBin: 'Source SAP Bin',

      save: 'Save',

      saving: 'Saving...',

      saved: 'Saved',

      post: 'Post',

      posting: 'Posting...',

      readOnly: 'Read only',

      stage1: 'Stage 1 - Station to Intermediate',

      stage2: 'Stage 2 - Intermediate to Fridge',

      stage3: 'Stage 3 - From Fridge / Outbound',
      stage4: 'Stage 4 - Warehouse to Warehouse',
      stage5: 'Stage 5 - Warehouse to Shipping Container',

      sourcePosition: 'Source Pallet Position',

    },

    transferRules: {

      title: 'Transfer Rules',

      admin: 'Admin',

      back: 'Back',

      users: 'Users',

      user: 'User',

      loadingUsers: 'Loading users...',

      noUsers: 'No users found.',

      rulesCount: (n) => `${n} rule${n !== 1 ? 's' : ''}`,

      allowedStages: 'Allowed transfer stages',

      bothStages: 'Both stages',

      allowedFrom: 'Allowed From Warehouses',

      allowedTo: 'Allowed To Warehouses',

      loadingWarehouses: 'Loading warehouses...',

      noWarehouses: 'No warehouses found.',

      saving: 'Saving...',

      saveAccess: 'Save Transfer Warehouse Access',

      currentRules: 'Current rules',

      warehouse: 'Warehouse',

      direction: 'Direction',

      stage: 'Stage',

      status: 'Status',

      active: 'Active',

      inactive: 'Inactive',

      delete: 'Delete',

      loadFailed: 'Failed to load transfer rules.',

      saved: 'Transfer warehouse access saved.',

      saveFailed: 'Failed to save transfer rules.',

      fixedRouteRequired: 'Select exactly one source warehouse and one destination warehouse for the user route.',
      stage5SourceRequired: 'Select at least one allowed source warehouse for Stage 5.',

      deleted: 'Rule deleted.',

      deleteFailed: 'Failed to delete rule.',

    },

    production: {

      moduleTitle: 'Production',

      title: 'Receipt from production',

      desc: 'Start receiving finished goods from a production order.',

      start: 'Start receipt →',

      issueTitle: 'Issue for Production',

      issueDesc: 'Issue components and raw materials for released production orders.',

      issueStart: 'Start issue →',

      issueReviewTitle: 'Issue Review',

      issueReviewDesc: 'Review, reject, or approve and post pending issues to SAP.',

      issueReviewStart: 'Review issues →',
    },


    issueWizard: {
      title: 'Issue for Production',
      pageTitle: 'Issue for Production',
      pageDesc: 'Prepare and submit a draft issue for production admin review',
      step1: 'Production Order',
      step1Desc: 'Select released order',
      step2: 'Components',
      step2Desc: 'Select items & quantities',
      step3: 'Inventory Allocation',
      step3Desc: 'Batches & bins',
      step4: 'Document Information',
      step4Desc: 'Dates & remarks',
      step5: 'Review & Save',
      step5Desc: 'Submit for review',
      searchOrder: 'Search by order #, product name, or item code...',
      loadingOrders: 'Loading production orders...',
      noOrders: 'No released production orders available.',
      noOrdersFiltered: 'No orders match the current search filter.',
      orderNumber: 'Order #',
      product: 'Product',
      plannedQty: 'Planned Qty',
      completedQty: 'Completed Qty',
      remainingQty: 'Remaining Qty',
      issuedQty: 'Already Issued',
      issueQty: 'Issue Quantity',
      dueDate: 'Due Date',
      postingDate: 'Posting Date',
      documentDate: 'Document Date',
      warehouse: 'Warehouse',
      status: 'Status',
      released: 'Released',
      selectedOrder: 'Selected Production Order',
      loadingOrderDetails: 'Loading component lines from SAP...',
      noComponents: 'This production order has no component lines in SAP.',
      selectComponentsTitle: 'Select Components to Issue',
      selectComponentsDesc: 'Choose the components and enter the issue quantities.',
      selectAll: 'Select All',
      deselectAll: 'Deselect All',
      itemCode: 'Item Code',
      itemName: 'Item Description',
      uom: 'UoM',
      issueType: 'Issue Type',
      invalidQty: 'Quantity must be > 0 and <= remaining',
      atLeastOneComponent: 'Please select at least one component to issue.',
      allocationTitle: 'Inventory Batch & Bin Allocation',
      allocationDesc: 'Allocate batches and bin locations for the selected components.',
      batchNumber: 'Batch Number',
      binLocation: 'Bin Location',
      allocatedQty: 'Allocated Qty',
      addSplit: 'Add Allocation Split',
      removeSplit: 'Remove Split',
      lookupBatch: 'Lookup',
      batchAvailable: 'Available in Batch',
      noBatchRequired: 'Standard item (no batch/bin required)',
      remainingToAllocate: 'Remaining to Allocate',
      allocatedExact: 'Allocations match issue quantity',
      allocationMismatch: 'Allocations do not equal issue quantity',
      availableBatchesTitle: 'Available Batches in SAP',
      loadingBatches: 'Loading available batches from SAP...',
      noBatchesFound: 'No available batches with stock found for this item in warehouse',
      systemBinBadge: 'System Bin',
      storageBinBadge: 'Storage Bin',
      autoAllocateBtn: 'Auto-fill',
      splitAllocationBtn: 'Add Split',
      selectBinTitle: 'Select Storage Bin',
      availableStock: 'Available Stock',
      expiryDate: 'Exp Date',
      mfrDate: 'Mfr Date',
      comments: 'Comments',
      journalMemo: 'Journal Remark',
      reviewTitle: 'Review Issue Draft',
      reviewDesc: 'Verify all details before submitting for Production Admin review.',
      reviewNotice: 'Saving this document submits it for Production Admin review. It will not be sent to SAP until approved.',
      submitForReview: 'Submit for Review',
      submitting: 'Submitting draft...',
      successTitle: 'Draft Submitted for Review!',
      successDesc: 'The issue draft has been saved locally. It is now awaiting review and posting by a Production Admin.',
      pendingReview: 'Pending Review',
      pendingIssueId: 'Draft Issue ID',
      submittedBy: 'Submitted By',
      submissionTime: 'Submission Time',
      totalComponents: 'Total Components',
      totalQuantity: 'Total Quantity',
      issueAnother: 'Issue Another Order',
      backToProduction: 'Back to Production',
      previousBtn: 'Previous',
      nextBtn: 'Next',
      noBins: 'No bins configured',
      selectBin: 'Select Bin Location',
      autoAssignedBin: 'Assigned Storage Bin',
      selectBatchFirst: 'Select or enter a batch number to view its storage bin',
      noBinForBatch: 'No storage bin configured for this batch',
      multipleBinsNotice: 'Select the storage bin to deduct from',
    },

    issueReview: {
      title: 'Issue for Production Review',
      pageTitle: 'Issue for Production Review',
      pageDesc: 'Review submitted drafts, reject, or approve and post to SAP Business One',
      filterStatus: 'Status Filter',
      allStatuses: 'All Statuses',
      pendingReview: 'Pending Review',
      posting: 'Posting in Progress',
      posted: 'Posted',
      failed: 'Failed',
      rejected: 'Rejected',
      searchPlaceholder: 'Search by order #, finished product, or draft ID...',
      noIssues: 'No pending issues found.',
      noIssuesFiltered: 'No issues match the selected filter criteria.',
      loadingIssues: 'Loading issues...',
      errorLoading: 'Failed to load issues.',
      colId: '#',
      colStatus: 'Status',
      colOrderNum: 'Order #',
      colProduct: 'Finished Product',
      colComponents: 'Components',
      colQuantity: 'Issue Qty',
      colCreatedBy: 'Created By',
      colCreatedAt: 'Created Date',
      colActions: 'Actions',
      actionReview: 'Review',
      backToList: 'Back to Issues List',
      backToProduction: 'Return to Production',
      localPendingNotice: 'Local Pending Issue — Not in SAP',
      localPendingDesc: 'This document was prepared by an operator and saved locally. It will NOT affect SAP inventory until approved.',
      postedNotice: 'Posted to SAP Business One',
      postedDesc: 'This Goods Issue has been successfully posted to SAP Business One.',
      postingNotice: 'Posting in progress...',
      postingDesc: 'The transaction is currently being processed and posted to SAP Business One.',
      rejectedNotice: 'Issue Rejected',
      rejectedDesc: 'This issue was rejected by a Production Admin and cannot be posted.',
      failedNotice: 'SAP Posting Failed',
      failedDesc: 'SAP returned an error during document creation. Review the error details below and retry if appropriate.',
      sapDetailsTitle: 'SAP Document Identifiers',
      sapDocNum: 'SAP Doc #',
      sapDocEntry: 'SAP DocEntry',
      postedBy: 'Posted By',
      postedAt: 'Posted At',
      orderInfoTitle: 'Production Order Information',
      issueId: 'Draft Issue ID',
      orderNumber: 'Production Order #',
      orderDocEntry: 'Order DocEntry',
      finishedProduct: 'Target Item',
      orderStatusAtSubmit: 'Order Status at Submission',
      postingDate: 'Posting Date',
      documentDate: 'Document Date',
      createdBy: 'Created By',
      createdAt: 'Created At',
      reviewedBy: 'Reviewed By',
      reviewedAt: 'Reviewed At',
      comments: 'Comments',
      journalMemo: 'Journal Memo',
      componentsTitle: 'Component Lines',
      componentsSubtitle: 'Components to be issued for this production order',
      colLineNum: 'Line #',
      colItemCode: 'Item Code',
      colItemName: 'Description',
      colWarehouse: 'Warehouse',
      colIssueType: 'Issue Type',
      colUom: 'UoM',
      colPlannedQty: 'Planned Qty',
      colIssuedQty: 'Issued at Submit',
      colRemainingQty: 'Remaining at Submit',
      colIssueQty: 'Issue Qty',
      allocationsTitle: 'Warehouse Inventory Allocations',
      allocationsSubtitle: 'Batches and bin locations allocated for each component',
      colBatch: 'Batch #',
      colBin: 'Bin Location',
      colAllocQty: 'Allocated Qty',
      allocMatch: 'Allocations Match',
      allocMismatch: 'Allocation Mismatch',
      standardNoAlloc: 'Standard item — No batch or bin allocation required',
      actionReject: 'Reject',
      actionApprovePost: 'Approve & Post to SAP',
      actionPosting: 'Posting to SAP...',
      actionRetry: 'Retry Approve & Post',
      rejectModalTitle: 'Reject Issue for Production',
      rejectReasonLabel: 'Rejection Reason (Required)',
      rejectReasonPlaceholder: 'Enter the reason for rejecting this issue...',
      rejectConfirmBtn: 'Confirm Rejection',
      rejectCancelBtn: 'Cancel',
      rejectSuccessMsg: 'Issue was rejected successfully.',
      approveModalTitle: 'Approve & Post to SAP Business One',
      approveWarning: 'Are you sure you want to approve this Issue and send it to SAP Business One?',
      approveIrreversibleNotice: 'Once posted, an InventoryGenExits document will be created in SAP Business One. This transaction cannot be edited or rejected after posting.',
      approveOrderRecap: 'Order',
      approveProductRecap: 'Finished Product',
      approveQtyRecap: 'Total Issue Quantity',
      approveComponentsRecap: 'Total Components',
      approveConfirmBtn: 'Confirm & Post to SAP',
      approveCancelBtn: 'Cancel',
      postSuccessMsg: 'Issue for Production was successfully posted to SAP Business One.',
      postFailureTitle: 'Posting Failed',
      postFailureMsg: 'Failed to post issue to SAP Business One.',
      rejectionReasonDisplay: 'Rejection Reason:',
      ambiguousNotice: 'Ambiguous SAP Result — Reconciliation Required',
      ambiguousDesc: 'The request may have reached SAP even though a definitive response was not received. Reconciliation is required before retrying.',
      ambiguousErrorNotice: 'The request may have reached SAP even though a definitive response was not received.',
      actionReconcile: 'Reconcile SAP',
      actionReconciling: 'Reconciling with SAP...',
      reconcileModalTitle: 'Reconcile Issue with SAP Business One',
      reconcileModalDesc: 'The system will inspect SAP Business One to verify whether an InventoryGenExits document was actually created for this issue.',
      reconcilePoint1: 'If found, the local issue will be linked to the SAP document and marked POSTED.',
      reconcilePoint2: 'If not found, the ambiguity will be cleared and the issue can safely be retried.',
      reconcilePoint3: 'If SAP is unreachable, the issue will remain blocked until connection is restored.',
      reconcileConfirmBtn: 'Check & Reconcile SAP',
      reconcileCancelBtn: 'Cancel',
      reconcileSuccessFound: 'Existing SAP document found and linked.',
      reconcileSuccessCleared: 'No SAP Goods Issue was found. The issue has been cleared for safe retry.',
      reconcileErrorUnreachable: 'SAP could not be reached. Retry reconciliation later.',
      reconcileManualToggle: 'Or enter verified SAP document numbers manually',
      reconcileManualDocEntry: 'SAP DocEntry (Optional)',
      reconcileManualDocNum: 'SAP Doc # (Optional)',
      reconcileManualSubmitBtn: 'Link Manual SAP Document',
    },

    createUser: {

      title: 'Create user',

      username: 'Username',

      password: 'Password',

      warehouse: 'Warehouse',

      role: 'Role',

      roleUser: 'User',

      roleAdmin: 'Admin',

      selectWarehouse: '— Select warehouse —',

      loadingWarehouses: 'Loading…',

      creating: 'Creating…',

      createUser: 'Create user',

      back: '← Back',

      created: (username) => `User "${username}" created successfully.`,

    },

    users: {

      title: 'User Management',

      newUser: '+ New user',
      activityLog: 'Activity Log',

      totalUsers: 'Total users',

      active: 'Active',

      disabled: 'Disabled',

      loadingUsers: 'Loading users…',

      noUsers: 'No users found.',

      colUsername: 'Username',

      colRole: 'Role',

      colWarehouse: 'Warehouse',

      colStatus: 'Status',

      colJoined: 'Joined',

      colActions: 'Actions',

      you: '(you)',

      editBtn: '✏️ Edit',

      disableBtn: '⊘ Disable',

      enableBtn: '✓ Enable',

      statusActive: '● Active',

      statusDisabled: '○ Disabled',

      roleAdmin: '⭐ Admin',

      roleUser: '👤 User',

      createModal: 'Create new user',

      editModal: (username) => `Edit — ${username}`,

      deleteModal: 'Delete user',

      username: 'Username',

      password: 'Password',

      role: 'Role',

      warehouse: 'Warehouse',

      optionalForAdmins: '(optional for admins)',

      selectWarehouse: '— Select warehouse —',

      noWarehouse: '— No warehouse —',

      accountActive: 'Account active',

      changePassword: 'Change password (optional)',

      newPassword: 'New password',

      confirmPassword: 'Confirm new password',

      leaveBlank: 'Leave blank to keep current',

      repeatPassword: 'Repeat new password',

      passwordMismatch: 'Passwords do not match',

      roleUser: 'User',

      roleAdmin: 'Admin',

      warehouseRequired: 'Warehouse is required for normal users.',

      cancel: 'Cancel',

      creating: 'Creating…',

      createUser: 'Create user',

      saving: 'Saving…',

      saveChanges: 'Save changes',

      deleteConfirm: (username) => `Are you sure you want to permanently delete `,

      deleteUsername: (username) => username,

      deleteWarn: '⚠️ This cannot be undone. Use',

      deleteWarnDisable: 'Disable',

      deleteWarnSuffix: "to preserve the user's history and attribute rules.",

      deleting: 'Deleting…',

      deleteBtn: '🗑️ Delete permanently',

      userUpdated: 'User updated successfully.',

      created: (username) => `User "${username}" created.`,

      confirmMustMatch: 'Please confirm the new password',

      enterPassword: 'Please enter a new password',

      passwordTooShort: 'Password must be at least 4 characters',

    },
    audit: {
      title: 'Activity Log',
      subtitle: 'Audit trail of system events, user operations, and SAP postings',
      filterSearch: 'Search description, entity ID, or details…',
      filterModule: 'Module',
      filterAction: 'Action',
      filterStatus: 'Status',
      filterUser: 'User',
      filterDateFrom: 'From Date',
      filterDateTo: 'To Date',
      allModules: 'All Modules',
      allActions: 'All Actions',
      allStatuses: 'All Statuses',
      allUsers: 'All Users',
      clearFilters: 'Clear Filters',
      refresh: 'Refresh',
      colTimestamp: 'Date & Time',
      colUser: 'User',
      colModule: 'Module',
      colAction: 'Action',
      colEntity: 'Reference',
      colDescription: 'Description',
      colStatus: 'Status',
      colIp: 'IP Address',
      colDetails: 'Details',
      viewDetails: 'View Details',
      detailsTitle: 'Activity Details',
      close: 'Close',
      metadata: 'Metadata',
      noChangesRecorded: 'No before/after state diff recorded.',
      businessDetailsTitle: 'Operation Details',
      changesTitle: 'Changes',
      noAdditionalDetails: 'No additional details are available for this operation.',
      detailUnknownField: 'Additional information',
      valueYes: 'Yes',
      valueNo: 'No',
      detailFields: {
        item_code: 'Item Code', item_name: 'Item Name', order_number: 'Production Order Number', production_order: 'Production Order',
        final_quantity: 'Final Quantity', warehouse: 'Warehouse', warehouse_code: 'Warehouse Code', warehouse_name: 'Warehouse Name',
        vehicle_number: 'Vehicle Number', car_number: 'Vehicle Number', container_number: 'Container Number', container_quantity: 'Container Count',
        batch_number: 'Batch Number', batch_numbers: 'Batch Numbers', batch: 'Batch', from_warehouse: 'Source Warehouse', to_warehouse: 'Destination Warehouse',
        from_bin: 'Source Bin', to_bin: 'Destination Bin', source_bin: 'Source Bin', source_pallet_position: 'Source Pallet Position',
        source_pallet_position_code: 'Pallet Position Code', pallet_position: 'Pallet Position', pallet_position_code: 'Pallet Position Code',
        transfer_reference: 'Transfer Reference', reservation_reference: 'Reservation Reference', reference: 'Reference',
        sap_document_entry: 'SAP Document Entry', sap_document_number: 'SAP Document Number', sap_doc_entry: 'SAP Document Entry',
        sap_doc_num: 'SAP Document Number', sap_receipt_doc_num: 'SAP Receipt Number', quantity: 'Quantity', total_quantity: 'Total Quantity',
        uom: 'Unit of Measure', uom_code: 'Unit of Measure', reason: 'Reason', notes: 'Notes', status: 'Status', username: 'Username',
        role: 'Role', is_active: 'Account Active', transfer_stage: 'Transfer Stage', draft_number: 'Draft Number', first_weight: 'First Weight',
        second_weight: 'Second Weight', product_weight: 'Product Weight', card_code: 'Business Partner Code', vendor_card_code: 'Vendor Code',
        vendor_name: 'Vendor Name', target_warehouse: 'Target Warehouse', updated_fields: 'Changed Fields',
        attempted_username: 'Attempted Username', target_pallet_position: 'Target Pallet Position', draft_id: 'Draft ID', stage: 'Inspection Stage',
        capacity: 'Capacity', allocation_type: 'Allocation Type', channel_type: 'Channel Type',
      },
      emptyTitle: 'No activities found',
      emptySubtitle: 'Try adjusting your filters or search terms.',
      loading: 'Loading activity logs…',
      errorLoading: 'Failed to load activity logs.',
      showingCount: 'Showing {from} - {to} of {total} events',
      page: 'Page',
      prev: 'Previous',
      next: 'Next',
      first: 'First',
      last: 'Last',
      diffField: 'Field',
      diffBefore: 'Before',
      diffAfter: 'After',
      modAuth: 'Auth & Security',
      modUsers: 'Users',
      modTransfer: 'Stock Transfer',
      modColdStorage: 'Cold Storage',
      modQuality: 'Quality',
      modGrpo: 'Purchase GRPO',
      modPurchaseQuotation: 'Purchase Quotation',
      modScale: 'Truck Scale',
      modProductionReceipt: 'Production Receipts',
      actLogin: 'Login',
      actLogout: 'Logout',
      actCreate: 'Create',
      actUpdate: 'Update',
      actDelete: 'Delete',
      actApprove: 'Approve',
      actReject: 'Reject',
      actPost: 'SAP Post',
      actCancel: 'Cancel',
      actReserve: 'Reserve',
      actRelease: 'Release',
      actOccupy: 'Occupy',
      actVacate: 'Vacate',
      actConfigure: 'Configure',
      actWeigh: 'Weigh',
      statusSuccess: 'Success',
      statusFailed: 'Failed',
      statusWarning: 'Warning',
    },


    wizard: {

      step1: 'Step 1 of 5',

      step2: (num) => `Step 2 of 5 · Order ${num}`,

      step3: (units, uom, wh) => `Step 3 of 5 · ${units} ${uom} · ${wh}`,

      step4: 'Step 4 of 5',

      step5: 'Step 5 of 5',

      tapCard: 'Tap a card — it loads and moves to the next step automatically.',

      enterUnits: 'Enter the number of units to receive, then choose a unit of measure.',

      completeBatch: 'Complete each batch step-by-step. When all batches show ✅ you can continue.',

      reviewDesc: 'Check everything below, then submit for admin review. The admin will approve and post to SAP.',

      filterPlaceholder: 'Filter by order number, item code or name…',

      clearFilters: 'Clear',

      loadingOrders: 'Loading orders…',

      noOrders: 'No open production orders found.',

      noOrdersFiltered: 'No orders match the current filters.',

      orderLabel: (num) => `Order ${num}`,

      loadingOrderDetails: 'Loading order details…',

      loadingOrderData: 'Loading order data…',

      unitsLabel: 'Number of units (1 – 150)',

      maxUnits: 'Maximum is 150 units',

      searchUom: 'Search by name or number…',

      loadingUom: 'Loading UOM options…',

      noUom: 'No weight-based UOM available for this order.',

      selectUom: 'Please select a unit of measure',

      nextBtn: 'Next →',

      totalBatchUnits: 'Total batch units',

      batchLabel: (n) => `Batch ${n}`,

      autoGenerated: 'Auto-generated on submit',

      editBtn: 'Edit',

      removeBtn: 'Remove',

      duplicateBatch: 'Duplicate this batch with the same values',

      noBins: 'No bin locations loaded — skip if not required.',

      loadingBins: 'Loading bin locations…',

      binsUnavailable: 'Could not load bin locations',

      searchBins: 'Search bins…',

      noBinsMatch: (q) => `No bins match "${q}".`,

      currentAttr: 'Current attribute',

      selected: (v) => `Selected: ${v}`,

      empty: 'Empty',

      optionalNotes: 'Leave empty or type a value',

      reviewBatch: '✓ Review batch',

      reviewArrow: 'Review →',

      submitReview: 'Submit for review ✓',

      submitting: 'Submitting…',

      chooseAnother: '← Choose another order',

      unlockHint: 'Complete previous steps to unlock',

      prevStepHint: 'Complete previous steps first',

      stepOrder: 'Order',

      stepQuantity: 'Quantity',

      stepBatchSetup: 'Batch setup',

      stepReview: 'Review',

      stepDone: 'Done',

      subBin: 'Bin',

      subAttributes: 'Attributes',

      subReview: 'Review',

      brandLabel: 'Brand',

      sizeLabel: 'Size',

      seasonLabel: 'Season',

      detailsLabel: 'Details',

      pageTitle1: 'Select a production order',

      pageTitle3: 'Batch setup',

      pageTitle4: 'Review before submitting',

      submittedTitle: 'Receipt submitted for review',

      submittedDesc: 'Your receipt has been saved and is waiting for admin approval before being posted to SAP.',

      reviewId: 'Review ID',

      totalSubmitted: 'Total submitted',

      printLabels: '🖨 Print batch labels',

      newReceipt: '+ New receipt',

      homeBtn: '← Home',

      warehouseFilter: '🏭 Warehouse:',

      allWarehouses: 'All',

      loadingAttrOpts: 'Loading attribute options…',

      attrUnavailable: 'SAP attribute options are temporarily unavailable. You can continue manually or retry.',

      clearSkip: '⊘ Clear & skip',

      noUomSearch: 'No UOM matches your search',

      binLocation: 'Bin location',

      addBatch: '+ Add another batch',

      released: 'Released',

      tapToSelect: 'Tap to select →',

      attrStep: (i, total) => `Step ${i} of ${total}`,

      quantity: 'Quantity',

    },

    review: {

      title: 'Receipt Review',

      subtitle: 'Admin',

      loadError: 'Failed to load pending receipts.',

      refresh: '↻ Refresh',

      exportExcel: '⬇ Export Excel',

      importExcel: '⬆ Import Excel',

      downloadTemplate: '⬇ Download Import Template',

      filterStatus: 'Status',

      filterOrder: 'Order #',

      filterBatch: 'Batch #',

      filterWarehouse: 'Warehouse',

      filterVendor: 'Vendor',

      filterCreatedBy: 'Created by',

      filterDateFrom: 'From',

      filterDateTo: 'To',

      allStatuses: 'All statuses',

      pending: 'Pending',

      posted: 'Posted',

      failed: 'Failed',

      approve: 'Approve & Post',

      approving: 'Posting…',

      reject: 'Reject',

      changeOrder: 'Change Order',

      save: 'Save',

      saving: 'Saving…',

      saved: '✓ Saved',

      bulkSet: 'Bulk set:',

      applySelected: 'Apply to selected',

      applying: 'Applying…',

      editableRows: (n) => `${n} editable ${n === 1 ? 'row' : 'rows'} selected`,

      selectAll: 'Select all',

      deselectAll: 'Deselect all',

      noMatch: 'No matches',

      noneSelected: 'None selected',

      selected: (n) => `${n} selected`,

      rejectTitle: (id) => `Reject Receipt #${id}`,

      rejectReason: 'Reason (optional)',

      rejectPlaceholder: 'Enter reason…',

      confirmReject: 'Confirm Reject',

      rejecting: 'Rejecting…',

      changeOrderTitle: (id) => `Change Production Order — Receipt #${id}`,

      changeOrderCurrent: 'Current:',

      changeOrderSearch: 'Search by order #, item code, or product name…',

      changeOrderLoading: 'Loading…',

      noOrders: 'No orders found.',

      changeTo: (num) => `Change to ${num}`,

      selectOrder: 'Select an order',

      changing: 'Changing…',

      addUnits: 'Add Units',

      postExtra: 'Post',

      postingExtra: 'Posting…',

      deleteConfirm: (label) => `Delete ${label}?\n\nThis will remove this batch only. Other batches in this receipt will not be affected.`,

      bulkSaveAll: 'Save All Edits',

      bulkPostAll: 'Post All Pending',

      bulkPostConfirm: (n) => `Post all ${n} pending receipt${n !== 1 ? 's' : ''} to SAP? This cannot be undone.`,

      importModalTitle: 'Import Preview',

      importApply: 'Apply Import',

      importApplying: 'Applying…',

      importCancel: 'Cancel',

      totalBatches: 'batches',

      totalQty: 'total qty',

      noReceipts: 'No receipts match the current filters.',

      rejectFailed: 'Failed to reject.',

      changeOrderFailed: 'Failed to change order.',

      loadProductionOrdersFailed: 'Failed to load production orders.',

      deleteBatchFailed: 'Failed to delete batch.',

      uomNotFound: 'UOM not found.',

      bulkUpdateFailed: 'Bulk update failed.',

      nothingToPost: 'Nothing to post. Select at least one pending batch row.',

      bulkPostFailed: 'Bulk post failed.',

      noRowsToExport: 'No rows to export.',

      multiBatchWarning: 'This receipt contains multiple batches. Select all batches in this receipt to post it, or duplicate batches must be separate receipts.',

      myReceipts: 'My Receipts',

      userBanner: 'You can edit and save your submitted receipts. Final SAP posting is handled by an admin.',

      colFiltersLabel: 'Column filters:',

      batchCount: (n) => `${n} batch${n !== 1 ? 'es' : ''}`,

      totalQtyLabel: 'Total qty:',

      saveSelected: 'Save selected',

      savingSelected: 'Saving…',

      postSelected: 'Post selected',

      postingSelected: 'Posting…',

      printLabels: (n) => `🖨️ Print ${n} label${n !== 1 ? 's' : ''}`,

      importConfirm: 'Confirm Import',

      importing: 'Importing...',

      importNote: (n) => `Showing first ${n} preview rows.`,

      colStatus: 'Status',       colOrder: 'Order',       colItem: 'Item',

      colProduct: 'Product',     colWh: 'WH',             colUnits: 'Units',

      colUom: 'UOM',             colQty: 'Qty',           colBatch: 'Batch #',

      colBrand: 'Brand',         colSize: 'Size',          colCategory: 'Category',

      colPacking: 'Packing',     colSeason: 'Season',      colCompany: 'Company',

      colVendor: 'Vendor',       colPart: 'Part',          colNumber: 'Number',

      colDetails: 'Details',     colBin: 'Bin',            colBy: 'By',

      colDate: 'Date',           colSapErr: 'SAP / Reason', colAddUnits: 'Add Units',

      colActions: 'Actions',

      fieldUnits: 'Units',       fieldUom: 'UOM',          fieldBrand: 'Brand',

      fieldSize: 'Size',         fieldCategory: 'Category', fieldPacking: 'Packing',

      fieldSeason: 'Season',     fieldCompany: 'Company',  fieldVendor: 'Vendor',

      fieldPart: 'Part',         fieldNumber: 'Number',    fieldDetails: 'Details',

      fieldBin: 'Bin',

    },

    rules: {

      title: 'Attribute Rules',

      tabOrders: '📦 Production Orders',

      tabUsers: '👤 User Rules',

      tabWarehouses: '🏭 Warehouse Rules',

      tabVisibility: '👁 Order Visibility',

      configuredOrders: 'Configured orders',

      loadingOrders: 'Loading…',

      noOrders: 'No rules configured yet.',

      orderNum: (n) => `Order ${n}`,

      valueRules: (n) => `${n} value rule${n !== 1 ? 's' : ''}`,

      hidden: (n) => `${n} hidden`,

      configured: 'configured',

      deleteAllRules: '✕ Delete all rules',

      deleting: 'Deleting…',

      enterOrderNum: 'Production order number…',

      load: 'Load',

      loading: '…',

      orderNotFound: 'Order not found.',

      noRulesHint: 'Enter a production order number to configure attribute rules.',

      noRulesHintSub: 'Orders without rules behave exactly as before — all options are shown.',

      loadingOptions: 'Loading order options…',

      fieldsRestricted: (n) => `${n} field${n !== 1 ? 's' : ''} restricted`,

      saveRules: 'Save rules',

      saving: 'Saving…',

      usersWithRules: 'Users with rules',

      noUserRules: 'No user rules configured yet.',

      selectUser: 'Select user',

      loadingUsers: 'Loading users…',

      selectUserDefault: '— Select user —',

      noUserHint: 'Select a user to configure their allowed attribute values.',

      noUserHintSub: 'Users without rules see all options — existing behavior is preserved.',

      loadingOpts: 'Loading options…',

      saveUserRules: 'Save user rules',

      warehousesWithRules: 'Warehouses with rules',

      noWhRules: 'No warehouse attribute rules configured yet.',

      selectWarehouse: 'Select warehouse',

      loadingWarehouses: 'Loading warehouses…',

      selectWarehouseDefault: '— Select warehouse —',

      noWhHint: 'Select a warehouse to configure its allowed attribute values and field visibility.',

      noWhHintSub: 'Warehouses without rules show all options and all fields — existing behavior is preserved.',

      saveWhRules: 'Save warehouse rules',

      allAllowed: 'All allowed',

      visible: 'Visible',

      hiddenLabel: 'Hidden',

      selectWarehouseVis: 'Select warehouse',

      orderVisTitle: 'Select warehouse',

      orderVisDesc: 'Hide specific production orders per warehouse. Hidden orders will not appear in the Receipt Wizard for normal users in that warehouse. Admins always see all orders.',

      orderVisEmpty: 'Select a warehouse to manage order visibility.',

      orderVisEmptySub: 'By default all orders are visible to all users.',

      ordersShown: (n, total) => `${n} order${n !== 1 ? 's' : ''} shown${total ? ` (filtered from ${total})` : ''}. Click to toggle visibility.`,

      saveVisRules: 'Save visibility rules',

      ordersHidden: (n) => `${n} order${n !== 1 ? 's' : ''} hidden`,

      searchOrders: 'Search orders…',

      noOpenOrders: 'No open orders found for this warehouse.',

      loadingOrdersVis: 'Loading orders…',

      metadataLoading: '⏳ Loading option values…',

      metadataError: '⚠️ Could not load all option values.',

      noFieldOptions: 'No options available for this field.',

      valuesAllowed: (n) => `✓ ${n} value${n !== 1 ? 's' : ''} allowed`,

      warehouseCode: (code) => `Warehouse ${code}`,

      savedMsg: 'Rules saved.',

      saveUserSuccess: (username) => `Rules saved for ${username}.`,

      saveWhSuccess: (code) => `Rules saved for warehouse ${code}.`,

      saveVisSuccess: (code) => `Saved visibility rules for warehouse ${code}.`,

      confirmDeleteUser: 'Delete all rules for this user?',

      confirmDeleteOrder: 'Delete all rules for this order?',

      confirmDeleteWh: (code) => `Delete all attribute rules for warehouse ${code}?`,

      clearedUser: 'All rules cleared for this user.',

      clearedWh: 'All rules cleared for this warehouse.',

      clearedOrder: 'All rules cleared for this order.',

      deleteFailed: (msg) => `Delete failed: ${msg}`,

      failedToSave: 'Failed to save.',

      orderVisible: '✓ Visible',

      orderHidden: '🚫 Hidden',

      noWhMatch: 'No warehouses match.',

      loadOrdersFailed: (msg) => `Failed to load orders: ${msg}`,

      searchWhPlaceholder: 'Search by code or name…',

    },

    scale: {

      title: 'Weighbridge / Scale',

      subtitle: 'Truck weighing, tare adjustments, and quality inspection handoff',

      weighingTitle: 'Weighing Station',

      weighingSubtitle: 'Record gross (loaded) or tare (empty) weights for trucks',

      draftsTitle: 'Weighing Drafts & History',

      draftsSubtitle: 'Track active weighing drafts, resume second weights, and print tickets',

      devicesTitle: 'Scale Devices & Indicators',

      devicesSubtitle: 'Manage hardware scale connections, COM ports, network gateways, and simulator',

      agentStatusTitle: 'Local Scale Agent Status',

      agentStatusSubtitle: 'Hardware gateway running on local port 8998',

      agentConnected: 'Local Scale Agent Connected',

      agentNotDetected: 'Local Scale Agent Not Detected',

      agentChecking: 'Checking Local Agent...',

      agentUptime: 'Uptime',

      agentVersion: 'Version',

      agentScalesCount: 'Scales Monitored',

      agentServerConnected: 'ERP Sync',

      testConnection: 'Test Agent',

      reloadConfig: 'Reload Agent Config',

      deployAgent: 'Deploy Agent',

      deployAllScales: 'Download Scale Agent',

      deploying: 'Downloading...',

      deploySuccess: 'Agent deployment package downloaded successfully',

      deployError: 'Failed to deploy agent package',

      comPort: 'COM Port',

      detectedPorts: 'Detected Hardware Ports',

      manualPort: 'Enter Port Manually...',

      manualComPortLabel: 'Custom COM Port',

      baudRate: 'Baud Rate',

      autoDetectMode: 'Auto-detect (Recommended)',

      autoDetectHelper:

        'The Scale Agent automatically finds the connected indicator COM port and baud rate. No manual settings needed.',

      manualConfig: 'Advanced / Manual Configuration',

      connectionType: 'Connection Type',

      localCom: 'Serial COM / USB (Local)',

      remoteIp: 'Network IP / Gateway (Remote)',

      virtualSim: 'Virtual Simulator (Lab)',

      toggleActive: 'Toggle Status',

      activateDevice: 'Activate Device',

      deactivateDevice: 'Deactivate Device',

      confirmDeactivateDevice: 'Are you sure you want to deactivate this scale device? Deactivated scales will not receive live weights or be packaged in agent deployments.',

      confirmActivateDevice: 'Are you sure you want to activate this scale device?',

      confirmDeleteDevice: 'Are you sure you want to permanently delete this scale device?',

      deviceCreatedSuccess: 'Scale device created successfully',

      deviceUpdatedSuccess: 'Scale device updated successfully',

      deviceDeletedSuccess: 'Scale device deleted successfully',

      deviceStatusChanged: 'Scale device status updated successfully',

      agentNoticeOffline: 'The Scale Agent is not running on this computer (http://127.0.0.1:8998). To connect physical serial indicators, please download the deployment package and run ScaleAgent.exe.',

      liveWeightMonitor: 'Live Indicator Monitor',

      selectScaleToMonitor: 'Select a scale to monitor real-time indicator output',

      noDevicesFound: 'No scale devices configured yet',

      openWeighing: 'Open Weighing Station →',

      openDrafts: 'View Drafts & Tickets →',

      openDevices: 'Manage Scale Devices →',

      itemElementsTitle: 'Scale Item Elements',

      itemElementsSubtitle: 'Manage approved pallet, crate, and tare master data used during weighing',

      openItemElements: 'Manage Item Elements →',

      receiptTitle: 'Receipt of Goods',

      receiptSubtitle: 'Record incoming goods and materials on the EG.ST.F04 receiving receipt',

      openReceipt: 'Open Receipt →',

      receiptDate: 'Date',

      vehicleNumber: 'Vehicle Number',

      driverName: 'Driver Name',

      driverLicense: 'License Number',

      receiptSource: 'Source',

      productsTable: 'Items & Quantities',

      quantityKg: 'Quantity (kg)',

      quantityTon: 'Quantity (ton)',

      packageType: 'Package Type',

      addRow: 'Add Row',

      removeRow: 'Remove',

      totalKg: 'Total (kg)',

      totalTon: 'Total (ton)',

      driverSignature: 'Driver',

      receiverSignature: 'Receiver of Goods Value',

      signatureName: 'Name',

      signatureDraw: 'Signature',

      clearSignature: 'Clear',

      saveReceipt: 'Save',

      saveAndClose: 'Save & Close',

      clearReceipt: 'Clear',

      printReceipt: 'Print',

      receiptSavedSuccess: 'Receipt saved successfully',

      receiptUpdatedSuccess: 'Receipt updated successfully',

      confirmClearReceipt: 'Are you sure you want to clear this receipt? Unsaved data will be lost.',

      newItemElement: 'New Item Element',

      editItemElement: 'Edit Item Element',

      noItemElementsFound: 'No item elements found',

      itemCode: 'Item Code',

      itemName: 'Item Name',

      elementName: 'Element Name',

      active: 'Active',

      inactive: 'Inactive',

      actions: 'Actions',

      activateElement: 'Activate',

      deactivateElement: 'Deactivate',

      itemElementCreated: 'Item element created successfully',

      itemElementUpdated: 'Item element updated successfully',

      liveWeight: 'Live Weight Reading',

      stable: 'STABLE',

      unstable: 'UNSTABLE',

      online: 'ONLINE',

      offline: 'OFFLINE',

      device: 'Scale Device',

      vehicle: 'Vehicle / Truck',

      truckType: 'Vehicle Type',

      trailerNumber: 'Trailer Number',

      containerNumber: 'Container Number',

      normalTruck: 'Normal Vehicle / Truck',

      containerTruck: 'Container Truck',

      driver: 'Driver',

      supplier: 'Supplier / Farm',

      item: 'Item / Material',

      firstWeight: 'First Weight',

      secondWeight: 'Second Weight',

      grossWeight: 'Gross Weight',

      tareWeight: 'Tare Weight',

      netWeight: 'Product Net Weight',

      tareAdjustments: 'Tare Adjustments (Pallets & Crates)',

      selectElement: 'Select an influencing element',

      pivotBatches: 'Pivot / Multi-Supplier Distribution',

      pivots: 'Pivot batches',

      notes: 'Notes / Observations',

      recordFirstWeight: 'Record First Weight',

      recordSecondWeight: 'Record Second Weight',

      sendToQuality: 'Send to Quality Inspection',

      sentToQualitySuccess: 'Draft #{draftNumber} successfully transferred to Quality Inspection!',

      cancelDraft: 'Cancel Draft',

      confirmCancelDraft: 'Are you sure you want to cancel this draft?',

      resumeDraft: 'Resume 2nd Weight',

      printTicket: 'Print Ticket',

      statusPendingSecond: '2nd Weight Pending',

      statusCompleted: 'Weighing Completed',

      statusSentToQuality: 'Transferred to Quality',

      statusCancelled: 'Cancelled',

      newVehicleModalTitle: 'Vehicle Entry & Registration',

      vehicleNumber: 'Vehicle Number / Plate',

      company: 'Transport Company',

      enterGate: 'Record Gate Entry',

      addTareElement: 'Add Tare Element',

      unitWeight: 'Unit Weight (KG)',

      count: 'Count / Quantity',

      signedWeight: 'Total Element Tare (KG)',

      addPivotBatch: 'Add Supplier Pivot',

      boxCount: 'Box Count',

      boxWeight: 'Box Weight',

      percentage: 'Percentage (%)',

      allocatedWeight: 'Allocated Weight (KG)',

      autoDistribute: 'Auto Distribute Weights',

      simulatorTitle: 'Virtual Scale Simulator (Dev / Lab)',

      simulatorNote: 'Use the virtual simulator only for lab testing.',

      setWeight: 'Set Weight (KG)',

      simStable: 'Simulate Stable',

      simUnstable: 'Simulate Unstable',

      simOffline: 'Simulate Offline',

      simOnline: 'Simulate Online',

      updateSimulator: 'Update Simulator Reading',

      mustBeStableWarning: 'Weight reading must be Stable and device Online to record weight.',

      noDraftsFound: 'No weighing drafts found.',

      noDevicesFound: 'No scale devices found.',

      ticketHeader: 'WEIGHBRIDGE TICKET / تصريح ميزان البسكول',

      ticketNumber: 'Ticket #',

      loadedTime: 'Loaded Time',

      emptyTime: 'Empty Time',

      operator: 'Scale Operator',

      allocationTitle: 'Truck Load Allocations',

      allocationSubtitle: 'Distribute certified net weight across suppliers, items, and batches',

      addAllocationLine: '+ Add Allocation Line',

      addAllocationLineMulti: '+ Add New Item/Supplier Line (Multi-Load)',

      removeAllocationLine: '✕ Delete Line',

      autoDistributeMode: 'Auto Distribution (by estimated weights)',

      manualDistributeMode: 'Custom Manual Distribution',

      certifiedNetTruckWeight: 'Certified Truck Net Weight:',

      totalAllocatedWeight: 'Total Distributed Weight:',

      remainingDifference: 'Remaining / Difference:',

      balancedStatus: '✅ Balanced (100% Certified)',

      unbalancedStatus: (diff) => `⚠️ Unbalanced (Diff: ${diff} KG)`,

      unbalancedSaveWarning: '⚠️ Cannot save while total allocation differs from certified net truck weight.',

      saveAllocations: 'Save & Certify Allocations',

      batchOrPivot: 'Batch / Pivot #',

      packageType: 'Package Type',

      packageCount: 'Package Count',

      estUnitWeight: 'Est. Unit Weight (KG)',

      estLineWeight: 'Est. Total Weight',

      finalAllocatedWeight: 'Allocated Net Weight (KG)',

      cargoStepTitle: 'Cargo & Load Data',

      cargoStepSubtitle: 'Specify driver, and cargo items, suppliers, and batches loaded on the truck',

      driverPlaceholder: 'Enter truck driver name',

      supplierPlaceholder: 'e.g. Al-Namaa Agri Co.',

      itemPlaceholder: 'e.g. Summer Orange Grade 1',

      batchPlaceholder: 'e.g. PVT-NORTH-01',

      allocatedLinesCount: (count) => `${count} Allocated Lines`,

      totalBoxesCount: (count) => `Total Packages: ${count}`,

      totalEstWeight: (weight) => `Total Est. Weight: ${weight} KG`,

      lineItemNum: (num) => `Line #${num}`,

      loadBreakdownSection: 'Load Breakdown & Allocations',

      allocatedBreakdownPreview: (count) => `📦 Assigned Load Lines (${count} lines):`,

      estUnitCalc: (count, unit, total) => `${count} pkgs × ${unit} KG = ${total} KG (Est.)`,

      allocationsSavedSuccess: 'Load allocations updated and distributed successfully.',

      tareDeductionTotal: 'Total Tare Deductions:',

      entryExitPermitsTitle: 'Entry & Exit Permits',

      entryExitPermitsSubtitle: 'Issue gate entry (F05) or exit (F06) permits for trucks and goods',

      openEntryExitPermits: 'Open Entry & Exit Permits →',

      entryPermitTitle: 'Entry Permit',

      entryPermitSubtitle: 'Gate entry permit for incoming vehicles — form EG.ST.F05',

      openEntryPermit: 'Open Entry Permit →',

      exitPermitTitle: 'Exit Permit',

      exitPermitSubtitle: 'Gate exit permit for outgoing goods — form EG.ST.F06',

      openExitPermit: 'Open Exit Permit →',

      permitDate: 'Date',

      permitType: 'Permit Type',

      supplierName: 'Supplier Name',

      buyerName: 'Buyer Name',

      permitDriverName: 'Driver Name',

      destination: 'Destination',

      inspectionSection: 'Inspection & Examination Result',

      inspectionResult: 'Inspection Result / Notes',

      gateWriter: 'Gate Clerk',

      inspectionHead: 'Head of Incoming Inspection',

      weighingSection: 'Load Weight Statement',

      grossWeight: 'Gross',

      tareWeight: 'Tare',

      netWeight: 'Net',

      kgLabel: 'kg',

      tonLabel: 'ton',

      onlyAndAmount: 'Only and Amount',

      scaleOperator: 'Scale Operator',

      generalManager: 'General Manager',

      responsiblePerson: 'Responsible',

      departmentManager: 'Department',

      recordKg: 'Recorded (kg)',

      recordTon: 'Recorded (ton)',

      weightKg: 'Weight (kg)',

      weightTon: 'Weight (ton)',

      savePermit: 'Save',

      printPermit: 'Print',

      clearPermit: 'Clear',

      permitSavedSuccess: 'Permit saved successfully',

      permitUpdatedSuccess: 'Permit updated successfully',

      confirmClearPermit: 'Are you sure you want to clear this permit? Unsaved data will be lost.',

      permitNumber: 'Permit No.',

    },

    inspectionStages: {

      eyebrow: 'Quality Settings',

      title: 'Inspection Stages',

      description: 'Manage quality inspection workflow stages.',

      total: 'Total Stages',

      active: 'Active',

      addStage: 'New Stage',

      editStage: 'Edit Stage',

      searchPlaceholder: 'Search stages...',

      code: 'Stage Code',

      nameAr: 'Arabic Name',

      nameEn: 'English Name',

      sortOrder: 'Sort Order',

      status: 'Status',

      actions: 'Actions',

      enabled: 'Active',

      disabled: 'Disabled',

      enable: 'Activate',

      disable: 'Deactivate',

      delete: 'Delete',

      deleted: 'Stage deleted successfully',

      deleteFailed: 'Failed to delete stage',

      deleteFirstTitle: 'Delete Inspection Stage',

      deleteFirstMessage: 'Are you sure you want to delete this stage?',

      deleteSecondTitle: 'Confirm Stage Deletion',

      deleteSecondMessage: 'This action is irreversible. All linked criteria will be affected.',

      saved: 'Stage saved successfully',

      saveFailed: 'Failed to save stage',

      loadFailed: 'Failed to load inspection stages',

    },

    qualityCategories: {

      eyebrow: 'Quality Settings',

      title: 'Quality Categories',

      description: 'Manage defect classification categories (Pests, Mechanical, Others).',

      total: 'Total Categories',

      active: 'Active',

      addCategory: 'New Category',

      editCategory: 'Edit Category',

      searchPlaceholder: 'Search categories...',

      code: 'Category Code',

      nameAr: 'Arabic Name',

      nameEn: 'English Name',

      sortOrder: 'Sort Order',

      status: 'Status',

      actions: 'Actions',

      enabled: 'Active',

      disabled: 'Disabled',

      enable: 'Activate',

      disable: 'Deactivate',

      saved: 'Category saved successfully',

      saveFailed: 'Failed to save category',

      loadFailed: 'Failed to load quality categories',

    },

    qualityCriteria: {

      eyebrow: 'Quality Settings',

      title: 'Quality Criteria Master',

      description: 'Manage all quality defect criteria and formula calculation keys.',

      total: 'Total Criteria',

      active: 'Active',

      addCriterion: 'New Criterion',

      editCriterion: 'Edit Criterion',

      searchPlaceholder: 'Search criteria...',

      code: 'Code',

      autoGeneratedCode: 'Auto-generated code',

      nameAr: 'Arabic Name',

      nameEn: 'English Name',

      category: 'Category',

      categoryFilter: 'Category Filter',

      allCategories: 'All Categories',

      inspectionStage: 'Inspection Stage',

      stageFilter: 'Stage Filter',

      allStages: 'All Stages',

      calculationKey: 'Calculation Key',

      displayOrder: 'Display Order',

      status: 'Status',

      actions: 'Actions',

      enabled: 'Active',

      disabled: 'Disabled',

      enable: 'Activate',

      disable: 'Deactivate',

      deleteConfirm: 'Are you sure you want to delete this criterion?',

      deleted: 'Criterion deleted successfully',

      deleteFailed: 'Failed to delete criterion',

      saved: 'Criterion saved successfully',

      saveFailed: 'Failed to save criterion',

      loadFailed: 'Failed to load quality criteria',

      noCriteriaMatch: 'No criteria matching search filter',

      description: 'Quality criteria definition',

    },

    itemCriteria: {

      eyebrow: 'Quality Settings',

      title: 'Item Criteria Mapping',

      description: 'Map inspection criteria to specific raw materials and items.',

      selectStage: 'Stage',

      selectStageTitle: '1. Select Stage',

      selectStageDesc: 'Choose the inspection stage to map criteria for.',

      selectItemGroup: 'Item Group',

      selectItemGroupTitle: '2. Select Item Group',

      selectItemGroupDesc: 'Choose an item group to filter items.',

      selectItemGroupWarning: 'Please select an item group first.',

      selectItemTitle: '3. Select Item',

      selectItemDesc: 'Choose the item to configure criteria.',

      items: 'Items',

      noItems: 'No items available',

      itemsLoadFailed: 'Failed to load items',

      itemGroupsLoadFailed: 'Failed to load item groups',

      mappingsLoadFailed: 'Failed to load criteria mappings',

      criteria: 'Criteria',

      criteriaSearch: 'Search Criteria',

      criteriaSearchPlaceholder: 'Search criteria by name or code...',

      categoryFilter: 'Category',

      allCategories: 'All Categories',

      selectionFilter: 'Selection Filter',

      selectionAll: 'All',

      selectionSelected: 'Selected Only',

      selectionUnselected: 'Unselected Only',

      selected: 'Selected',

      notSelected: 'Not Selected',

      selectedCount: 'Selected Criteria',

      saveMappings: 'Save Mappings',

      saved: 'Mappings saved successfully',

      saveFailed: 'Failed to save mappings',

      noCriteriaTitle: 'No Criteria Available',

      noCriteriaDesc: 'No active criteria found for this stage.',

      noCriteriaMatchTitle: 'No Matching Criteria',

      noCriteriaMatchDesc: 'No criteria matched the search filters.',

      itemSearchPlaceholder: 'Search items...',

      stage: 'Stage',

      itemGroup: 'Item Group',

    },

    quality: {

      stepTrucks: 'Trucks & Vehicles',

      addTruck: '+ Add Truck',

      addFirstBatch: '+ Add First Batch',

      addAnotherBatch: '+ Add Another Batch',

      addedOperationsTitle: 'Recorded Batch Operations',

      batchesProgress: (done, total) => `${done} of ${total} Batches Completed`,

      completedInspections: 'Completed Inspections',

      remainingInspections: 'Remaining Inspections',

      totalTrucksLabel: 'Total Trucks',

      totalBatchesLabel: 'Total Batches',

      totalOperationsCount: (n) => `${n} operations`,

      contractorsLoading: 'Loading contractors...',

      contractorsEmpty: 'No contractors found',

      contractorsLoadFailed: 'Failed to load contractors',

      contractorSelectDesc: 'Select contractor for this vehicle',

      selectContractorFirst: 'Please select a contractor first',

      noPendingScaleDrafts: 'No closed scale drafts are waiting for receiving.',

      contractorSearchPlaceholder: 'Search contractor by name...',

      farmSearchPlaceholder: 'Search farm by name...',

      selectFarmFirst: 'Please select a farm / origin first',

      selectItemWarning: 'Please select an item for all batches',

      searchingBatchERP: 'Verifying batch in ERP...',

      noActiveTrucks: 'No active trucks in this inspection session',

      noActiveDefects: 'No active defects registered',

      noDefectsInCat: 'No defects recorded in this category',

      recordedDefects: 'Recorded Defects',

      leftSideDefects: 'Pests & Agricultural Defects',

      rightSideDefects: 'Mechanical & Physiological Defects',

      tabPests: 'Agricultural Pests',

      tabMechanical: 'Mechanical Defects',

      tabPhysiological: 'Physiological & Quality',

      returnToVehicleDetails: '← Return to Truck Details',

      reviewCollectedInfo: 'Review Inspection Summary & Statistics',

      reviewResultsAction: 'View Results Dashboard →',

      startNewVehicleInspection: '+ Start New Vehicle Inspection',

      openOperationAction: (label) => label || 'Start raw inspection',

      operationsEmptyTitle: 'No Batch Operations Found',

      operationsEmptyDesc: 'No batch operations recorded for this truck yet.',

      printWindowBlocked: 'Popup window was blocked by your browser. Please allow popups to print.',

      dashboardDesc: 'Review statistical quality indicators, defects distribution, and final decision.',

      colTruckNumber: 'Truck #',

      colContractor: 'Contractor',

      colFarmVendor: 'Farm / Supplier',

      totalQuantity: 'Total Qty',

      warehouseCode: (code) => `Warehouse ${code}`,

      statusRejected: 'Rejected',

      filterTruckNumber: 'Truck Number',

      filterContractor: 'Contractor',

      filterFarmVendor: 'Farm / Supplier',

      filterProduct: 'Product / Item',

      filterInspector: 'Inspector',

      filterDateFrom: 'From Date',

      filterDateTo: 'To Date',

      grpoDraftOpenFailed: 'Failed to open receiving draft',

      backToTruck: 'Back to Truck',

      binLocation: 'Bin Location',

      binLocationRequired: 'Bin location is required',

      checkGrpoPostingReadiness: 'Check Document Readiness',

      continueBtn: 'Continue',

      delete: 'Delete',

      deleteFailed: 'Failed to delete report',

      discountPercent: 'Discount %',

      discountPercentCannotBeNegative: 'Discount % cannot be negative',

      documentDate: 'Document Date',

      documentDateRequired: 'Document date is required',

      dueDate: 'Due Date',

      dueDateRequired: 'Due date is required',

      expiryDate: 'Expiry Date',

      grpoApproveFailed: 'Failed to approve receiving draft',

      grpoComments: 'Receiving Comments',

      grpoDocumentNotPosted: 'Receiving document is not registered yet',

      grpoDraftApprovedForPosting: 'Receiving draft approved for registration',

      grpoDraftLoadFailed: 'Failed to load receiving draft',

      grpoDraftNotFound: 'Receiving draft not found',

      grpoDraftSaveFailed: 'Failed to save receiving draft',

      grpoDraftSaved: 'Receiving draft saved successfully',

      grpoDraftStatus: 'Receiving Status',

      grpoDraftPostedSuccess: 'Receiving document registered successfully.',

      grpoHeaderDesc: 'Header & Vendor Details',

      grpoHeaderInfo: 'Header Information',

      grpoItemDetails: 'Warehouse & Pricing',

      grpoItemDetailsDesc: 'Item specifications, quantity, pricing, and cost centers',

      grpoPostFailed: 'Failed to register receiving document',

      grpoPostedFinalDesc: 'Receiving document has been registered successfully.',

      grpoPostedFinalTitle: 'Receiving Document Registered',

      grpoPostedToSap: 'Document Registered',

      grpoPostingReadinessReady: 'Ready for registration',

      grpoPreviewFailed: 'Failed to preview receiving document',

      grpoQuantity: 'Receiving Quantity',

      grpoReviewPostingDesc: 'Review all fields before finalizing the receiving document',

      grpoReviewPostingTitle: 'Review & Register Receiving',

      grpoStatuses: {

        DRAFT: 'Draft',

        PENDING_REVIEW: 'Pending Review',

        APPROVED_FOR_POSTING: 'Approved for Posting',

        POSTED: 'Posted',

        POSTING_FAILED: 'Posting Failed',

        CANCELLED: 'Cancelled',

      },

      grpoSteps: {

        header: 'Supplier & Documents',

        item: 'Warehouse & Pricing',

        warehouse: 'Warehouse & Bin',

        operational: 'Operational & Weight',

        batches: 'Batch Data',

        review: 'Review & Post',

        batch: 'Operational & Weight',

        manual: 'Manual Receiving',

        manualItemWarehouse: 'Warehouse, Pricing & Bin Location',

        itemAndPricingSection: 'Item & Pricing Details',

        warehouseAndBinSection: 'Warehouse & Bin Location',

      },

      manualSteps: {

        vehicle: 'Shipment & Container',

        supplier: 'Supplier',

        product: 'Product & Material',

        warehouse: 'Warehouse & Bin',

        operational: 'Operational Context',

        batches: 'Batch Data',

        review: 'Review & Create',

        batch: 'Batch & Production Dates',

      },

      batchDataTitle: 'Batch Data & Properties',

      batchDataDesc: 'Configure batches, allocate received quantities, assign bin locations, and set batch properties.',

      batchLabel: (n) => `Batch #${n}`,

      totalRequiredQty: 'Required Quantity',

      allocatedQty: 'Allocated Quantity',

      remainingBalance: 'Remaining Balance',

      quantitiesBalanced: 'Quantities are fully balanced and ready to proceed.',

      quantityMismatch: (diff) => `Allocated quantity does not match total required quantity (Difference: ${diff}).`,

      addBatch: '＋ Add Batch',

      duplicateBatch: '⧉ Duplicate',

      removeBatch: '✕ Remove',

      editBatch: 'Edit Batch',

      doneBatch: 'Done / Confirm',

      basicAndBin: 'Batch Details',

      batchProperties: 'Batch Properties',

      batchSummary: 'Batch Summary',

      batchBreakdown: 'Batch Allocation Breakdown',

      noBatchesConfigured: 'No batches configured.',

      batchAttrs: {

        size: 'Size',

        brand: 'Brand',

        category: 'Category',

        packing: 'Packing',

        season: 'Season',

        extraSpec: 'Extra Spec.',

        vendor: 'Vendor',

        part: 'Part',

        company: 'Company',

        number: 'Number',

        details: 'Details',

        batchAttribute1: 'Batch Attribute 1',

        batchAttribute2: 'Batch Attribute 2',

      },

      manualStepVehicleTitle: 'Shipment & Container Details',

      manualStepVehicleDesc: 'Enter container / truck number, packed quantity, and optional operational notes.',

      manualStepSupplierTitle: 'Supplier',

      manualStepSupplierDesc: 'Select supplier or farm from SAP master data.',

      manualStepProductTitle: 'Product & Material Details',

      manualStepProductDesc: 'Select item group and item from SAP. Unit of measure is automatically locked.',

      manualStepWarehouseTitle: 'Warehouse & Bin',

      manualStepWarehouseDesc: 'Select destination warehouse and target bin location.',

      manualStepBatchTitle: 'Batch & Production Dates',

      manualStepBatchDesc: 'Enter manual batch number and specify manufacturing and admission dates.',

      manualStepReviewTitle: 'Review Manual Receiving',

      manualStepReviewDesc: 'Verify all intake details before creating the receiving draft.',

      containerNumber: 'Container No.',

      containerNumberPlaceholder: 'Enter container / truck number...',

      containerNumberRequired: 'Container No. is required.',

      noPacked: 'No. Packed',

      noPackedPlaceholder: '0',

      noPackedRequired: 'No. Packed is required.',

      invalidNoPacked: 'No. Packed must be a whole non-negative number.',

      itemGroupRequired: 'Item group is required',

      batchAvailable: 'Batch number is available in SAP',

      carNumberRequired: 'Car number is required for manual receiving',

      grpoManualStepTitle: 'Manual Receiving Details',

      grpoManualStepDesc: 'Shipment identity and material details for manual receiving.',

      itemCodeOrNameRequired: 'Item code or item name is required',

      inspectAnotherBatch: 'Inspect Another Batch',

      itemCodeRequired: 'Item code is required',

      itemNameRequired: 'Item name is required',

      landingSubtitle: 'Select inspection module or configure master quality data',

      landingTitle: 'Quality Control Hub',

      location: 'Location',

      locationOptional: 'Location (Optional)',

      locationPlaceholder: 'Optional location / Dimension 1 code',

      selectLocationOptional: '-- Select Location (Optional) --',

      general: 'General',

      generalOptional: 'General (Optional)',

      generalPlaceholder: 'Optional general / Dimension 2 code',

      selectGeneralOptional: '-- Select General Cost Center (Optional) --',

      loadingCostCenters: 'Loading SAP cost centers...',

      noCostCenters: 'No cost centers available',

      costCenterLoadFailed:
        'Failed to load SAP cost centers. Your changes will be kept. Retry to load again.',

      loadBinsFailed: 'Failed to load bin locations',

      loadWarehousesFailed: 'Failed to load warehouses',

      loadingBinLocations: 'Loading bins...',

      vendorRefNo: 'Vendor Ref. No.',

      vendorRefNoPlaceholder: 'Enter vendor ref. no...',

      journalRemark: 'Journal Remark',

      journalRemarkPlaceholder: 'Enter journal remark...',

      manufacturingDate: 'Manufacturing Date',

      manufacturingDateRequired: 'Manufacturing date is required',

      newTruckDetails: 'New Truck Details',

      noBatchesAdded: 'No batches added yet',

      numSamples: 'Number of Samples',

      postGrpoToSap: 'Register Receiving Document',

      confirmAndPostGrpoToSap: 'Confirm Receiving & Send to SAP',

      printGrpoDocument: 'Print Receiving Document',

      postedAt: 'Posted At',

      postedDeleteError: 'Cannot delete an already posted report',

      postingDate: 'Posting Date',

      postingDateRequired: 'Posting date is required',

      purchaseGrpoDocumentTitle: 'Receiving Document',

      purchaseGrpoDraftTitle: 'Receiving Draft',

      purchaseGrpoKicker: 'Receiving Operations',

      quantity: 'Quantity',

      quantityMustBeGreaterThanZero: 'Quantity must be greater than zero',

      quantityRequired: 'Quantity is required',

      receivingButton: 'Start Receiving Inspection →',

      receivingSubtitle: 'Inspect incoming raw material trucks and batches',

      receivingTitle: 'Raw Receiving Inspection',

      scaleDraftNumber: 'Scale draft number',

      scaleItem: 'Item',

      scalePendingDrafts: 'Scale drafts ready for receiving',

      scalePendingDraftsDesc: 'Receiving can be started here with vehicle, supplier, item, and weight prefilled.',

      scaleSupplier: 'Supplier',

      scaleVehicleTruck: 'Vehicle / Truck',

      scaleWeight: 'Weight',

      kgUnit: 'kg',

      reloadDraft: 'Reload Draft',

      sapDocEntry: 'Reference Number',

      sapDocNum: 'SAP DocNum',

      sapStatus: 'SAP Status',

      selectWarehouse: '— Select Warehouse —',

      selectWarehouseFirst: 'Please select a warehouse first',

      selectBinLocation: '— Select Bin Location —',

      title: 'Quality Inspection',

      desc: 'Perform quality inspections and record defects for batches.',

      headerKicker: 'EGAST Quality Management',

      start: 'Start Inspection',

      startBtn: 'Start Inspection',

      stepBatch: 'Batch Search',

      stepInfo: 'Inspection Info',

      stepFarm: 'Farm / Origin',

      stepCount: 'Sample Setup',

      stepSamples: 'Inspect Samples',

      stepReview: 'Review & Verify',

      stepResults: 'Results Dashboard',

      stepPrint: 'Print Report',

      stepDone: 'Print Report',

      catPests: 'Agricultural Pests & Insect Defects (Pests)',

      catMechanical: 'Mechanical Defects (Mechanical)',

      catOthers: 'Physiological Defects',
      catGrades: 'Quality Grades',

      colStatus: 'Status',

      colBatch: 'Batch #',

      colItem: 'Item Code',

      colProduct: 'Product Name',

      colDate: 'Date',

      colInspector: 'Inspector',

      colDecision: 'Decision',

      colDefects: 'Defects',

      colActions: 'Actions',

      loadFailed: 'Failed to load inspections.',

      rejectTitle: 'Reject Inspection Report #',

      rejectReason: 'Rejection Reason',

      rejectPlaceholder: 'Enter why this inspection was rejected...',

      confirmReject: 'Confirm Rejection',

      rejecting: 'Rejecting...',

      approveSuccess: 'Inspection approved and posted to SAP successfully.',

      rejectSuccess: 'Inspection report rejected successfully.',

      deleteSuccess: 'Inspection report deleted successfully.',

      savedDraft: 'Draft saved successfully.',

      resetConfirm: 'Are you sure you want to reset the wizard? All entered data will be lost.',

      totalSamples: 'Total Samples',

      totalDefects: 'Total Defects',

      commonDefect: 'Most Common Defect',

      qaDecision: 'QA Decision',

      averageDefects: 'Avg Defects / Sample',

      quarantineViolation: 'Quarantine Violation',

      quarantineViolationDesc: 'Molds detected in the sample inspection. Quarantine violation has occurred.',

      excelMatrix: 'Excel summary matrix',

      pctBruisesCuts: 'Bruises & Cuts Pct',

      pctHighCut: 'High Cut Pct',

      wasteTotal: 'Waste Total (AF)',

      qualityTotal: 'Quality Total (AG)',

      grandTotal: 'Grand Total (AH)',

      pass: 'Passed',

      fail: 'Failed',

      approved: 'Approved',

      rejected: 'Rejected',

      draftSaved: 'Draft Saved',

      draftAutoSaved: 'Draft Auto-Saved',

      printReport: 'Print Report',

      exportJson: 'Export JSON',

      postToSap: 'Approve & Post',

      posting: 'Posting...',

      rejectionReason: 'Rejection Reason',

      comments: 'Comments',

      notes: 'Notes',

      searchPlaceholder: 'Search batch number...',

      filterStatus: 'Filter status',

      additionalNotes: 'Additional Notes',

      approve: 'Approve & Post',

      approveConfirm: 'Are you sure you want to approve and post this inspection report to SAP?',

      approveError: 'Error approving and posting inspection report.',

      approveFailed: 'Approval and posting failed.',

      batchFound: 'Batch details loaded successfully.',

      batchNotFoundErr: 'Batch metadata not found in the ERP system. Inspection cannot proceed without a valid batch.',

      batchNumber: 'Batch Number',

      batchRequired: 'Batch number is required.',

      breakdown: 'Breakdown',

      carNumber: 'Car Number',

      colInspectionId: 'Inspection ID',

      confirmSaveReport: 'Confirm & Save Report',

      contractorName: 'Contractor Name',

      contractor: 'Contractor',

      cropName: 'Crop / Variety',

      dataClerkName: 'Data Clerk Name',

      decreaseSamples: 'Decrease Samples',

      defectCodeCategory: 'Defect Category',

      editInspection: 'Edit Inspection',

      enterBatchNumber: 'Please enter a batch number.',

      excelMatrixDesc: 'Statistical indicators and overall quality classification of the batch.',

      farmOrigin: 'Farm Origin',

      farm: 'Farm / Origin',

      finishInspection: 'Finish Inspection',

      increaseSamples: 'Increase Samples',

      infoDesc: 'Enter basic inspection and supplier details',

      inspectingSample: 'Inspecting Sample',

      inspectionDate: 'Inspection Date',

      inspectorName: 'Inspector Name',

      inspectorPlaceholder: 'Name of the responsible quality inspector',

      inspectorRequired: 'Inspector name is required.',

      itemCode: 'Item Code',

      loadingReports: 'Loading reports...',

      nextSample: 'Next Sample',

      noDefectsRecorded: 'No defects recorded',

      noReports: 'No quality reports found.',

      notesPlaceholder: 'Enter any additional comments regarding container state, moisture, temperature...',

      productName: 'Product Name',

      rawMaterialType: 'Raw Material Type',

      refresh: 'Refresh',

      refreshing: 'Refreshing...',

      reject: 'Reject',

      rejectFailed: 'Rejection failed.',

      rejectReasonRequired: 'Rejection reason is required.',

      releaseWarehouseLabel: 'Release Warehouse',

      releaseWarehouseDefault: 'Select release warehouse',

      returnHome: 'Return Home',

      backToReview: 'Back to Quality Review',

      reviewDashboardTitle: 'Quality Inspection Review Dashboard',

      reviewDesc: 'Review and verify sample data before finalizing',

      sampleCountQuestion: 'Total Samples (Samples Count)',

      sampleDefectsTotal: 'Total Sample Defects',

      sampleEntryDesc: 'Record defects detected in each sample',

      sampleLabel: (id) => `Sample ${id}`,

      sampleNumber: 'Sample #',

      sampleOf: (current, total) => `Sample ${current} of ${total}`,

      sampleSetupDesc: 'Configure statistical inspection sample size',

      sampleSetupHint: 'Separate input screens will be generated dynamically for each sample.',

      saveSuccess: 'Inspection report saved successfully.',

      saveSuccessTitle: 'Inspection Saved',

      saveSuccessDesc: 'Quality inspection report saved successfully.',

      searchDesc: 'Search and load an existing batch to inspect',

      searchTitle: 'Batch Search',

      searching: 'Searching...',

      startDefects: 'Start Defect Entry',

      startNewInspection: 'Start New Inspection',

      statusAll: 'All',

      statusFailed: 'Failed',

      statusPendingReview: 'Pending Review',

      statusPosted: 'Posted to SAP',

      statusCompleted: 'Completed',

      statusInProgress: 'In Progress',

      statusNotStarted: 'Not Started',

      submitFailed: 'Failed to submit inspection report.',

      submitNetworkError: 'Network error submitting inspection report.',

      submitSuccess: 'Quality Inspection report created and saved to review.',

      submitting: 'Submitting...',

      supplierName: 'Supplier Name',

      totalReports: 'Total Reports',

      unit: 'unit',

      unitOfMeasure: 'Unit of Measure',

      unitPrice: 'Unit Price',

      unitPriceRequired: 'Unit price is required',

      uomRequired: 'UoM is required',

      taxCode: 'Tax Code',

      taxCodeRequired: 'Tax code is required',

      selectTaxCode: 'Select Tax Code',

      loadingTaxCodes: 'Loading tax codes...',

      loadTaxCodesFailed: 'Failed to load tax codes',

      vendorCardCode: 'Vendor Code',

      vendorCardCodeRequired: 'Vendor code is required',

      vendorName: 'Vendor / Supplier',

      vendorNameRequired: 'Vendor name is required',

      warehouseRequired: 'Warehouse is required',

      viewDetails: 'View Details',

      viewReportTitle: 'View Report',

      viewResultsDashboard: 'View Results Dashboard',

      truckNumber: 'Truck Number',

      truckNumberRequired: 'Truck number is required',

      newTruck: 'New Truck',

      editTruck: 'Edit Truck',

      editTruckDetails: 'Edit Truck Details',

      editTruckDetailsTitle: 'Truck Details',

      deleteTruckCard: 'Delete Truck',

      confirmRemoveTruck: 'Are you sure you want to remove this truck and its batches?',

      truckNotFound: 'Truck not found',

      truckDetailsTitle: 'Truck Details',

      selectItem: 'Select Item',

      autoGenerated: 'Auto-generated',

      continueInspection: 'Continue Inspection',

      startInspection: 'Start Inspection',

      editBatchNumber: 'Edit Batch #',

      deleteBatch: 'Delete Batch',

      confirmRemoveBatch: 'Are you sure you want to delete this batch?',

      addBatch: 'Add Batch',

      batchInfoDesc: 'Batch details and weights',

      admissionDate: 'Admission Date',

      admissionDateRequired: 'Admission date is required',

      approveGrpoForPosting: 'Approve Receiving Draft',

      validationErrorsFound: 'Please resolve validation errors before submitting',

      selectedBin: 'Selected Storage Bin',

      warehouseBinDesc: 'Warehouse and Bin allocation',

      truckLabel: 'Truck',

      trucksBreakdown: 'Trucks Breakdown',

      defects: {

        acarus: 'Acarus',

        scale_insect: 'Scale Insect',

        spray_marks: 'Spray Marks',

        citrus_rust: 'Citrus Rust',

        thrips: 'Thrips',

        vegetable_defects: 'Vegetable Defects',

        gummosis: 'Gummosis',

        oil_spots: 'Oil Spots',

        sunburn: 'Sunburn',

        sooty_mold: 'Sooty Mold',

        mealybug: 'Mealybug',

        tearing: 'Tearing',

        high_cut: 'High Cut',

        bruises: 'Bruises',

        cuts: 'Cuts',

        under_size: 'Under Size',

        venting: 'Venting',

        fruit_fly: 'Fruit Fly',

        creasing: 'Creasing',

        fall_drop: 'Fall Drop',

        mutations: 'Mutations',

        navel_blight: 'Navel Blight',

        softness: 'Softness',

        molds: 'Molds',

        grade_1: 'Grade 1',

        grade_2: 'Grade 2',

      },

      decisions: {

        'Accepted': 'Accepted',

        'Conditionally Accepted': 'Conditionally Accepted',

        'Rejected (Tolerable Boundary Exceeded)': 'Rejected (Tolerable Boundary Exceeded)',

        'Rejected (Quarantine Defects)': 'Rejected (Quarantine Defects)'

      },

      batchExistsInSap: 'Batch number already exists in SAP for this item.',

      batchChecking: 'Checking batch in SAP...',

      scaleTicket: 'Scale Weighing Ticket',

      selectScaleTicket: 'Select active scale ticket (Optional)...',

      selectSupplier: 'Select Supplier / Farm...',

      selectContractor: 'Select Contractor (Optional)...',

      farmFilterAll: 'All',

      farmFilterCompany: 'Company Farms',

      farmFilterSuppliers: 'Raw Material Suppliers',

      selectItemGroup: 'Select Item Group...',

      itemGroup: 'Item Group',

      manualTruckNumber: 'Vehicle / Truck Number',

      selectBin: 'Select Storage Bin (Optional)...',

    },

    grpo: {

      title: 'Receiving',

      subtitle: 'Manage incoming goods and receiving operations.',

      pendingShipments: 'Pending Shipments',

      pendingShipmentsDesc: 'Incoming shipments awaiting receiving documentation',

      noPendingShipments: 'No pending receiving shipments',

      noPendingShipmentsDesc: 'All incoming shipments are documented or there are no eligible shipments.',

      openGrpo: 'Open Receiving',

      backToPending: 'Return to Pending Shipments',

      kicker: 'Receiving',

      searchPlaceholder: 'Search by batch, truck, supplier, or item...',

      refresh: 'Refresh',

      batchNumber: 'Batch / Order',

      vehicleTruck: 'Vehicle / Truck',

      supplier: 'Supplier / Vendor',

      item: 'Product / Item',

      quantity: 'Quantity',

      warehouse: 'Warehouse',

      inspectionDate: 'Inspection Date',

      scaleDate: 'Weighing Date',

      scaleDraftNumber: 'Weighbridge Ticket',

      sourceScale: 'Weighbridge',

      sourceScaleDesc: 'Weighed shipment directly from weighbridge',

      sourceQuality: 'Quality Inspection',

      sourceQualityDesc: 'Inspected shipment from quality lab',

      certifiedWeight: 'Certified Net Weight',

      status: 'Status',

      statusDraft: 'Receiving Draft',

      statusApprovedForPosting: 'Approved for Posting',

      statusPostingFailed: 'Posting Failed',

      statusPosted: 'Document Registered',

      statusReady: 'Ready for Receiving',

      openFailed: 'Failed to open receiving draft',

      deleteConfirmTitle: 'Delete Receiving Draft',

      confirmDelete: 'Are you sure you want to delete this receiving draft? This action cannot be undone.',

      draftDeleted: 'Receiving draft deleted successfully.',

      deleteFailed: 'Failed to delete receiving draft.',

      loading: 'Loading pending shipments...',

      errorLoading: 'Failed to load pending shipments',

      countShipments: (n) => `${n} pending shipments`,

      reviewTitle: 'Receiving Review',

      reviewSubtitle: 'Review completed receiving documents',

      reviewStep: 'Review & Register',

      documentStatus: 'Document Status',

      referenceNumber: 'Reference Number',

      manualSupplierDesc: 'Select the supplier or farm from the available records.',

      manualProductDesc: 'Select the item group and item. The unit of measure is set automatically.',

      batchAlreadyRegistered: 'This batch number is already registered for the selected item.',

      batchChecking: 'Checking the batch number...',

      noCompletedGrpos: 'No completed receiving documents found',

      noCompletedGrposDesc: 'No receiving documents have been registered yet.',

      countCompletedGrpos: (n) => `${n} completed receiving documents`,

      viewDocument: 'View Receiving Document',

      grpoNumber: 'Document Number',

      postedDate: 'Posting Date',

      sapDocInfo: 'Reference Number',

      backToReview: 'Return to Receiving Review',

      manualReceiving: 'Manual Receiving',

      manualReceivingTitle: 'Create Manual Receiving Request',

      manualReceivingDesc: 'Enter shipment and material details for manual receiving.',

      manualBadge: 'Manual',

      manualBadgeDesc: 'Manual receiving request',

      carNumber: 'Vehicle / Truck Number',

      carNumberPlaceholder: 'e.g. 1234 ABC',

      vendorName: 'Supplier / Vendor Name',

      vendorNamePlaceholder: 'e.g. Al-Amal Trading Co.',

      vendorCardCode: 'Vendor Code (Optional)',

      vendorCardCodePlaceholder: 'e.g. V10001',

      itemCode: 'Item Code (Optional)',

      itemCodePlaceholder: 'e.g. RM-TOMATO-01',

      itemName: 'Item / Material Description',

      itemNamePlaceholder: 'e.g. Fresh Tomatoes Grade A',

      quantityLabel: 'Quantity',

      uom: 'Unit of Measure (UOM)',

      warehouseSelect: 'Destination Warehouse',

      selectWarehouse: 'Select Warehouse...',

      batchNumberInput: 'Batch / Order Number',

      batchNumberPlaceholder: 'e.g. B-2026-001',

      notesLabel: 'Notes / Remarks (Optional)',

      notesPlaceholder: 'Any additional notes or shipment comments...',

      submitManualReceiving: 'Create & Open Receiving',

      creatingManualReceiving: 'Creating Receiving...',

      manualReceivingSuccess: 'Manual receiving created successfully. Opening receiving draft...',

      validationError: 'Please fill all required fields correctly',

      continuousWorkflow: 'Integrated Receiving System',

      phase1Badge: 'Phase 1: Manual Intake',

      phase2Badge: 'Phase 2: Receiving Review',

      phase1Kicker: 'Phase 1 of 2 (Manual Intake)',

      phase2Kicker: 'Phase 2 of 2 (Receiving Review)',

      phase1: 'Phase 1',

      phase1Completed: 'Phase 1 Completed',

      phase2: 'Phase 2',

      steps1to6: 'Steps 1 – 6',

      steps7to10: 'Steps 7 – 10',

      steps7to11: 'Steps 7 – 11',

      steps7to12: 'Steps 7 – 12',

      manualPhaseTitle: 'Manual Intake',

      manualIntakePhaseBadge: 'Manual Intake',

      steps1to10: 'Steps 1 – 10',

      continuousStepProgress: (arg) => {

        const step = typeof arg === 'object' && arg !== null ? arg.step || 1 : (arg || 1);

        return `Current step: ${step} of 10 (Manual Intake & Registration)`;

      },

      phase1Title: 'Manual Receiving Intake',

      phase2Title: 'Receiving Review & Registration',

      phase1DescActive: (arg) => {

        const step = typeof arg === 'object' && arg !== null ? arg.step || 1 : (arg || 1);

        return `Current step: ${step} of 6 (Intake details)`;

      },

      phase2DescActive: (arg) => {

        const step = typeof arg === 'object' && arg !== null ? arg.step || 7 : (arg || 7);

        return `Current step: ${step} of 10 (Accounting & document review)`;

      },

      phase2DescUpcoming: 'Next phase after completing intake and creating the draft.',

      submitManualAndProceedToGrpo: 'Create Draft & Proceed to Receiving Review',

      manualIntakeNotice: 'Manual intake details have been saved. Review accounting items, pricing, and storage below before final registration.',

      reviewPhase1Prompt: 'After verifying manual intake details, proceed to Step 8 to enter batch information and dates.',

    },

    shippingReceiving: {

      eyebrow: 'Logistics Operations',

      title: 'Shipping & Receiving',

      subtitle: 'Manage shipping, receiving, incoming goods, and delivery operations.',

      grpoTitle: 'Receiving',

      grpoSubtitle: 'Manage incoming goods and receiving operations.',

      openGrpo: 'Open Receiving →',

      shippingDeliveryTitle: 'Shipping',

      shippingDeliverySubtitle: 'Manage shipping and delivery operations for farms and suppliers.',

      openShippingDelivery: 'Open Shipping →',

    },

    shippingDelivery: {

      eyebrow: 'Logistics Operations',

      title: 'Shipping & Delivery',

      subtitle: 'Manage outgoing deliveries, shipping dispatches, and customer order fulfillment.',

      placeholderTitle: 'Shipping & Delivery Module',

      placeholderDesc: 'The Shipping & Delivery workflow is currently being set up. Full delivery management and dispatch features will be available here soon.',

      backToModule: 'Back to Shipping & Receiving',

    },

    customizationDelivery: {

      printTotalQuantity: 'Total Quantity',
      printTotalAmount: 'Total Value',
      printSapCreated: 'Document created in SAP Business One',
      printLineDetails: 'Document Items',
      checkingPosting: 'Checking document status in SAP. No new posting will be sent.',
      checkPosting: 'Check document status',
      pagination: 'Document pages',
      pageCounts: 'Delivery status counts and filters apply to the current page. Use Next to browse more orders.',
      scrollTable: 'Scroll horizontally to view all item fields',

      eyebrow: 'Sales Operations',

      title: 'Customization & Delivery',

      subtitle: 'Manage the sales cycle from quotation to delivery',

      quotationsTitle: 'Sales Quotations',

      quotationsSubtitle: 'Create and manage sales quotations',

      createQuotation: 'Create Sales Quotation →',

      openQuotations: 'Open Sales Quotations →',

      ordersTitle: 'Sales Orders',

      ordersSubtitle: 'Convert approved quotations into sales orders',

      salesQuotationsReviewTitle: 'Sales Quotations Review',

      salesQuotationsReviewEyebrow: 'LAYER 1: SALES QUOTATIONS',

      salesQuotationsReviewSubtitle: 'Review Sales Quotations and approval workflow status.',

      allQuotations: 'All Quotations',

      noQuotationsFound: 'No Sales Quotations Found',

      noQuotationsDesc: 'No quotation drafts match your selected filters.',

      salesOrdersReviewTitle: 'Sales Orders Review',

      salesOrdersReviewEyebrow: 'LAYER 2: SALES ORDERS',

      salesOrdersReviewSubtitle: 'Review Sales Orders created from approved quotations.',

      deliveryReviewTitle: 'Delivery Review',

      deliveryReviewSubtitle: 'Review completed Delivery documents created from Sales Orders.',

      deliveryReviewAnalyticsSubtitle: 'Analyze posted Deliveries by date, customer, Sales Order, and item.',

      reportFilters: 'Report Filters',

      dateFrom: 'From Date',

      dateTo: 'To Date',

      allCustomers: 'All Customers',

      allSalesOrders: 'All Sales Orders',

      allItems: 'All Items',

      item: 'Item',

      applyFilters: 'Apply Filters',

      resetFilters: 'Reset Filters',

      appliedFilters: 'Applied Filters',

      filter_dateFrom: 'From Date',

      filter_dateTo: 'To Date',

      filter_customer: 'Customer',

      filter_salesOrder: 'Sales Order',

      filter_item: 'Item',

      printReport: 'Print Report',

      printDelivery: 'Print Delivery',

      printQuotation: 'Print Quotation',

      printSalesOrder: 'Print Sales Order',

      printDocument: 'Print Document',

      deliveryReport: 'Delivery Report',

      deliveryDocument: 'Delivery Document',

      quotationDocument: 'Sales Quotation',

      salesOrderDocument: 'Sales Order',

      reportGeneratedAt: 'Report generated at',

      uom: 'UoM',

      quantity: 'Quantity',

      unitPrice: 'Unit Price',

      lineTotal: 'Line Total',

      deliverySummary: 'Delivery Summary',

      summary_deliveries: 'Deliveries',

      summary_quantity: 'Delivered Quantity',

      summary_customers: 'Customers',

      summary_salesOrders: 'Sales Orders',

      summary_items: 'Items',

      byCustomer: 'By Customer',

      byItem: 'By Item',

      bySalesOrder: 'By Sales Order',

      byDate: 'By Date',

      deliveryDetails: 'Delivery Details',

      allPostedDeliveries: 'All Posted Deliveries',

      filteredDeliveryDetails: 'Filtered Delivery Details',

      noMatchingDeliveries: 'No posted Deliveries match the applied filters.',

      deliveryReviewSearch: 'Search by Delivery, Sales Order, customer, or item...',

      deliveryReviewEmpty: 'No completed Deliveries',

      deliveryReviewEmptyDescription: 'Completed Delivery documents will appear here after successful creation.',

      deliveryNumber: 'Delivery Number',

      deliveryDocEntry: 'SAP Delivery DocEntry',

      sourceSalesOrder: 'Sales Order',

      customer: 'Customer',

      items: 'Items',

      deliveredQuantity: 'Delivered Qty',

      deliveryStatus: 'Status',

      deliveryDate: 'Delivery Date',

      deliveryCreated: 'Delivery Created',

      deliveryReviewReadOnly: 'Completed Delivery documents are shown in read-only mode.',

      openOrders: 'Open Sales Orders →',

      customizationTitle: 'Customization',

      customizationSubtitle: 'Review customer sales quotations and their items.',

      openCustomization: 'Open Customization →',

      customizationListSubtitle: 'Sales quotations recorded in SAP. Open a document to see its items.',

      deliveryTitle: 'Delivery',

      deliverySubtitle: 'Review customer sales orders and their items.',

      openDelivery: 'Open Delivery →',

      deliveryListSubtitle: 'Sales orders recorded in SAP. Open a document to see its items.',

      detailSubtitle: 'Document details as recorded in SAP.',

      readOnlyNote: 'Read-only. This module cannot create or change documents in SAP.',

      noDocuments: 'No documents found',

      noQuotations: 'There are no sales quotations to show.',

      noOrders: 'There are no sales orders to show.',

      emptyFiltered: 'No documents match the selected filters.',

      noItems: 'This document has no items.',

      moreAvailable: 'More documents are available. Narrow the filters to see them.',

      section: {

        summary: 'Document',

        items: 'Items',

      },

      status: {

        open: 'Open',

        closed: 'Closed',

        paid: 'Paid',

        delivered: 'Delivered',

      },

      filters: {

        status: 'Status',

        allStatuses: 'All statuses',

        dateFrom: 'From',

        dateTo: 'To',

        clear: 'Clear filters',

      },

      columns: {

        documentNumber: 'Document Number',

        customer: 'Customer',

        status: 'Status',

        currency: 'Currency',

        quotationDate: 'Quotation Date',

        validUntil: 'Valid Until',

        orderDate: 'Order Date',

        dueDate: 'Due Date',

        documentDate: 'Document Date',

        line: 'Line',

        item: 'Item',

        description: 'Description',

        quantity: 'Quantity',

        unit: 'Unit',

        warehouse: 'Warehouse',

        location: 'Location',

        unitPrice: 'Unit Price',

        lineTotal: 'Line Total',

      },

      workflow: {

        customizeQuotation: 'Customize Quotation',

        createDelivery: 'Create Delivery',

        draftTitle: 'Customization Draft',

        deliveryDraftTitle: 'Delivery Draft',

        customizedQuantity: 'Customized Quantity',

        customizedPrice: 'Customized Unit Price',

        specification: 'Specification',

        brand: 'Brand',

        packaging: 'Packaging',
        notes: 'Notes',
        sourceQuotation: 'Source Quotation',

        saveDraft: 'Save Changes',

        submitReview: 'Submit for Review',

        approve: 'Approve',

        reject: 'Reject',

        syncQuotation: 'Sync to SAP Quotation',

        customerApproval: 'Customer Approval',

        recordCustomerApproval: 'Record Customer Approval',

        approvalType: 'Approval Evidence Type',

        referenceNumber: 'Customer PO / Reference #',

        contactPerson: 'Customer Contact Person',

        createOrder: 'Create Sales Order',

        salesOrderCreated: 'SAP Sales Order Created',

        deliveryCreated: 'SAP Delivery Note Created',

        postDelivery: 'Post Delivery to SAP',

        batches: 'Batches & Bin Locations',

        batchNumber: 'Batch Number',

        binCode: 'Bin Location',

        allocatedQuantity: 'Allocated Quantity',

        addBatch: 'Add Batch Allocation',

        orderQuantity: 'Order Quantity',

        openQuantity: 'Open Quantity',

        deliveryQuantity: 'Delivery Quantity',

        notes: 'Notes / Remarks',

        rejectionReason: 'Rejection Reason',

        relationshipMapInfo: 'Natively linked in SAP Business One Relationship Map',

        poApproval: 'Customer Purchase Order (PO)',

        signedDocApproval: 'Signed Quotation Document',

        emailApproval: 'Written Email Confirmation',

        unselectedNotice: 'Unselected lines remain open in the SAP Quotation and will not be ordered.',

        viewOrder: 'View Sales Order',

        viewQuotation: 'View Sales Quotation',

        sourceQuotation: 'Source Quotation',

        costingDimensions: 'Cost Center Dimensions (COGS)',

        deliveryHistory: 'Delivery History',

        createAnotherDelivery: 'Create Another Delivery Note',

        confirmLinesForOrder: 'Confirm Lines to Order',

        diffOriginal: 'Original',

        diffCustomized: 'Customized',

        freeText: 'Free Text',

        actions: 'Actions',

        customize: 'Customize',

        deliver: 'Deliver',

        openQty: 'Open Qty',

        deliveredQty: 'Delivered Qty',

        lineStatus: 'Line Status',

        statusOpen: 'Open',

        statusClosed: 'Closed',

        batchSumMismatch: 'Batch allocation sum must match line delivery quantity',

        relationshipChain: 'SAP Native Relationship Chain',

      },

      wizard: {

        step1Customer: 'Customer',

        step2Items: 'Items',

        step3Commercial: 'Commercial & Warehouse',

        step4Logistics: 'Logistics',

        step5Specs: 'Customization',

        step6Review: 'Review & Validate',

        step7Confirm: 'Confirmation',

        delivStep1Order: 'Order Details',

        delivStep2Quantities: 'Quantities',

        delivStep3Batches: 'Batches',

        delivStep4Bins: 'Bin Locations',

        delivStep5Dimensions: 'Cost Centers',

        delivStep6Review: 'Review & Post',

      },

      workflowGuidanceNote: 'Connected to SAP Business One Service Layer. Select a document to start or continue the customization and delivery workflow.',

    },

    purchaseQuotation: {

      kicker: 'Shipping Operations',

      title: 'Shipping',

      desc: 'Create and manage shipping documents and delivery operations.',

      newQuotation: 'New Shipping Document',

      searchPlaceholder: 'Search by supplier, document number, or reference number...',

      records: 'records',

      postedRecords: 'posted records',

      noQuotations: 'No Shipping Documents Found',

      noQuotationsDesc: 'Get started by creating a new shipping document.',

      noPostedRecords: 'No Completed Shipping Documents',

      noPostedRecordsDesc: 'Completed shipping documents will appear here.',

      vendor: 'Vendor',

      vendorCardCode: 'Vendor Code',

      vendorName: 'Vendor Name',

      vendorRefNo: 'Vendor Ref. No.',

      currency: 'Currency',

      groupNo: 'Group No.',

      postingDate: 'Posting Date',

      validUntil: 'Valid Until',

      documentDate: 'Document Date',

      requiredDate: 'Required Date',

      buyerCode: 'Buyer',

      ownerCode: 'Owner',

      journalRemark: 'Journal Remark',

      remarks: 'Remarks',

      shipToAddress: 'Ship-to Address',

      payToAddress: 'Pay-to Address',

      totalBeforeDiscount: 'Total Before Discount',

      discountPct: 'Header Discount %',

      discountAmount: 'Discount Amount',

      freight: 'Freight',

      taxTotal: 'Tax Total',

      rounding: 'Rounding',

      totalPaymentDue: 'Total Payment Due',

      itemsCount: 'Line Items',

      items: 'items',

      openDoc: 'Open Document',

      docTitle: 'Shipping Document',

      headerInfo: 'Basic Document Info',

      saveDraft: 'Save Draft',

      approveAndPreview: 'Approve & Preview Document',

      confirmPostToSap: 'Confirm & Register Document',

      postingToSap: 'Registering document...',

      cancelQuotation: 'Cancel Shipping Document',

      deleteConfirmTitle: 'Delete Shipping Draft',

      confirmDelete: 'Are you sure you want to delete this shipping draft? This action cannot be undone.',

      draftDeleted: 'Shipping draft deleted successfully.',

      deleteFailed: 'Failed to delete shipping draft.',

      draftCreated: 'New shipping draft created.',

      draftSaved: 'Draft saved successfully.',

      approvedForPosting: 'Shipping document approved for registration.',

      postSuccess: 'Document registered successfully!',

      cancelledSuccess: 'Shipping document cancelled.',

      confirmCancel: 'Are you sure you want to cancel this shipping document?',

      loadFailed: 'Failed to load shipping draft.',

      createFailed: 'Failed to create shipping draft.',

      saveFailed: 'Failed to save draft.',

      approvalFailed: 'Failed to approve draft for posting.',

      postFailed: 'Document registration failed.',

      cancelFailed: 'Failed to cancel draft.',

      errorLoading: 'Failed to load shipping records.',

      status_DRAFT: 'Draft',

      status_PENDING_REVIEW: 'Pending Review',

      status_APPROVED_FOR_POSTING: 'Approved for Posting',

      status_POSTED: 'Posted',

      status_POSTING_FAILED: 'Posting Failed',

      status_CANCELLED: 'Cancelled',

      statusDraft: 'Draft',

      statusApprovedForPosting: 'Approved for Posting',

      statusPostingFailed: 'Posting Failed',

      statusPosted: 'Posted',

      statusCancelled: 'Cancelled',

      reviewTitle: 'Shipping Summary & Verification',

      sapPayloadPreview: 'Document Data Preview',

      financialTotals: 'Calculated Document Totals',

      documentOverview: 'Document Overview',

      financialSummary: 'Financial Summary',

      documentLines: 'Document Lines',

      sapVerification: 'Document Verification',

      verifyWithSap: 'Verify Document',

      readyToPost: 'Ready to register',

      readyToPostDesc: 'The shipping document is ready to be registered.',

      sapVerificationSuccess: 'Document verification successful - the shipping document is ready to be registered.',

      clickVerifyPrompt: 'Click "Verify Document" before final registration.',

      developerDetails: 'Technical Document Details',

      reviewLogTitle: 'Completed Shipping Documents',

      reviewLogDesc: 'Archive of all successfully completed shipping documents.',

      sapDocNum: 'Document Number',

      postedBy: 'Posted By',

      itemNo: 'Item No.',

      itemDesc: 'Item Description',

      quotedDate: 'Quoted Date (ShipDate)',

      quotedQty: 'Quoted Qty.',

      requiredQty: 'Required Qty.',

      uom: 'UoM',

      unitPrice: 'Unit Price',

      discPct: 'Disc %',

      warehouse: 'Warehouse',

      location: 'Location',

      costCenter: 'General (Cost Center)',

      lineTotal: 'Line Total',

      addLine: 'Add Line Item',

      removeLine: 'Remove Line',

      pendingQuotations: 'Shipping & Delivery Documents',

      vendorRequired: 'Please select a vendor to proceed.',

      vendorSearchPlaceholder: 'Search contractor by name or code...',

      selectedVendor: 'Selected Vendor',

      vendorsFound: 'vendors found',

      noVendorsFound: 'No vendors match your search.',

      selectVendorPrompt: 'Select a supplier to proceed with the shipping document.',

      changeVendor: 'Change Vendor',

      selectedItem: 'Selected Item',

      itemRequiredPrompt: 'Please select an item from the list below.',

      itemRequired: 'Please select an Item No. for all lines to proceed.',

      searchItemPlaceholder: 'Search item by code or description...',

      noItemsFound: 'No items match your search.',

      itemGroup: 'Item Group',

      selectItemGroup: 'Select Item Group',

      selectItemGroupPrompt: 'Select an Item Group above to view its items, or use search.',

      group: 'Group',

      sectionItemGroup: '1. Item Group',

      sectionItem: '2. Item',

      sectionItemDetails: '3. Item Details',

      selectItemGroupFirst: 'Select an Item Group first.',

      selectItemFirst: 'Select an Item above to configure quantities and details.',

      availableSapItems: 'Available Items',

      lockedToVendorCurrency: 'Locked to Supplier Currency',

      multiCurrency: 'Multi-Currency (Select)',

      itemGroupStepDesc: 'Select an item group for each shipping line to load matching items.',

      itemStepDesc: 'Select the required item for each shipping line from the item catalog.',

      itemDetailsStepDesc: 'Configure quoted and required quantities, dates, and pricing for each selected item.',

      itemGroupRequired: 'Please select an Item Group for all lines to proceed.',

      invalidQuantities: 'Please enter valid quantities for all lines to proceed.',

      vehicleNumber: 'Vehicle Number',

      vehicleNumberPlaceholder: 'Enter vehicle / truck number...',

      invalidVehicleNumber: 'Vehicle number cannot exceed 11 characters.',

      containerQuantity: 'Container Quantity',

      invalidContainerQty: 'Container quantity must be a whole non-negative number.',

      vehicleAndContainer: 'Vehicle & Container',

      vehicleAndContainerDesc: 'Specify the shipment vehicle number and container quantity.',

      steps: {

        vehicle: 'Vehicle & Container',

        vendor: 'Vendor',

        header: 'Document Info & Dates',

        itemGroup: 'Item Group',

        item: 'Item',

        itemDetails: 'Item Details',

        contents: 'Contents & Quantities',

        logistics: 'Logistics & Cost Centers',

        financial: 'Financial & Remarks',

        review: 'Review & Post',

      },

      tabs: {

        contents: 'Contents',

        logistics: 'Logistics',

        accounting: 'Accounting',

        attachments: 'Attachments',

      },

      attachmentsDesc: 'No file attachments associated with this shipping document.',

    },

  },





  ar: {
    searchControl: searchTranslations.ar,
    physicalTransfer: physicalTransferTranslations.ar,

    common: {

      continue: 'متابعة',

      pleaseWait: 'يرجى الانتظار...',

      errorLoadingData: 'فشل تحميل البيانات',

      previous: 'السابق',

      remove: 'إزالة',

      requiredFields: 'يرجى ملء جميع الحقول المطلوبة',

      saveChanges: 'حفظ التعديلات',

      status: 'الحالة',

      typeDelete: 'اكتب حذف للتأكيد',

      save: 'حفظ',

      cancel: 'إلغاء',

      delete: 'حذف',

      deleteDraft: 'حذف المسودة',

      edit: 'تعديل',

      duplicate: 'تكرار',

      refresh: 'تحديث',

      review: 'المراجعة',

      rules: 'القواعد',

      users: 'المستخدمين',

      signOut: 'تسجيل الخروج',

      admin: 'مدير',

      pending: 'قيد الانتظار',

      posted: 'تم الترحيل',

      failed: 'فشل',

      rejected: 'مرفوض',

      ready: 'جاهز',

      total: 'الإجمالي',

      search: 'بحث',

      filter: 'فلتر',

      clear: 'مسح',

      done: 'تم',

      back: 'رجوع',

      next: 'التالي',

      loading: 'جارٍ التحميل…',

      saving: 'جارٍ الحفظ…',

      submitting: 'جارٍ الإرسال…',

      posting: 'جارٍ الترحيل…',

      postingToSap: 'جارٍ الإرسال إلى SAP…',

      creatingInSap: 'جارٍ الإنشاء في SAP…',

      preparingPrint: 'جارٍ تجهيز المستند للطباعة…',

      validating: 'جارٍ التحقق…',

      deleting: 'جارٍ الحذف…',

      refreshing: 'جارٍ التحديث…',

      reconciling: 'جارٍ المطابقة…',

      systemBusy: 'النظام يعمل الآن — يرجى الانتظار…',

      retry: 'إعادة المحاولة',

      accessDenied: 'غير مصرح. للمديرين فقط.',

      noData: 'لا توجد بيانات.',

      confirm: 'تأكيد',

      close: 'إغلاق',

      working: 'جارٍ التنفيذ...',

      dismissNotification: 'إغلاق الإشعار',

      selectOption: 'اختر خيارًا',

      typeToSearch: 'اكتب للبحث…',

      noOptions: 'لا توجد خيارات',

      success: 'نجاح',

      error: 'خطأ',

      warning: 'تنبيه',

      info: 'معلومة',

      open: 'فتح →',

      optional: 'اختياري',

      actions: 'الإجراءات',

      view: 'عرض',

    },

    nav: {

      quality: 'فحص الجودة',

      qualityReceiving: 'فحص استلام الخام',

      sapWorkflow: 'SAP سير العمل',

      home: 'الرئيسية',

      production: 'الإنتاج',

      receiptWizard: 'معالج الإيصال',
      issueWizard: 'معالج الصرف للإنتاج',

      createUser: 'إنشاء مستخدم',

      usersPage: 'المستخدمون',
      activityLog: 'سجل النشاط',

      attributeRules: 'قواعد الخصائص',

      receiptReview: 'مراجعة الإيصالات',
      issueReview: 'مراجعة أوامر الصرف',
      productionReview: 'مراجعة الإنتاج',

      transfer: 'التحويل',

      productionRules: 'قواعد الإنتاج',

      transferRules: 'قواعد التحويل',

      qualityRules: 'قواعد الجودة',

      qualityInspectionStages: 'مراحل الفحص',

      qualityCategories: 'تصنيفات الجودة',

      qualityCriteria: 'معايير الجودة',

      qualityCriteriaMapping: 'ربط معايير الجودة',

      transferReview: 'مراجعة التحويلات',

      qualityReview: 'مراجعة الجودة',

      scale: 'الميزان والبسكول',

      scaleReview: 'مراجعة الميزان',

      scaleWeighing: 'محطة التوزين',

      scaleDrafts: 'مسودات الميزان',

      scaleDevices: 'أجهزة الميزان',

      scaleItemElements: 'العناصر المؤثرة',

      scaleReceipt: 'إيصال استلام',

      scaleEntryExitPermits: 'تصاريح الدخول والخروج',

      scaleEntryPermit: 'تصريح دخول',

      scaleExitPermit: 'تصريح خروج',

      grpo: 'الاستلام',

      grpoReview: 'مراجعة الاستلام',

      shippingReceiving: 'الشحن والاستلام',

      customizationDelivery: 'التخصيص والتسليم',

      customization: 'التخصيص',

      delivery: 'التسليم',

      salesQuotations: 'عروض الأسعار',
      salesQuotationsReview: 'مراجعة عروض الأسعار',
      salesReview: 'مراجعة المبيعات',
      salesOrdersReview: 'مراجعة أوامر البيع',
      deliveryReview: 'مراجعة التسليمات',

      createSalesQuotation: 'عرض سعر جديد',

      salesOrders: 'أوامر البيع',

      deliveries: 'التسليم',
      createDelivery: 'إذن تسليم جديد',

      shippingDelivery: 'الشحن والتسليم',

      purchaseQuotations: 'مستندات الشحن',

      purchaseQuotationsReview: 'مراجعة الشحن',

      page: 'صفحة',

    },

    toolbar: {

      review: '📋 المراجعة',

      rules: '⚙️ القواعد',

      users: '👥 المستخدمون',

      signOut: 'تسجيل الخروج',

      switchToDark: 'التحويل للوضع الداكن',

      switchToLight: 'التحويل للوضع الفاتح',

      switchToArabic: 'التحويل إلى العربية',

      switchToEnglish: 'Switch to English',

    },

    login: {

      title: 'تسجيل الدخول',

      subtitle: 'SAP سير العمل · الإنتاج',

      username: 'اسم المستخدم',

      password: 'كلمة المرور',

      signIn: 'تسجيل الدخول',

      signingIn: 'جارٍ التسجيل…',

      loginFailed: 'فشل تسجيل الدخول',

    },

    home: {

      production: 'الإنتاج',

      productionDesc: 'إدارة إيصالات الإنتاج والعمليات المرتبطة بأوامر الإنتاج.',

      transfer: 'التحويل',

      transferDesc: 'إدارة تحويلات المخازن باستخدام مسح الباتشات.',

      quality: 'فحص الجودة',

      qualityDesc: 'إجراء فحوصات الجودة للخام والمنتج النهائي والتحقق من المطابقة.',

      grpo: 'الاستلام',

      grpoDesc: 'إدارة عمليات استلام البضائع والشحنات الواردة.',

      shippingReceivingTitle: 'الشحن والاستلام',

      shippingReceivingDesc: 'إدارة عمليات الشحن والاستلام، واستلام البضائع من الموردين، وعمليات التسليم.',

      customizationDeliveryTitle: 'التخصيص والتسليم',

      customizationDeliveryDesc: 'مراجعة عروض أسعار العملاء وأوامر البيع. للقراءة فقط.',

      description: 'اختر الوحدة المتاحة حسب دورك. يظل مسار العمل الحالي وفحوصات الصلاحيات كما هي.',

      open: 'فتح →',

    },

    rulesHub: {

      productionTitle: 'قواعد الإنتاج',

      productionDesc: 'إدارة قواعد أوامر الإنتاج والمستخدمين والمخازن الخاصة بالإيصالات.',

      transferTitle: 'قواعد التحويل',

      transferDesc: 'التحكم في صلاحيات مخازن التحويل من وإلى لكل مستخدم.',

    },

    transfer: {

      headerKicker: 'تحويل مخزون SAP',
      destinationSapBin: 'موقع Bin الوجهة في SAP',
      destinationSapLoadFailed: 'تعذر التحقق من متطلبات Bin الوجهة في SAP. أعد اختيار المخزن للمحاولة مجددًا.',
      destinationSapBinsUnavailable: 'هذا المخزن يتطلب موقع Bin في SAP، ولا توجد مواقع صالحة متاحة.',

      title: 'التحويل',

      stepStage: 'المرحلة',

      stepSource: 'المصدر',

      stepBatches: 'الباتشات',

      stepDestination: 'الوجهة',

      stepReview: 'المراجعة',

      stepDone: 'تم',

      stage1Badge: 'مرحلة 1',

      stage2Badge: 'مرحلة 2',

      stage3Badge: 'المرحلة 3',

      stage4Badge: 'المرحلة 4',

      stage5Badge: 'المرحلة 5',

      stage1Title: 'المحطة إلى الوسيط',

      stage2Title: 'الوسيط إلى الثلاجة',

      stage3Title: 'من الثلاجة / منصرف',

      stage4Title: 'من مخزن إلى مخزن',

      stage5Title: 'المخزن إلى حاوية الشحن',

      stage1Desc: 'من مخزن الإنتاج / المحطة إلى المخزن الوسيط',

      stage2Desc: 'من المخزن الوسيط إلى الثلاجة / المخزن البارد',

      stage3Desc: 'من مخزن الثلاجة إلى مخزن الوجهة',

      stage4Desc: 'نقل بين مخازن يختارها المستخدم وتسمح بها قواعد التحويل',

      stage5Desc: 'تحميل البالت من المخزن المحدد إلى حاوية الشحن (تحميل فعلي)',

      containerNotSapWarehouseNotice: 'حاوية الشحن مخصصة للحيازة الفعلية فقط وليست مخزنًا في SAP.',

      intermediateFixedSource: 'المخزن الوسيط',

      fromStation: 'من مخزن المحطة / الإنتاج',

      toIntermediate: 'إلى المخزن الوسيط',

      fromIntermediate: 'من المخزن الوسيط',

      toFridge: 'إلى مخزن الثلاجة',

      fromFridge: 'من مخزن الثلاجة',

      toDestination: 'إلى مخزن الوجهة',

      fromIntermediateWh: 'من المخزن الوسيط',

      toShippingHall: 'إلى صالة الشحن',

      fromShippingHall: 'من صالة الشحن',

      toContainer: 'إلى حاوية الشحن',

      containerNumber: 'رقم الحاوية',

      enterContainerNumber: 'أدخل رقم الحاوية',

      localPhysicalRecorded: 'تم تسجيل الحركة الفعلية المحلية بنجاح.',

      localLoadingRecorded: 'تم تسجيل تحميل الحاوية محلياً بنجاح.',

      confirmArrival: 'تأكيد الوصول',

      confirmLoad: 'تأكيد التحميل',

      inShippingHall: 'في صالة الشحن',

      loadedToContainer: 'تم التحميل في الحاوية',

      alreadyInShippingHall: 'الدفعة وصلت بالفعل إلى صالة الشحن.',

      alreadyLoadedToContainer: 'تم تحميل الدفعة بالفعل في الحاوية.',

      selectStageTitle: 'اختر مرحلة التحويل',

      selectSourceTitle: 'اختر المصدر',

      scanBatchesTitle: 'مسح الباتشات',

      selectDestinationTitle: 'اختر الوجهة',

      reviewSubmitTitle: 'مراجعة وإرسال',

      completeTitle: 'اكتمل التحويل',

      chooseTransferFlow: 'اختر مسار التحويل',

      selectSourceWarehouse: 'اختر مخزن المصدر',

      scanBatchNumbers: 'امسح أرقام الباتشات',

      chooseMoveTarget: 'اختر المكان الذي سيتم نقل المخزون إليه',

      selectDestinationWarehouse: 'اختر مخزن الوجهة',

      confirmTransferDetails: 'تأكد من تفاصيل التحويل',

      noWarehouseAccess: 'لا توجد مخازن مخصصة لهذا المستخدم. تواصل مع المدير.',

      fixedRouteNotConfigured: 'لم يتم إعداد مسار التحويل الخاص بك. تواصل مع المدير.',

      fromWarehouse: 'من مخزن',

      noWarehousesAvailable: 'لا توجد مخازن متاحة',

      fromBin: 'من خلية',

      selectSourceBin: 'اختر خلية المصدر',

      scanPlaceholder: 'امسح أو اكتب رقم الباتش ثم اضغط Enter',

      lookingUp: 'جارٍ البحث…',

      addBatch: 'إضافة باتش',

      colBatchNumber: 'رقم الباتش',

      colItemCode: 'كود الصنف',

      colItemName: 'اسم الصنف',

      colSourceStatus: 'حالة المصدر',

      colAvailable: 'المتاح',

      colUom: 'وحدة القياس',

      colExpiry: 'الصلاحية',

      colQtyToTransfer: 'كمية التحويل',

      removeLine: 'حذف السطر',

      removeBatch: (batch) => `حذف الباتش ${batch}`,

      localReceiptWarning: 'في انتظار اعتماد الإيصال. يمكن إرسال باتشات الإيصالات المحلية المعلقة كطلبات تحويل، لكن لا يمكن ترحيلها إلى SAP حتى يتم ترحيل إيصال المصدر.',

      noBatches: 'لم تتم إضافة باتشات بعد. امسح رقم باتش بالأعلى.',

      destinationType: 'نوع الوجهة',

      option1: 'اختيار 1',

      option2: 'اختيار 2',

      intermediateWarehouse: 'مخزن وسيط',

      fridgeStockingWarehouse: 'ثلاجة / مخزن تخزين',

      intermediateDesc: 'تحويل إلى مخزن عبور / وسيط آخر. لا يتطلب خلية.',

      fridgeDesc: 'تحويل إلى مخزن بارد أو مخزن تخزين مُدار بالخلايا. يتطلب خلية.',

      toFridgeStocking: 'إلى ثلاجة / مخزن تخزين',

      toWarehouse: 'إلى مخزن',

      toBin: 'إلى خلية',

      selectDestinationBin: 'اختر خلية الوجهة',

      visualMap: 'خريطة التخزين المرئية',

      dropdownView: 'قائمة منسدلة',

      mapView: 'خريطة الثلاجة',

      storageMapTitle: 'خريطة الثلاجة التفاعلية',

      selectedLocation: 'المكان المحدد للتسكين',

      noLocationSelected: 'لم يتم تحديد مكان بعد. اضغط على أي مكان تخزين في الخريطة أدناه.',

      absEntry: 'رقم SAP AbsEntry',

      sublevels: 'المسار الهيكلي',

      clearSelection: 'إلغاء التحديد',

      refreshMap: 'تحديث الخريطة',

      allAreas: 'كافة الثلاجات / المناطق',

      directBin: 'مكان تخزين عام / أرضي',

      corridorBin: 'طرقة / ممر',

      systemBinNotice: 'مكان نظام — غير مخصص للتخزين',

      binsCount: (n) => `${n} مكان`,

      sectionsCount: (n) => `${n} قسم/عنبر`,

      loadingHierarchy: 'جاري تحميل خريطة الثلاجة من SAP...',

      errorLoadingHierarchy: 'تعذر تحميل خريطة التخزين.',

      retry: 'إعادة المحاولة',

      emptyHierarchy: 'لا توجد خريطة تخزين مسجلة لهذا المخزن.',

      rack: 'رك / صف',

      chamber: 'عنبر / قسم',

      level: 'دور / مستوى',

      generalBin: 'مكان عام / أرضي',
      palletPositions: 'أماكن البليتات',
      palletPositionsInBin: (n) => `${n} مكان بليت`,
      position: 'مكان البليت',
      capacity: 'السعة الكلية',
      physicalCapacity: 'السعة الفعلية',
      unconfiguredCapacity: 'عمق غير محدد',
      unconfigured: 'غير محدد',
      sapBinOnly: 'موقع SAP',
      occupancy: 'نسبة الإشغال',
      statusAvailable: 'متاح',
      statusReserved: 'محجوز',
      statusOccupied: 'مشغول',
      statusReservedOutbound: 'محجوز للصرف',
      statusMaintenance: 'صيانة',
      statusSelected: 'محدد',
      selectPalletPosition: 'اختر مكان البليت',
      selectedPalletPosition: 'مكان البليت المحدد',
      sourcePalletPosition: 'موقع البالتة الفعلي (المصدر)',
      noPositionSelected: 'اضغط على مكان بليت متاح أدناه',
      reservePosition: 'حجز المكان',
      releaseReservation: 'إلغاء الحجز',
      reservingPosition: 'جارٍ الحجز...',
      releasingPosition: 'جارٍ إلغاء الحجز...',
      positionReservedSuccess: 'تم حجز مكان البليت بنجاح',
      positionConflictError: 'هذا المكان محجوز أو مشغول بالفعل. يرجى اختيار مكان آخر.',
      positionConflictOutbound: 'موقع البالتة المختار لم يعد متاحًا لهذا التحويل.',
      loadingLayout: 'جارٍ تحميل السعات وأماكن البليتات...',
      backToRacks: '← العودة للراكات',
      allocatable: 'قابل للتسكين',
      stagingOnly: 'وسيط / نقل فقط',
      nonAllocatable: 'غير قابل للتسكين',
      binStagingOnlyNotice: 'هذا الموقع وسيط/طرقة فقط ولا يمكن تسكين البليتات فيه للتخزين.',
      binNonAllocatableNotice: 'هذا الموقع غير قابل للتسكين.',
      binUnconfiguredNotice: 'هذا الموقع لم يتم تحديد سعته وتكوينه بعد.',
      physicalPosition: 'الموقع الفعلي',
      pleaseSelectPalletPosition: 'يرجى اختيار موقع البالتة داخل الثلاجة.',
      pleaseSelectSourcePalletPosition: 'يجب اختيار موقع البالتة الفعلي من خريطة الثلاجة.',
      batchNumber: 'رقم التشغيلة',
      transferRef: 'مرجع التحويل',
      sequentialPalletCount: 'التسكين بالترتيب المتتابع (عدد البالتات):',
      previewSequential: 'معاينة الترتيب',
      confirmSequential: 'تأكيد التسكين المتتابع',
      required: 'المطلوب',
      available: 'المتاح',
      shortage: 'العجز',
      sequenceOrder: 'الترتيب المتتابع',

      transferStage: 'مرحلة التحويل',

      reviewId: 'رقم المراجعة',

      docEntry: 'رقم المرجع',

      docNum: 'DocNum',

      movementReference: 'مرجع الحركة',

      from: 'من',

      to: 'إلى',

      stage: 'المرحلة',

      qtyTransferred: 'الكمية المحولة',

      createInventoryTransfer: 'إنشاء تحويل مخزون',

      submitForReview: 'إرسال للمراجعة',

      postingToSap: 'جارٍ الترحيل إلى SAP...',

      submitting: 'جارٍ الإرسال...',

      submittedForReview: 'تم إرسال التحويل لمراجعة المدير.',

      mockCreated: 'تم إنشاء تحويل مخزون تجريبي.',

      postedSuccessfully: 'تم ترحيل تحويل المخزون إلى SAP بنجاح.',

      newTransfer: 'تحويل جديد',

      back: 'رجوع',

      next: 'التالي',

      status: {

        pendingTransferChain: 'بانتظار سلسلة التحويل',

        sapAvailable: 'متاح في SAP',

        sapPosted: 'تم الترحيل / موجود في SAP',

        localPendingReceipt: 'إيصال محلي معلق',

        localPostedReceipt: 'في انتظار الإتاحة في SAP',

        notFound: 'غير موجود',

        waitingApproval: 'في انتظار اعتماد الإيصال',

      },

      errors: {

        selectFromWarehouse: 'اختر مخزن المصدر قبل المسح.',

        enterBatch: 'أدخل رقم باتش للمسح.',

        duplicateBatch: (batch) => `الباتش "${batch}" موجود بالفعل في سطور التحويل.`,

        notFound: (batch, warehouse) => `غير موجود: لم يتم العثور على الباتش "${batch}" في SAP أو باتشات الإيصالات المحلية للمخزن ${warehouse}.`,

        lookupFailed: (batch) => `فشل البحث عن الباتش "${batch}".`,

        transferFailed: 'فشل التحويل. حاول مرة أخرى.',

      },

    },

    transferReview: {

      title: 'مراجعة التحويلات',

      adminReview: 'مراجعة المدير',

      myTransfers: 'تحويلاتي',

      refresh: 'تحديث',

      refreshing: 'جارٍ التحديث...',

      postSelected: (n) => `ترحيل المحدد (${n})`,

      pendingTransfers: 'تحويلات معلقة',

      failedTransfers: 'تحويلات فاشلة',

      totalTransfers: 'إجمالي التحويلات',

      selected: 'المحدد',

      status: 'الحالة',

      pending: 'قيد الانتظار',

      posted: 'تم الترحيل',

      failed: 'فشل',

      allStatuses: 'كل الحالات',

      search: 'بحث',

      searchPlaceholder: 'باتش، صنف، مخزن، مستخدم',

      type: 'النوع',

      typeInternal: 'تحويل داخلي',

      typeShipping: 'الشحن / الدليفري',

      toOrContainer: 'إلى / الحاوية',

      container: 'الحاوية',

      itemAndQty: 'الصنف / الكمية',

      reference: 'المرجع',

      allStages: 'جميع المراحل',

      stageFilter: 'المرحلة',

      loadedToContainer: 'تم التحميل بالحاوية',

      stage1Short: 'المرحلة 1',

      stage2Short: 'المرحلة 2',

      stage3Short: 'المرحلة 3',

      stage4Short: 'المرحلة 4',

      stage5Short: 'المرحلة 5',

      fromFilter: 'من',

      toFilter: 'إلى',

      allFrom: 'كل المصادر',

      allTo: 'كل الوجهات',

      clear: 'مسح',

      loading: 'جارٍ تحميل طلبات التحويل...',

      empty: 'لا توجد عمليات نقل للمراجعة.',

      loadFailed: 'فشل تحميل طلبات التحويل.',

      saveFailed: 'فشل الحفظ.',

      postFailed: 'فشل ترحيل التحويل.',

      deleteFailed: 'فشل حذف التحويل.',

      deleteConfirm: (label) => `حذف ${label}؟\n\nسيتم حذف طلب التحويل هذا فقط. طلبات التحويل الأخرى لن تتأثر.`,

      deleting: 'جارٍ الحذف...',

      selectAllPostable: 'تحديد كل صفوف التحويل القابلة للترحيل',

      source: 'المصدر',

      stage: 'المرحلة',

      fromWh: 'من مخزن',

      fromBin: 'من خلية',

      toWh: 'إلى مخزن',

      toBin: 'إلى خلية',

      batch: 'الباتش',

      itemCode: 'كود الصنف',

      itemName: 'اسم الصنف',

      qty: 'الكمية',

      by: 'بواسطة',

      created: 'تاريخ الإنشاء',

      sapDocEntry: 'Reference Number',

      sapDocNum: 'SAP DocNum',

      errorReason: 'سبب الخطأ',

      actions: 'الإجراءات',

      reservedOutboundTitle: 'مواقع الصرف المحجوزة',

      reservedOutboundDescription: 'مواقع فعلية تنتظر نجاح SAP أو إعادة المحاولة أو إلغاء التحويل. تظهر الحجوزات الأقدم أولاً.',

      reservedOutboundLoading: 'جارٍ تحميل مواقع الصرف المحجوزة...',

      reservedOutboundEmpty: 'لا توجد مواقع محجوزة للصرف.',

      reservedOutboundLoadFailed: 'فشل تحميل مواقع الصرف المحجوزة.',

      physicalPosition: 'الموقع الفعلي',

      reservationReference: 'مرجع الحجز',

      reservedBy: 'حجزه',

      reservedAt: 'وقت الحجز',

      reconciliationRequired: 'مطلوب تسوية المواقع',

      reconciliationCompleted: 'تمت تسوية المواقع',

      retryReconciliation: 'إعادة محاولة المواقع',

      reconciling: 'جارٍ إعادة المحاولة...',

      reconciliationFailed: 'فشلت تسوية المواقع.',

      sourcePositionState: 'موقع المصدر',

      destinationPositionState: 'موقع الوجهة',

      sourceSapBin: 'خلية SAP المصدر',

      save: 'حفظ',

      saving: 'جارٍ الحفظ...',

      saved: 'تم الحفظ',

      post: 'ترحيل',

      posting: 'جارٍ الترحيل...',

      readOnly: 'قراءة فقط',

      stage1: 'مرحلة 1 - من المحطة إلى الوسيط',

      stage2: 'مرحلة 2 - من الوسيط إلى الثلاجة',

      stage3: 'مرحلة 3 - من الثلاجة / منصرف',
      stage4: 'مرحلة 4 - من مخزن إلى مخزن',
      stage5: 'مرحلة 5 - من المخزن إلى حاوية الشحن',

      sourcePosition: 'موقع البالتة المصدر',

    },

    transferRules: {

      title: 'قواعد التحويل',

      admin: 'مدير',

      back: 'رجوع',

      users: 'المستخدمون',

      user: 'المستخدم',

      loadingUsers: 'جارٍ تحميل المستخدمين...',

      noUsers: 'لا يوجد مستخدمون.',

      rulesCount: (n) => `${n} ${n === 1 ? 'قاعدة' : 'قواعد'}`,

      allowedStages: 'مراحل التحويل المسموحة',

      bothStages: 'كل المراحل',

      allowedFrom: 'المخازن المسموحة كمصدر',

      allowedTo: 'المخازن المسموحة كوجهة',

      loadingWarehouses: 'جارٍ تحميل المخازن...',

      noWarehouses: 'لا توجد مخازن.',

      saving: 'جارٍ الحفظ...',

      saveAccess: 'حفظ صلاحيات مخازن التحويل',

      currentRules: 'القواعد الحالية',

      warehouse: 'المخزن',

      direction: 'الاتجاه',

      stage: 'المرحلة',

      status: 'الحالة',

      active: 'مفعّل',

      inactive: 'غير مفعّل',

      delete: 'حذف',

      loadFailed: 'فشل تحميل قواعد التحويل.',

      saved: 'تم حفظ صلاحيات مخازن التحويل.',

      saveFailed: 'فشل حفظ قواعد التحويل.',

      fixedRouteRequired: 'اختر مخزن مصدر واحد ومخزن وجهة واحد فقط لمسار المستخدم.',
      stage5SourceRequired: 'اختر مخزن مصدر مسموحًا واحدًا على الأقل للمرحلة 5.',

      deleted: 'تم حذف القاعدة.',

      deleteFailed: 'فشل حذف القاعدة.',

    },

    production: {

      moduleTitle: 'الإنتاج',

      title: 'إيصال من الإنتاج',

      desc: 'بدء استلام البضاعة المنتجة من أمر إنتاج.',

      start: 'بدء الإيصال →',


      issueTitle: 'صرف للإنتاج',

      issueDesc: 'صرف المواد الخام والمكونات لأوامر الإنتاج المطلقة.',

      issueStart: 'بدء الصرف ←',

      issueReviewTitle: 'مراجعة أوامر الصرف',

      issueReviewDesc: 'مراجعة أوامر الصرف المعلقة ورفضها أو اعتمادها وترحيلها إلى SAP.',

      issueReviewStart: 'مراجعة الطلبات ←',
    },

    issueWizard: {
      title: 'صرف للإنتاج',
      pageTitle: 'صرف للإنتاج',
      pageDesc: 'إعداد وتقديم مسودة صرف للإنتاج لمراجعة مسؤول الإنتاج',
      step1: 'أمر الإنتاج',
      step1Desc: 'اختر أمر إنتاج مطلق',
      step2: 'المكونات',
      step2Desc: 'تحديد البنود والكميات',
      step3: 'تخصيص المخزون',
      step3Desc: 'التشغيلات والمواقع',
      step4: 'بيانات المستند',
      step4Desc: 'التواريخ والملاحظات',
      step5: 'المراجعة والحفظ',
      step5Desc: 'إرسال للمراجعة',
      searchOrder: 'البحث برقم الأمر، اسم المنتج، أو كود الصنف...',
      loadingOrders: 'جاري تحميل أوامر الإنتاج...',
      noOrders: 'لا توجد أوامر إنتاج مطلقة متاحة.',
      noOrdersFiltered: 'لا توجد أوامر مطابقة لفلتر البحث الحالي.',
      orderNumber: 'رقم الأمر',
      product: 'المنتج',
      plannedQty: 'الكمية المخططة',
      completedQty: 'الكمية المنجزة',
      remainingQty: 'الكمية المتبقية',
      issuedQty: 'المنصرف سابقاً',
      issueQty: 'كمية الصرف',
      dueDate: 'تاريخ الاستحقاق',
      postingDate: 'تاريخ الترحيل',
      documentDate: 'تاريخ المستند',
      warehouse: 'المستودع',
      status: 'الحالة',
      released: 'مطلق',
      selectedOrder: 'أمر الإنتاج المحدد',
      loadingOrderDetails: 'جاري تحميل سطور المكونات من SAP...',
      noComponents: 'لا يحتوي أمر الإنتاج هذا على سطور مكونات في SAP.',
      selectComponentsTitle: 'تحديد المكونات المراد صرفها',
      selectComponentsDesc: 'اختر المكونات وأدخل كميات الصرف المطلوبة.',
      selectAll: 'تحديد الكل',
      deselectAll: 'إلغاء تحديد الكل',
      itemCode: 'كود الصنف',
      itemName: 'وصف الصنف',
      uom: 'وحدة القياس',
      issueType: 'طريقة الصرف',
      invalidQty: 'الكمية يجب أن تكون أكبر من 0 وأقل من أو تساوي المتبقي',
      atLeastOneComponent: 'يرجى تحديد مكون واحد على الأقل للصرف.',
      allocationTitle: 'تخصيص تشغيلات ومواقع المخزون',
      allocationDesc: 'تخصيص التشغيلات ومواقع التخزين للمكونات المحددة.',
      batchNumber: 'رقم التشغيلة',
      binLocation: 'موقع التخزين (Bin)',
      allocatedQty: 'الكمية المخصصة',
      addSplit: 'إضافة تقسيم تخصيص',
      removeSplit: 'حذف التقسيم',
      lookupBatch: 'فحص',
      batchAvailable: 'المتاح في التشغيلة',
      noBatchRequired: 'صنف قياسي (بدون تشغيلة / موقع)',
      remainingToAllocate: 'المتبقي للتخصيص',
      allocatedExact: 'التخصيص مطابق لكمية الصرف',
      allocationMismatch: 'إجمالي التخصيص لا يساوي كمية الصرف',
      availableBatchesTitle: 'التشغيلات المتاحة في SAP',
      loadingBatches: 'جاري تحميل التشغيلات المتاحة من SAP...',
      noBatchesFound: 'لا توجد تشغيلات برصيد متاح لهذا الصنف في المستودع',
      systemBinBadge: 'موقع نظام',
      storageBinBadge: 'موقع تخزين',
      autoAllocateBtn: 'تخصيص تلقائي',
      splitAllocationBtn: 'إضافة تقسيم',
      selectBinTitle: 'اختر موقع التخزين (Bin)',
      availableStock: 'الرصيد المتاح',
      expiryDate: 'تاريخ الصلاحية',
      mfrDate: 'تاريخ الإنتاج',
      comments: 'الملاحظات',
      journalMemo: 'بيان القيد',
      reviewTitle: 'مراجعة مسودة الصرف',
      reviewDesc: 'تحقق من كافة التفاصيل قبل الإرسال لمراجعة مسؤول الإنتاج.',
      reviewNotice: 'حفظ هذا المستند يرسله إلى مراجعة مسؤول الإنتاج. لن يتم إرساله إلى SAP حتى تتم الموافقة عليه.',
      submitForReview: 'إرسال للمراجعة',
      submitting: 'جاري إرسال المسودة...',
      successTitle: 'تم تقديم المسودة للمراجعة بنجاح!',
      successDesc: 'تم حفظ مسودة الصرف محلياً. وهي الآن بانتظار مراجعة وترحيل مسؤول الإنتاج.',
      pendingReview: 'قيد المراجعة',
      pendingIssueId: 'رقم مسودة الصرف',
      submittedBy: 'مقدم الطلب',
      submissionTime: 'وقت التقديم',
      totalComponents: 'إجمالي المكونات',
      totalQuantity: 'إجمالي الكمية',
      issueAnother: 'صرف أمر إنتاج آخر',
      backToProduction: 'العودة للإنتاج',
      previousBtn: 'السابق',
      nextBtn: 'التالي',
      noBins: 'لا توجد مواقع مهيأة',
      selectBin: 'اختر موقع التخزين',
      autoAssignedBin: 'موقع التخزين المحدد',
      selectBatchFirst: 'اختر أو أدخل رقم التشغيلة لعرض موقع التخزين',
      noBinForBatch: 'لا يوجد موقع تخزين مهيأ لهذه التشغيلة',
      multipleBinsNotice: 'اختر موقع التخزين المراد الصرف منه',
    },

    issueReview: {
      title: 'مراجعة أوامر الصرف للإنتاج',
      pageTitle: 'مراجعة أوامر الصرف للإنتاج',
      pageDesc: 'مراجعة مسودات أوامر الصرف ورفضها أو اعتمادها وترحيلها إلى SAP Business One',
      filterStatus: 'تصفية الحالة',
      allStatuses: 'جميع الحالات',
      pendingReview: 'قيد المراجعة',
      posting: 'جاري الترحيل',
      posted: 'تم الترحيل',
      failed: 'فشل الترحيل',
      rejected: 'مرفوض',
      searchPlaceholder: 'بحث برقم الأمر أو المنتج أو رقم المسودة...',
      noIssues: 'لا توجد أوامر صرف معلقة.',
      noIssuesFiltered: 'لا توجد نتائج تطابق معايير التصفية المحددة.',
      loadingIssues: 'جاري تحميل أوامر الصرف...',
      errorLoading: 'فشل تحميل أوامر الصرف.',
      colId: '#',
      colStatus: 'الحالة',
      colOrderNum: 'رقم الأمر',
      colProduct: 'المنتج التام',
      colComponents: 'المكونات',
      colQuantity: 'كمية الصرف',
      colCreatedBy: 'تم الإنشاء بواسطة',
      colCreatedAt: 'تاريخ الإنشاء',
      colActions: 'الإجراءات',
      actionReview: 'مراجعة',
      backToList: 'العودة إلى قائمة الأوامر',
      backToProduction: 'العودة إلى الإنتاج',
      localPendingNotice: 'أمر صرف معلق محلياً — غير مسجل في SAP',
      localPendingDesc: 'تم حفظ هذا المستند محلياً كمراجعة. لن يتم تعديل المخزون في SAP حتى تتم الموافقة عليه وترحيله.',
      postedNotice: 'تم الترحيل إلى SAP Business One',
      postedDesc: 'تم ترحيل مستند صرف البضاعة بنجاح إلى SAP Business One.',
      postingNotice: 'جاري الترحيل إلى SAP...',
      postingDesc: 'جاري معالجة المعاملة والترحيل إلى SAP Business One.',
      rejectedNotice: 'تم رفض أمر الصرف',
      rejectedDesc: 'تم رفض هذا الطلب بواسطة مسؤول الإنتاج ولا يمكن ترحيله.',
      failedNotice: 'فشل الترحيل إلى SAP',
      failedDesc: 'أرجع نظام SAP خطأ أثناء إنشاء المستند. يمكنك مراجعة التفاصيل أدناه وإعادة المحاولة.',
      sapDetailsTitle: 'بيانات مستند SAP',
      sapDocNum: 'رقم مستند SAP',
      sapDocEntry: 'معرف المستند في SAP',
      postedBy: 'تم الترحيل بواسطة',
      postedAt: 'تاريخ الترحيل',
      orderInfoTitle: 'بيانات أمر الإنتاج',
      issueId: 'رقم المسودة',
      orderNumber: 'رقم أمر الإنتاج',
      orderDocEntry: 'معرف أمر الإنتاج',
      finishedProduct: 'المنتج المستهدف',
      orderStatusAtSubmit: 'حالة الأمر وقت التقديم',
      postingDate: 'تاريخ الترحيل',
      documentDate: 'تاريخ المستند',
      createdBy: 'تم الإنشاء بواسطة',
      createdAt: 'تاريخ الإنشاء',
      reviewedBy: 'تمت المراجعة بواسطة',
      reviewedAt: 'تاريخ المراجعة',
      comments: 'التعليقات',
      journalMemo: 'البيان المحاسبي',
      componentsTitle: 'بنود المكونات',
      componentsSubtitle: 'المكونات المطلوب صرفها لأمر الإنتاج هذا',
      colLineNum: 'رقم السطر',
      colItemCode: 'كود الصنف',
      colItemName: 'اسم الصنف',
      colWarehouse: 'المستودع',
      colIssueType: 'نوع الصرف',
      colUom: 'الوحدة',
      colPlannedQty: 'الكمية المخططة',
      colIssuedQty: 'المصروف وقت التقديم',
      colRemainingQty: 'المتبقي وقت التقديم',
      colIssueQty: 'كمية الصرف',
      allocationsTitle: 'تخصيصات المخزون (التشغيلات والمواقع)',
      allocationsSubtitle: 'التشغيلات وأماكن التخزين المخصصة لكل مكون',
      colBatch: 'رقم التشغيلة',
      colBin: 'مكان التخزين',
      colAllocQty: 'الكمية المخصصة',
      allocMatch: 'التخصيص مطابق',
      allocMismatch: 'التخصيص غير مطابق',
      standardNoAlloc: 'صنف قياسي — لا يتطلب تخصيص تشغيلة أو موقع',
      actionReject: 'رفض',
      actionApprovePost: 'الموافقة والترحيل إلى SAP',
      actionPosting: 'جاري الترحيل إلى SAP...',
      actionRetry: 'إعادة محاولة الترحيل',
      rejectModalTitle: 'رفض أمر الصرف للإنتاج',
      rejectReasonLabel: 'سبب الرفض (مطلوب)',
      rejectReasonPlaceholder: 'أدخل سبب رفض أمر الصرف هذا...',
      rejectConfirmBtn: 'تأكيد الرفض',
      rejectCancelBtn: 'إلغاء',
      rejectSuccessMsg: 'تم رفض أمر الصرف بنجاح.',
      approveModalTitle: 'الموافقة والترحيل إلى SAP Business One',
      approveWarning: 'هل أنت متأكد من رغبتك في الموافقة على أمر الصرف هذا وإرساله إلى SAP Business One؟',
      approveIrreversibleNotice: 'بمجرد الترحيل، سيتم إنشاء مستند صرف بضاعة (InventoryGenExits) في SAP Business One، ولا يمكن تعديل هذه المعاملة أو رفضها بعد الترحيل.',
      approveOrderRecap: 'أمر الإنتاج',
      approveProductRecap: 'المنتج التام',
      approveQtyRecap: 'إجمالي كمية الصرف',
      approveComponentsRecap: 'إجمالي المكونات',
      approveConfirmBtn: 'تأكيد والترحيل إلى SAP',
      approveCancelBtn: 'إلغاء',
      postSuccessMsg: 'تم ترحيل أمر الصرف للإنتاج بنجاح إلى SAP Business One.',
      postFailureTitle: 'فشل عملية الترحيل',
      postFailureMsg: 'فشل ترحيل أمر الصرف إلى SAP Business One.',
      rejectionReasonDisplay: 'سبب الرفض:',
      ambiguousNotice: 'فشل غير مؤكد في SAP — يلزم التحقق قبل إعادة الترحيل',
      ambiguousDesc: 'قد يكون الطلب قد وصل إلى SAP على الرغم من عدم تلقي استجابة قاطعة. يلزم التحقق قبل إعادة المحاولة.',
      ambiguousErrorNotice: 'قد يكون الطلب قد وصل إلى SAP على الرغم من عدم تلقي استجابة قاطعة.',
      actionReconcile: 'التحقق من حالة SAP',
      actionReconciling: 'جاري التحقق من SAP...',
      reconcileModalTitle: 'التحقق من حالة أمر الصرف في SAP Business One',
      reconcileModalDesc: 'سيتحقق النظام من SAP Business One للتأكد مما إذا كان قد تم إنشاء مستند صرف بضاعة (InventoryGenExits) بالفعل لهذا الأمر.',
      reconcilePoint1: 'إذا تم العثور على المستند، سيتم ربط أمر الصرف المحلي به وتحديث حالته إلى تم الترحيل.',
      reconcilePoint2: 'إذا لم يتم العثور عليه، سيتم إزالة حالة عدم التأكد وإتاحة إعادة المحاولة بأمان.',
      reconcilePoint3: 'إذا تعذر الاتصال بـ SAP، سيظل أمر الصرف محظوراً حتى استعادة الاتصال.',
      reconcileConfirmBtn: 'بدء التحقق من SAP',
      reconcileCancelBtn: 'إلغاء',
      reconcileSuccessFound: 'تم العثور على مستند SAP موجود وتم ربطه بنجاح.',
      reconcileSuccessCleared: 'لم يتم العثور على إذن صرف في SAP. تم تجهيز أمر الصرف لإعادة المحاولة بأمان.',
      reconcileErrorUnreachable: 'تعذر الاتصال بـ SAP. يرجى إعادة محاولة التحقق لاحقاً.',
      reconcileManualToggle: 'أو إدخال أرقام مستند SAP المؤكدة يدوياً',
      reconcileManualDocEntry: 'رقم DocEntry في SAP (اختياري)',
      reconcileManualDocNum: 'رقم المستند DocNum في SAP (اختياري)',
      reconcileManualSubmitBtn: 'ربط مستند SAP اليدوي',
    },

    createUser: {

      title: 'إنشاء مستخدم',

      username: 'اسم المستخدم',

      password: 'كلمة المرور',

      warehouse: 'المخزن',

      role: 'الدور',

      roleUser: 'مستخدم',

      roleAdmin: 'مدير',

      selectWarehouse: '— اختر المخزن —',

      loadingWarehouses: 'جارٍ التحميل…',

      creating: 'جارٍ الإنشاء…',

      createUser: 'إنشاء مستخدم',

      back: '→ رجوع',

      created: (username) => `تم إنشاء المستخدم "${username}" بنجاح.`,

    },

    users: {

      title: 'إدارة المستخدمين',

      newUser: '+ مستخدم جديد',
      activityLog: 'سجل النشاط',

      totalUsers: 'إجمالي المستخدمين',

      active: 'مفعّل',

      disabled: 'معطّل',

      loadingUsers: 'جارٍ تحميل المستخدمين…',

      noUsers: 'لا يوجد مستخدمون.',

      colUsername: 'اسم المستخدم',

      colRole: 'الدور',

      colWarehouse: 'المخزن',

      colStatus: 'الحالة',

      colJoined: 'تاريخ الإنشاء',

      colActions: 'الإجراءات',

      you: '(أنت)',

      editBtn: '✏️ تعديل',

      disableBtn: '⊘ تعطيل',

      enableBtn: '✓ تفعيل',

      statusActive: '● مفعّل',

      statusDisabled: '○ معطّل',

      roleAdmin: '⭐ مدير',

      roleUser: '👤 مستخدم',

      createModal: 'إنشاء مستخدم جديد',

      editModal: (username) => `تعديل — ${username}`,

      deleteModal: 'حذف مستخدم',

      username: 'اسم المستخدم',

      password: 'كلمة المرور',

      role: 'الدور',

      warehouse: 'المخزن',

      optionalForAdmins: '(اختياري للمديرين)',

      selectWarehouse: '— اختر المخزن —',

      noWarehouse: '— بدون مخزن —',

      accountActive: 'الحساب مفعّل',

      changePassword: 'تغيير كلمة المرور (اختياري)',

      newPassword: 'كلمة المرور الجديدة',

      confirmPassword: 'تأكيد كلمة المرور الجديدة',

      leaveBlank: 'اتركه فارغًا للإبقاء على كلمة المرور الحالية',

      repeatPassword: 'كرر كلمة المرور الجديدة',

      passwordMismatch: 'كلمتا المرور غير متطابقتين',

      roleUser: 'مستخدم',

      roleAdmin: 'مدير',

      warehouseRequired: 'المخزن مطلوب للمستخدمين العاديين.',

      cancel: 'إلغاء',

      creating: 'جارٍ الإنشاء…',

      createUser: 'إنشاء مستخدم',

      saving: 'جارٍ الحفظ…',

      saveChanges: 'حفظ التعديلات',

      deleteConfirm: (username) => `هل أنت متأكد من الحذف النهائي لـ `,

      deleteUsername: (username) => username,

      deleteWarn: '⚠️ لا يمكن التراجع عن هذا الإجراء. استخدم',

      deleteWarnDisable: 'تعطيل',

      deleteWarnSuffix: 'للحفاظ على سجل المستخدم وقواعد الخصائص.',

      deleting: 'جارٍ الحذف…',

      deleteBtn: '🗑️ حذف نهائي',

      userUpdated: 'تم تحديث المستخدم بنجاح.',

      created: (username) => `تم إنشاء المستخدم "${username}".`,

      confirmMustMatch: 'يرجى تأكيد كلمة المرور الجديدة',

      enterPassword: 'يرجى إدخال كلمة المرور الجديدة',

      passwordTooShort: 'كلمة المرور يجب أن تكون 4 أحرف على الأقل',

    },
    audit: {
      title: 'سجل النشاط',
      subtitle: 'سجل تدقيق شامل لعمليات النظام وأنشطة المستخدمين وترحيلات SAP',
      filterSearch: 'بحث في الوصف، رقم المرجع، أو التفاصيل…',
      filterModule: 'الوحدة',
      filterAction: 'نوع الإجراء',
      filterStatus: 'الحالة',
      filterUser: 'المستخدم',
      filterDateFrom: 'من تاريخ',
      filterDateTo: 'إلى تاريخ',
      allModules: 'جميع الوحدات',
      allActions: 'جميع الإجراءات',
      allStatuses: 'جميع الحالات',
      allUsers: 'جميع المستخدمين',
      clearFilters: 'إعادة ضبط الفلاتر',
      refresh: 'تحديث',
      colTimestamp: 'التاريخ والوقت',
      colUser: 'المستخدم',
      colModule: 'الوحدة',
      colAction: 'الإجراء',
      colEntity: 'المرجع',
      colDescription: 'الوصف',
      colStatus: 'الحالة',
      colIp: 'عنوان IP',
      colDetails: 'التفاصيل',
      viewDetails: 'عرض التفاصيل',
      detailsTitle: 'تفاصيل النشاط',
      close: 'إغلاق',
      metadata: 'البيانات الوصفية',
      noChangesRecorded: 'لا توجد فروقات مسجلة للحالة السابقة واللاحقة.',
      businessDetailsTitle: 'تفاصيل العملية',
      changesTitle: 'التغييرات',
      noAdditionalDetails: 'لا توجد تفاصيل إضافية لهذه العملية.',
      detailUnknownField: 'معلومة إضافية',
      valueYes: 'نعم',
      valueNo: 'لا',
      detailFields: {
        item_code: 'كود الصنف', item_name: 'اسم الصنف', order_number: 'رقم أمر الإنتاج', production_order: 'أمر الإنتاج',
        final_quantity: 'الكمية النهائية', warehouse: 'المخزن', warehouse_code: 'كود المخزن', warehouse_name: 'اسم المخزن',
        vehicle_number: 'رقم السيارة', car_number: 'رقم السيارة', container_number: 'رقم الحاوية', container_quantity: 'عدد الحاويات',
        batch_number: 'رقم الباتش', batch_numbers: 'أرقام الباتشات', batch: 'الباتش', from_warehouse: 'المخزن المصدر', to_warehouse: 'المخزن المستهدف',
        from_bin: 'الموقع المصدر', to_bin: 'الموقع المستهدف', source_bin: 'الموقع المصدر', source_pallet_position: 'موقع البالتة المصدر',
        source_pallet_position_code: 'كود موقع البالتة', pallet_position: 'موقع البالتة', pallet_position_code: 'كود موقع البالتة',
        transfer_reference: 'مرجع التحويل', reservation_reference: 'مرجع الحجز', reference: 'المرجع',
        sap_document_entry: 'رقم إدخال مستند SAP', sap_document_number: 'رقم مستند SAP', sap_doc_entry: 'رقم إدخال مستند SAP',
        sap_doc_num: 'رقم مستند SAP', sap_receipt_doc_num: 'رقم استلام SAP', quantity: 'الكمية', total_quantity: 'الكمية الإجمالية',
        uom: 'وحدة القياس', uom_code: 'وحدة القياس', reason: 'السبب', notes: 'الملاحظات', status: 'الحالة', username: 'المستخدم',
        role: 'الدور', is_active: 'الحساب نشط', transfer_stage: 'مرحلة التحويل', draft_number: 'رقم المسودة', first_weight: 'الوزن الأول',
        second_weight: 'الوزن الثاني', product_weight: 'وزن المنتج', card_code: 'كود شريك الأعمال', vendor_card_code: 'كود المورد',
        vendor_name: 'اسم المورد', target_warehouse: 'المخزن المستهدف', updated_fields: 'الحقول التي تغيرت',
        attempted_username: 'اسم المستخدم في محاولة الدخول', target_pallet_position: 'موقع البالتة المستهدف', draft_id: 'معرف المسودة', stage: 'مرحلة الفحص',
        capacity: 'السعة', allocation_type: 'نوع التخصيص', channel_type: 'نوع القناة',
      },
      emptyTitle: 'لا توجد أنشطة مسجلة',
      emptySubtitle: 'جرب تعديل خيارات البحث أو تصفية الفلاتر.',
      loading: 'جارٍ تحميل سجل النشاط…',
      errorLoading: 'تعذر تحميل سجل النشاط.',
      showingCount: 'عرض {from} - {to} من أصل {total} عملية',
      page: 'صفحة',
      prev: 'السابق',
      next: 'التالي',
      first: 'الأولى',
      last: 'الأخيرة',
      diffField: 'الحقل',
      diffBefore: 'قبل التغيير',
      diffAfter: 'بعد التغيير',
      modAuth: 'تسجيل الدخول والأمان',
      modUsers: 'إدارة المستخدمين',
      modTransfer: 'تحويل المخزون',
      modColdStorage: 'المخازن والتبريد',
      modQuality: 'فحص الجودة',
      modGrpo: 'استلام المشتريات (GRPO)',
      modPurchaseQuotation: 'عروض أسعار المشتريات',
      modScale: 'ميزان الشاحنات',
      modProductionReceipt: 'استلامات الإنتاج',
      actLogin: 'تسجيل دخول',
      actLogout: 'تسجيل خروج',
      actCreate: 'إنشاء',
      actUpdate: 'تعديل',
      actDelete: 'حذف',
      actApprove: 'اعتماد',
      actReject: 'رفض',
      actPost: 'ترحيل SAP',
      actCancel: 'إلغاء',
      actReserve: 'حجز',
      actRelease: 'تحرير',
      actOccupy: 'إشغال',
      actVacate: 'إخلاء',
      actConfigure: 'ضبط وتهيئة',
      actWeigh: 'تسجيل وزن',
      statusSuccess: 'ناجح',
      statusFailed: 'فشل',
      statusWarning: 'تنبيه',
    },


    wizard: {

      step1: 'الخطوة 1 من 5',

      step2: (num) => `الخطوة 2 من 5 · أمر ${num}`,

      step3: (units, uom, wh) => `الخطوة 3 من 5 · ${units} ${uom} · ${wh}`,

      step4: 'الخطوة 4 من 5',

      step5: 'الخطوة 5 من 5',

      tapCard: 'اضغط على بطاقة — سيتم التحميل والانتقال للخطوة التالية تلقائيًا.',

      enterUnits: 'أدخل عدد الوحدات المراد استلامها، ثم اختر وحدة القياس.',

      completeBatch: 'أكمل كل باتش خطوة بخطوة. عندما تظهر ✅ على كل الباتشات يمكنك المتابعة.',

      reviewDesc: 'تحقق من كل شيء أدناه، ثم أرسل للمراجعة. سيقوم المدير بالموافقة والترحيل إلى SAP.',

      filterPlaceholder: 'فلترة برقم الأمر أو كود الصنف أو الاسم…',

      clearFilters: 'مسح',

      loadingOrders: 'جارٍ تحميل الأوامر…',

      noOrders: 'لا توجد أوامر إنتاج مفتوحة.',

      noOrdersFiltered: 'لا توجد أوامر تطابق الفلاتر الحالية.',

      orderLabel: (num) => `أمر ${num}`,

      loadingOrderDetails: 'جارٍ تحميل تفاصيل الأمر…',

      loadingOrderData: 'جارٍ تحميل بيانات الأمر…',

      unitsLabel: 'عدد الوحدات (1 – 150)',

      maxUnits: 'الحد الأقصى 150 وحدة',

      searchUom: 'بحث بالاسم أو الرقم…',

      loadingUom: 'جارٍ تحميل وحدات القياس…',

      noUom: 'لا تتوفر وحدة قياس بالوزن لهذا الأمر.',

      selectUom: 'يرجى اختيار وحدة قياس',

      nextBtn: 'التالي →',

      totalBatchUnits: 'إجمالي وحدات الباتش',

      batchLabel: (n) => `باتش ${n}`,

      autoGenerated: 'سيتم التوليد تلقائيًا عند الإرسال',

      editBtn: 'تعديل',

      removeBtn: 'حذف',

      duplicateBatch: 'تكرار هذا الباتش بنفس القيم',

      noBins: 'لا توجد مواقع تخزين — تجاوز إذا لم يكن مطلوبًا.',

      loadingBins: 'جاري تحميل مواقع التخزين…',

      binsUnavailable: 'تعذر تحميل مواقع التخزين',

      searchBins: 'بحث في المواقع…',

      noBinsMatch: (q) => `لا توجد مواقع تطابق "${q}".`,

      currentAttr: 'الخاصية الحالية',

      selected: (v) => `المحدد: ${v}`,

      empty: 'فارغ',

      optionalNotes: 'اتركه فارغًا أو اكتب قيمة',

      reviewBatch: '✓ مراجعة الباتش',

      reviewArrow: 'مراجعة →',

      submitReview: 'إرسال للمراجعة ✓',

      submitting: 'جارٍ الإرسال…',

      chooseAnother: '→ اختيار أمر آخر',

      unlockHint: 'أكمل الخطوات السابقة للمتابعة',

      prevStepHint: 'أكمل الخطوات السابقة أولًا',

      stepOrder: 'الأمر',

      stepQuantity: 'الكمية',

      stepBatchSetup: 'إعداد الباتش',

      stepReview: 'المراجعة',

      stepDone: 'تم',

      subBin: 'موقع التخزين',

      subAttributes: 'الخصائص',

      subReview: 'مراجعة',

      brandLabel: 'العلامة',

      sizeLabel: 'المقاس',

      seasonLabel: 'الموسم',

      detailsLabel: 'التفاصيل',

      pageTitle1: 'اختيار أمر إنتاج',

      pageTitle3: 'إعداد الباتش',

      pageTitle4: 'مراجعة قبل الإرسال',

      submittedTitle: 'تم إرسال الإيصال للمراجعة',

      submittedDesc: 'تم حفظ الإيصال وهو في انتظار موافقة المدير قبل الترحيل إلى SAP.',

      reviewId: 'رقم المراجعة',

      totalSubmitted: 'الإجمالي المرسل',

      printLabels: '🖨 طباعة ملصقات الباتش',

      newReceipt: '+ إيصال جديد',

      homeBtn: '→ الرئيسية',

      warehouseFilter: '🏭 المخزن:',

      allWarehouses: 'الكل',

      loadingAttrOpts: 'جارٍ تحميل خيارات الخصائص…',

      attrUnavailable: 'خيارات الخصائص من SAP غير متاحة مؤقتًا. يمكنك المتابعة يدويًا أو إعادة المحاولة.',

      clearSkip: '⊘ مسح وتخطي',

      noUomSearch: 'لا توجد وحدات قياس تطابق البحث',

      binLocation: 'موقع التخزين',

      addBatch: '+ إضافة باتش',

      released: 'مُصدَر',

      tapToSelect: 'اضغط للاختيار →',

      attrStep: (i, total) => `الخطوة ${i} من ${total}`,

      quantity: 'الكمية',

    },

    review: {

      title: 'مراجعة الإيصالات',

      subtitle: 'مدير',

      loadError: 'فشل تحميل الإيصالات.',

      refresh: '↻ تحديث',

      exportExcel: '⬇ تصدير Excel',

      importExcel: '⬆ استيراد Excel',

      downloadTemplate: '⬇ تحميل قالب الاستيراد',

      filterStatus: 'الحالة',

      filterOrder: 'رقم الأمر',

      filterBatch: 'رقم الباتش',

      filterWarehouse: 'المخزن',

      filterVendor: 'المورد',

      filterCreatedBy: 'بواسطة',

      filterDateFrom: 'من',

      filterDateTo: 'إلى',

      allStatuses: 'كل الحالات',

      pending: 'قيد الانتظار',

      posted: 'تم الترحيل',

      failed: 'فشل',

      approve: 'موافقة وترحيل',

      approving: 'جارٍ الترحيل…',

      reject: 'رفض',

      changeOrder: 'تغيير الأمر',

      save: 'حفظ',

      saving: 'جارٍ الحفظ…',

      saved: '✓ تم الحفظ',

      bulkSet: 'تعيين جماعي:',

      applySelected: 'تطبيق على المحدد',

      applying: 'جارٍ التطبيق…',

      editableRows: (n) => `تم تحديد ${n} ${n === 1 ? 'صف' : 'صفوف'} قابلة للتعديل`,

      selectAll: 'تحديد الكل',

      deselectAll: 'إلغاء تحديد الكل',

      noMatch: 'لا توجد نتائج',

      noneSelected: 'لا شيء محدد',

      selected: (n) => `${n} محدد`,

      rejectTitle: (id) => `رفض الإيصال #${id}`,

      rejectReason: 'السبب (اختياري)',

      rejectPlaceholder: 'أدخل السبب…',

      confirmReject: 'تأكيد الرفض',

      rejecting: 'جارٍ الرفض…',

      changeOrderTitle: (id) => `تغيير أمر الإنتاج — إيصال #${id}`,

      changeOrderCurrent: 'الحالي:',

      changeOrderSearch: 'بحث برقم الأمر أو كود الصنف أو الاسم…',

      changeOrderLoading: 'جارٍ التحميل…',

      noOrders: 'لا توجد أوامر.',

      changeTo: (num) => `تغيير إلى ${num}`,

      selectOrder: 'اختر أمرًا',

      changing: 'جارٍ التغيير…',

      addUnits: 'إضافة وحدات',

      postExtra: 'ترحيل',

      postingExtra: 'جارٍ الترحيل…',

      deleteConfirm: (label) => `حذف ${label}?\n\nسيتم حذف هذا الباتش فقط. الباتشات الأخرى في هذا الإيصال لن تتأثر.`,

      bulkSaveAll: 'حفظ كل التعديلات',

      bulkPostAll: 'ترحيل كل المعلقة',

      bulkPostConfirm: (n) => `ترحيل ${n} إيصال معلق إلى SAP؟ لا يمكن التراجع.`,

      importModalTitle: 'معاينة الاستيراد',

      importApply: 'تطبيق الاستيراد',

      importApplying: 'جارٍ التطبيق…',

      importCancel: 'إلغاء',

      totalBatches: 'باتش',

      totalQty: 'إجمالي الكمية',

      noReceipts: 'لا توجد إيصالات تطابق الفلاتر الحالية.',

      rejectFailed: 'فشل رفض الإيصال.',

      changeOrderFailed: 'فشل تغيير الأمر.',

      loadProductionOrdersFailed: 'فشل تحميل أوامر الإنتاج.',

      deleteBatchFailed: 'فشل حذف الباتش.',

      uomNotFound: 'وحدة القياس غير موجودة.',

      bulkUpdateFailed: 'فشل التحديث الجماعي.',

      nothingToPost: 'لا شيء للترحيل. حدد صفًا واحدًا على الأقل.',

      bulkPostFailed: 'فشل الترحيل الجماعي.',

      noRowsToExport: 'لا توجد صفوف للتصدير.',

      multiBatchWarning: 'يحتوي هذا الإيصال على باتشات متعددة. حدد جميع الباتشات لترحيله، أو يجب أن تكون الباتشات المكررة في إيصالات منفصلة.',

      myReceipts: 'إيصالاتي',

      userBanner: 'يمكنك تعديل وحفظ إيصالاتك. الترحيل النهائي إلى SAP يتم بواسطة المدير.',

      colFiltersLabel: 'فلاتر الأعمدة:',

      batchCount: (n) => `${n} باتش`,

      totalQtyLabel: 'إجمالي الكمية:',

      saveSelected: 'حفظ المحدد',

      savingSelected: 'جارٍ الحفظ…',

      postSelected: 'ترحيل المحدد',

      postingSelected: 'جارٍ الترحيل…',

      printLabels: (n) => `🖨️ طباعة ${n} ملصق`,

      importConfirm: 'تأكيد الاستيراد',

      importing: 'جارٍ الاستيراد...',

      importNote: (n) => `عرض أول ${n} صفوف.`,

      colStatus: 'الحالة',        colOrder: 'أمر الإنتاج',   colItem: 'كود الصنف',

      colProduct: 'المنتج',       colWh: 'المخزن',           colUnits: 'الوحدات',

      colUom: 'وحدة القياس',      colQty: 'الكمية',          colBatch: 'رقم الباتش',

      colBrand: 'البراند',        colSize: 'الحجم',          colCategory: 'التصنيف',

      colPacking: 'التعبئة',      colSeason: 'الموسم',       colCompany: 'الشركة',

      colVendor: 'المورد',        colPart: 'الجزء',          colNumber: 'الرقم',

      colDetails: 'التفاصيل',     colBin: 'الخلية',          colBy: 'أنشأه',

      colDate: 'التاريخ',         colSapErr: 'SAP / السبب',  colAddUnits: 'إضافة وحدات',

      colActions: 'الإجراءات',

      fieldUnits: 'الوحدات',      fieldUom: 'وحدة القياس',   fieldBrand: 'البراند',

      fieldSize: 'الحجم',         fieldCategory: 'التصنيف',  fieldPacking: 'التعبئة',

      fieldSeason: 'الموسم',      fieldCompany: 'الشركة',    fieldVendor: 'المورد',

      fieldPart: 'الجزء',         fieldNumber: 'الرقم',      fieldDetails: 'التفاصيل',

      fieldBin: 'الخلية',

    },

    rules: {

      title: 'قواعد الخصائص',

      tabOrders: '📦 أوامر الإنتاج',

      tabUsers: '👤 قواعد المستخدم',

      tabWarehouses: '🏭 قواعد المخزن',

      tabVisibility: '👁 ظهور الأوامر',

      configuredOrders: 'الأوامر المُعدَّة',

      loadingOrders: 'جارٍ التحميل…',

      noOrders: 'لا توجد قواعد بعد.',

      orderNum: (n) => `أمر ${n}`,

      valueRules: (n) => `${n} ${n === 1 ? 'قاعدة' : 'قواعد'} قيمة`,

      hidden: (n) => `${n} مخفي`,

      configured: 'مُعدَّ',

      deleteAllRules: '✕ حذف كل القواعد',

      deleting: 'جارٍ الحذف…',

      enterOrderNum: 'رقم أمر الإنتاج…',

      load: 'تحميل',

      loading: '…',

      orderNotFound: 'الأمر غير موجود.',

      noRulesHint: 'أدخل رقم أمر إنتاج لإعداد قواعد الخصائص.',

      noRulesHintSub: 'الأوامر بدون قواعد تعمل كالمعتاد — تظهر كل الخيارات.',

      loadingOptions: 'جارٍ تحميل خيارات الأمر…',

      fieldsRestricted: (n) => `${n} ${n === 1 ? 'حقل' : 'حقول'} مقيّد`,

      saveRules: 'حفظ القواعد',

      saving: 'جارٍ الحفظ…',

      usersWithRules: 'المستخدمون بقواعد',

      noUserRules: 'لا توجد قواعد مستخدمين بعد.',

      selectUser: 'اختر مستخدمًا',

      loadingUsers: 'جارٍ تحميل المستخدمين…',

      selectUserDefault: '— اختر مستخدمًا —',

      noUserHint: 'اختر مستخدمًا لإعداد القيم المسموحة لخصائصه.',

      noUserHintSub: 'المستخدمون بدون قواعد يرون كل الخيارات — السلوك الحالي محفوظ.',

      loadingOpts: 'جارٍ تحميل الخيارات…',

      saveUserRules: 'حفظ قواعد المستخدم',

      warehousesWithRules: 'المخازن بقواعد',

      noWhRules: 'لا توجد قواعد مخازن بعد.',

      selectWarehouse: 'اختر مخزنًا',

      loadingWarehouses: 'جارٍ تحميل المخازن…',

      selectWarehouseDefault: '— اختر مخزنًا —',

      noWhHint: 'اختر مخزنًا لإعداد القيم المسموحة وظهور الحقول.',

      noWhHintSub: 'المخازن بدون قواعد تظهر كل الخيارات وكل الحقول — السلوك الحالي محفوظ.',

      saveWhRules: 'حفظ قواعد المخزن',

      allAllowed: 'الكل مسموح',

      visible: 'ظاهر',

      hiddenLabel: 'مخفي',

      selectWarehouseVis: 'اختر مخزنًا',

      orderVisTitle: 'اختر مخزنًا',

      orderVisDesc: 'إخفاء أوامر إنتاج معينة لكل مخزن. الأوامر المخفية لن تظهر في معالج الإيصال للمستخدمين العاديين. المديرون يرون كل الأوامر دائمًا.',

      orderVisEmpty: 'اختر مخزنًا لإدارة ظهور الأوامر.',

      orderVisEmptySub: 'كل الأوامر ظاهرة لكل المستخدمين بشكل افتراضي.',

      ordersShown: (n, total) => `${n} ${n === 1 ? 'أمر' : 'أوامر'} معروض${total ? ` (فلترة من ${total})` : ''}. اضغط للتبديل.`,

      saveVisRules: 'حفظ قواعد الظهور',

      ordersHidden: (n) => `${n} ${n === 1 ? 'أمر' : 'أوامر'} مخفي`,

      searchOrders: 'بحث في الأوامر…',

      noOpenOrders: 'لا توجد أوامر مفتوحة لهذا المخزن.',

      loadingOrdersVis: 'جارٍ تحميل الأوامر…',

      metadataLoading: '⏳ جارٍ تحميل قيم الخيارات…',

      metadataError: '⚠️ تعذّر تحميل بعض قيم الخيارات.',

      noFieldOptions: 'لا تتوفر خيارات لهذا الحقل.',

      valuesAllowed: (n) => `✓ ${n} ${n === 1 ? 'قيمة' : 'قيم'} مسموحة`,

      warehouseCode: (code) => `مخزن ${code}`,

      savedMsg: 'تم حفظ القواعد.',

      saveUserSuccess: (username) => `تم حفظ قواعد ${username}.`,

      saveWhSuccess: (code) => `تم حفظ قواعد المخزن ${code}.`,

      saveVisSuccess: (code) => `تم حفظ قواعد ظهور المخزن ${code}.`,

      confirmDeleteUser: 'هل تريد حذف كل قواعد هذا المستخدم؟',

      confirmDeleteOrder: 'هل تريد حذف كل قواعد هذا الأمر؟',

      confirmDeleteWh: (code) => `هل تريد حذف كل قواعد المخزن ${code}؟`,

      clearedUser: 'تم مسح كل قواعد هذا المستخدم.',

      clearedWh: 'تم مسح كل قواعد هذا المخزن.',

      clearedOrder: 'تم مسح كل قواعد هذا الأمر.',

      deleteFailed: (msg) => `فشل الحذف: ${msg}`,

      failedToSave: 'فشل الحفظ.',

      orderVisible: '✓ ظاهر',

      orderHidden: '🚫 مخفي',

      noWhMatch: 'لا توجد مخازن مطابقة.',

      loadOrdersFailed: (msg) => `فشل تحميل الأوامر: ${msg}`,

      searchWhPlaceholder: 'بحث بالكود أو الاسم…',

    },

    scale: {

      title: 'الميزان والبسكول',

      subtitle: 'توزين الشاحنات، خصم العناصر المؤثرة، والتحويل لفحص الجودة',

      weighingTitle: 'محطة التوزين',

      weighingSubtitle: 'تسجيل الوزن القائم (محمل) أو الفارغ للشاحنات',

      draftsTitle: 'مسودات وتذاكر الميزان',

      draftsSubtitle: 'متابعة مسودات التوزين، استكمال الوزنة الثانية، وطباعة التذاكر',

      devicesTitle: 'أجهزة ومؤشرات الميزان',

      devicesSubtitle: 'إدارة منافذ التوصيل والمؤشرات وبوابات الشبكة والمحاكي المعملي',

      agentStatusTitle: 'حالة وكيل الميزان المحلي (Scale Agent)',

      agentStatusSubtitle: 'بوابة الاتصال بالعتاد على المنفذ المحلي 8998',

      agentConnected: 'وكيل الميزان المحلي متصل',

      agentNotDetected: 'وكيل الميزان المحلي غير متاح',

      agentChecking: 'جاري فحص الوكيل المحلي...',

      agentUptime: 'وقت التشغيل',

      agentVersion: 'الإصدار',

      agentScalesCount: 'الموازين المربوطة',

      agentServerConnected: 'المزامنة مع ERP',

      testConnection: 'فحص الاتصال بالوكيل',

      reloadConfig: 'إعادة تحميل إعدادات الوكيل',

      deployAgent: 'تجهيز وتحميل الوكيل',

      deployAllScales: 'تحميل وكيل الموازين',

      deploying: 'جاري التحميل...',

      deploySuccess: 'تم تحميل حزمة الوكيل بنجاح',

      deployError: 'فشل تحميل حزمة الوكيل',

      comPort: 'منفذ COM',

      detectedPorts: 'المنافذ المكتشفة بالعتاد',

      manualPort: 'إدخال المنفذ يدوياً...',

      manualComPortLabel: 'منفذ COM مخصص',

      baudRate: 'معدل الباود (Baud Rate)',

      autoDetectMode: 'اكتشاف تلقائي (موصى به)',

      autoDetectHelper:

        'يقوم وكيل الميزان تلقائياً بإيجاد منفذ COM ومعدل الباود للمؤشر المتصل دون الحاجة لأي إعدادات يدوية.',

      manualConfig: 'إعدادات متقدمة / يدوية',

      connectionType: 'نوع الاتصال',

      localCom: 'منفذ تسلسلي COM / USB (محلي)',

      remoteIp: 'شبكة IP / بوابة إلكترونية (عن بعد)',

      virtualSim: 'محاكي افتراضي (معملي)',

      toggleActive: 'تغيير الحالة',

      activateDevice: 'تفعيل الجهاز',

      deactivateDevice: 'إيقاف الجهاز',

      confirmDeactivateDevice: 'هل أنت متأكد من رغبتك في إيقاف هذا الميزان؟ الموازين غير النشطة لن تستقبل أوزاناً ولن تُضمّن في حزم الوكيل.',

      confirmActivateDevice: 'هل أنت متأكد من رغبتك في تفعيل هذا الميزان؟',

      confirmDeleteDevice: 'هل أنت متأكد من حذف جهاز الميزان نهائياً؟',

      deviceCreatedSuccess: 'تم إنشاء جهاز الميزان بنجاح',

      deviceUpdatedSuccess: 'تم تحديث جهاز الميزان بنجاح',

      deviceDeletedSuccess: 'تم حذف جهاز الميزان بنجاح',

      deviceStatusChanged: 'تم تحديث حالة جهاز الميزان بنجاح',

      agentNoticeOffline: 'برنامج وكيل الميزان غير مشغل على هذا الجهاز (http://127.0.0.1:8998). لقراءة الأوزان من مؤشر الميزان الفعلي، يرجى تحميل حزمة التشغيل وتشغيل ScaleAgent.exe.',

      liveWeightMonitor: 'شاشة مراقبة المؤشر اللحظية',

      selectScaleToMonitor: 'اختر ميزاناً لعرض إشارة الوزن الحية',

      noDevicesFound: 'لا توجد أجهزة ميزان مضافة حالياً',

      openWeighing: 'فتح محطة التوزين ←',

      openDrafts: 'استعراض المسودات والتذاكر ←',

      openDevices: 'إدارة أجهزة الميزان ←',

      itemElementsTitle: 'عناصر الميزان المؤثرة',

      itemElementsSubtitle: 'إدارة بيانات الطبالي والأقفاص والعناصر المؤثرة المعتمدة المستخدمة أثناء التوزين',

      openItemElements: 'إدارة العناصر المؤثرة ←',

      receiptTitle: 'إيصال استلام',

      receiptSubtitle: 'تسجيل استلام البضائع والمواد الواردة على نموذج EG.ST.F04',

      openReceipt: 'فتح إيصال الاستلام ←',

      receiptDate: 'التاريخ',

      vehicleNumber: 'رقم السيارة',

      driverName: 'اسم السائق',

      driverLicense: 'رقم الرخصة',

      receiptSource: 'من المصدر',

      productsTable: 'الأصناف والكميات',

      quantityKg: 'الكمية بالكيلو',

      quantityTon: 'الكمية بالطن',

      packageType: 'نوع العبوة',

      addRow: 'إضافة صف',

      removeRow: 'حذف',

      totalKg: 'الإجمالي بالكيلو',

      totalTon: 'الإجمالي بالطن',

      driverSignature: 'السائق',

      receiverSignature: 'المستلم بقيمة البضاعة',

      signatureName: 'الاسم',

      signatureDraw: 'التوقيع',

      clearSignature: 'مسح',

      saveReceipt: 'حفظ',

      saveAndClose: 'حفظ وإغلاق',

      clearReceipt: 'مسح',

      printReceipt: 'طباعة',

      receiptSavedSuccess: 'تم حفظ الإيصال بنجاح',

      receiptUpdatedSuccess: 'تم تحديث الإيصال بنجاح',

      confirmClearReceipt: 'هل أنت متأكد من مسح الإيصال؟ سيتم فقدان البيانات غير المحفوظة.',

      newItemElement: 'عنصر مؤثر جديد',

      editItemElement: 'تعديل عنصر مؤثر',

      noItemElementsFound: 'لا توجد عناصر مؤثرة',

      itemCode: 'كود الصنف',

      itemName: 'اسم الصنف',

      elementName: 'اسم العنصر',

      active: 'نشط',

      inactive: 'غير نشط',

      actions: 'الإجراءات',

      activateElement: 'تفعيل',

      deactivateElement: 'إيقاف',

      itemElementCreated: 'تم إنشاء العنصر المؤثر بنجاح',

      itemElementUpdated: 'تم تحديث العنصر المؤثر بنجاح',

      liveWeight: 'قراءة الوزن اللحظي',

      stable: 'مستقر',

      unstable: 'غير مستقر',

      online: 'متصل',

      offline: 'غير متصل',

      device: 'جهاز الميزان',

      vehicle: 'السيارة / الشاحنة',

      truckType: 'نوع المركبة',

      trailerNumber: 'رقم المقطورة',

      containerNumber: 'رقم الحاوية',

      normalTruck: 'سيارة / شاحنة عادية',

      containerTruck: 'شاحنة حاويات',

      driver: 'السائق',

      supplier: 'المورد / المزرعة',

      item: 'الصنف / المادة',

      firstWeight: 'الوزنة الأولى',

      secondWeight: 'الوزنة الثانية',

      grossWeight: 'الوزن القائم',

      tareWeight: 'الوزن الفارغ',

      netWeight: 'صافي وزن المنتج',

      tareAdjustments: 'العناصر المؤثرة (الطبالي / الأقفاص)',

      selectElement: 'اختر عنصرًا مؤثرًا',

      pivotBatches: 'توزيع البيفوتات والموردين',

      pivots: 'باتشات البيفوت',

      notes: 'ملاحظات وتفاصيل',

      recordFirstWeight: 'تسجيل الوزنة الأولى',

      recordSecondWeight: 'تسجيل الوزنة الثانية',

      sendToQuality: 'تحويل لفحص الجودة',

      sentToQualitySuccess: 'تم تحويل المسودة #{draftNumber} لفحص الجودة بنجاح!',

      cancelDraft: 'إلغاء المسودة',

      confirmCancelDraft: 'هل أنت متأكد من رغبتك في إلغاء هذه المسودة؟',

      resumeDraft: 'استكمال الوزنة الثانية',

      printTicket: 'طباعة التذكرة',

      statusPendingSecond: 'بانتظار الوزنة الثانية',

      statusCompleted: 'اكتمل التوزين',

      statusSentToQuality: 'تم التحويل للجودة',

      statusCancelled: 'ملغاة',

      newVehicleModalTitle: 'تسجيل ودخول سيارة جديدة',

      vehicleNumber: 'رقم اللوحة / العربية',

      company: 'شركة النقل',

      enterGate: 'تسجيل دخول البوابة',

      addTareElement: 'إضافة عنصر مؤثر',

      unitWeight: 'وزن الوحدة (كجم)',

      count: 'العدد / الكمية',

      signedWeight: 'إجمالي خصم العنصر (كجم)',

      addPivotBatch: 'إضافة بيفوت مورد',

      boxCount: 'عدد الصناديق',

      boxWeight: 'وزن الصندوق',

      percentage: 'النسبة (%)',

      allocatedWeight: 'الوزن المخصص (كجم)',

      autoDistribute: 'توزيع الأوزان آلياً',

      simulatorTitle: 'محاكي الميزان الافتراضي (للاختبار المعملي)',

      simulatorNote: 'استخدم المحاكي الافتراضي للاختبار المعملي فقط.',

      setWeight: 'تحديد الوزن (كجم)',

      simStable: 'محاكاة استقرار الوزن',

      simUnstable: 'محاكاة تذبذب الوزن',

      simOffline: 'محاكاة انقطاع الاتصال',

      simOnline: 'محاكاة إعادة الاتصال',

      updateSimulator: 'تحديث قراءة المحاكي',

      mustBeStableWarning: 'يجب أن تكون قراءة الوزن مستقرة والجهاز متصلاً لتسجيل الوزن.',

      noDraftsFound: 'لا توجد مسودات توزين.',

      noDevicesFound: 'لا توجد أجهزة ميزان.',

      ticketHeader: 'تصريح ميزان البسكول / WEIGHBRIDGE TICKET',

      ticketNumber: 'رقم التذكرة',

      loadedTime: 'وقت وزن القائم',

      emptyTime: 'وقت وزن الفارغ',

      operator: 'مسؤول الميزان',

      allocationTitle: 'تخصيص وتوزيع حمولة الشاحنة',

      allocationSubtitle: 'توزيع الوزن الصافي المعتمد للشاحنة عبر بنود الموردين والأصناف والتشغيلات',

      addAllocationLine: '+ إضافة بند صنف/مورد',

      addAllocationLineMulti: '+ إضافة بند صنف/مورد جديد للشاحنة',

      removeAllocationLine: '✕ حذف البند',

      autoDistributeMode: 'توزيع تلقائي (حسب الأوزان التقديرية)',

      manualDistributeMode: 'توزيع يدوي مخصص',

      certifiedNetTruckWeight: 'الوزن الصافي المعتمد للشاحنة:',

      totalAllocatedWeight: 'إجمالي التوزيع الفعلي:',

      remainingDifference: 'المتبقي / الفارق:',

      balancedStatus: '✅ متزن (100% معتمد)',

      unbalancedStatus: (diff) => `⚠️ غير متزن (فارق: ${diff} كجم)`,

      unbalancedSaveWarning: '⚠️ لا يمكن حفظ التوزيع أثناء وجود عدم اتزان مع الوزن الصافي المعتمد للشاحنة.',

      saveAllocations: 'حفظ واعتماد التوزيع',

      batchOrPivot: 'رقم التشغيلة / البيفوت',

      packageType: 'نوع العبوة',

      packageCount: 'عدد العبوات',

      estUnitWeight: 'وزن العبوة التقديري (كجم)',

      estLineWeight: 'الوزن التقديري',

      finalAllocatedWeight: 'الوزن المخصص (كجم)',

      cargoStepTitle: 'بيانات الشحنة والحمولة',

      cargoStepSubtitle: 'حدد السائق، وبيانات الموردين والأصناف والتشغيلات المحملة على الشاحنة',

      driverPlaceholder: 'اسم السائق المشغل للشاحنة',

      supplierPlaceholder: 'مثال: شركة النماء الزراعية',

      itemPlaceholder: 'مثال: برتقال صيفي فرز أول',

      batchPlaceholder: 'مثال: PVT-NORTH-01',

      allocatedLinesCount: (count) => `${count} بنود مخصصة`,

      totalBoxesCount: (count) => `إجمالي العبوات: ${count}`,

      totalEstWeight: (weight) => `إجمالي الوزن التقديري: ${weight} كجم`,

      lineItemNum: (num) => `بند #${num}`,

      loadBreakdownSection: 'تفاصيل توزيع الحمولة والأصناف',

      allocatedBreakdownPreview: (count) => `📦 بنود الحمولة المخصصة للشاحنة (${count} بنود):`,

      estUnitCalc: (count, unit, total) => `${count} عبوة × ${unit} كجم = ${total} كجم (تقديري)`,

      allocationsSavedSuccess: 'تم حفظ وتوزيع بنود الحمولة بنجاح.',

      tareDeductionTotal: 'إجمالي خصم العناصر المؤثرة:',

      entryExitPermitsTitle: 'تصاريح الدخول والخروج',

      entryExitPermitsSubtitle: 'إصدار تصريح دخول (F05) أو خروج (F06) للسيارات والبضائع من البوابة',

      openEntryExitPermits: 'فتح تصاريح الدخول والخروج ←',

      entryPermitTitle: 'تصريح دخول',

      entryPermitSubtitle: 'تصريح دخول للسيارات الواردة — نموذج EG.ST.F05',

      openEntryPermit: 'فتح تصريح دخول ←',

      exitPermitTitle: 'تصريح خروج',

      exitPermitSubtitle: 'تصريح خروج للبضائع الصادرة من البوابة — نموذج EG.ST.F06',

      openExitPermit: 'فتح تصريح خروج ←',

      permitDate: 'التاريخ',

      permitType: 'نوع التصريح',

      supplierName: 'اسم المورد',

      buyerName: 'اسم المشتري',

      permitDriverName: 'اسم السائق',

      destination: 'الجهة',

      inspectionSection: 'نتيجة الفحص والمعاينة',

      inspectionResult: 'نتيجة الفحص والمعاينة',

      gateWriter: 'كاتب البوابة',

      inspectionHead: 'رئيس قسم التفتيش الوارد',

      weighingSection: 'بيان وزن الحمولة',

      grossWeight: 'القائم',

      tareWeight: 'الفارغ',

      netWeight: 'الصافي',

      kgLabel: 'كيلو',

      tonLabel: 'طن',

      onlyAndAmount: 'فقط وقدره',

      scaleOperator: 'مسؤول الباسكول',

      generalManager: 'مدير عام الشركة',

      responsiblePerson: 'المسؤول',

      departmentManager: 'مدير الإدارة',

      recordKg: 'مسجل (كيلو)',

      recordTon: 'مسجل (طن)',

      weightKg: 'الوزن (كيلو)',

      weightTon: 'الوزن (طن)',

      savePermit: 'حفظ',

      printPermit: 'طباعة',

      clearPermit: 'مسح',

      permitSavedSuccess: 'تم حفظ التصريح بنجاح',

      permitUpdatedSuccess: 'تم تحديث التصريح بنجاح',

      confirmClearPermit: 'هل تريد مسح هذا التصريح؟ ستفقد البيانات غير المحفوظة.',

      permitNumber: 'رقم التصريح',

    },

    inspectionStages: {

      eyebrow: 'إعدادات الجودة',

      title: 'مراحل الفحص الفني',

      description: 'إدارة مراحل ومحطات فحص الجودة في النظام.',

      total: 'إجمالي المراحل',

      active: 'نشطة',

      addStage: 'مرحلة جديدة',

      editStage: 'تعديل المرحلة',

      searchPlaceholder: 'البحث في المراحل...',

      code: 'كود المرحلة',

      nameAr: 'الاسم بالعربية',

      nameEn: 'الاسم بالإنجليزية',

      sortOrder: 'ترتيب العرض',

      status: 'الحالة',

      actions: 'الإجراءات',

      enabled: 'نشط',

      disabled: 'معطل',

      enable: 'تفعيل',

      disable: 'تعطيل',

      delete: 'حذف',

      deleted: 'تم حذف المرحلة بنجاح',

      deleteFailed: 'فشل حذف المرحلة',

      deleteFirstTitle: 'حذف مرحلة الفحص',

      deleteFirstMessage: 'هل أنت متأكد من رغبتك في حذف هذه المرحلة؟',

      deleteSecondTitle: 'تأكيد الحذف النهائي للمرحلة',

      deleteSecondMessage: 'هذا الإجراء لا يمكن التراجع عنه وسيؤثر على المعايير المرتبطة.',

      saved: 'تم حفظ المرحلة بنجاح',

      saveFailed: 'فشل حفظ المرحلة',

      loadFailed: 'فشل تحميل مراحل الفحص',

    },

    qualityCategories: {

      eyebrow: 'إعدادات الجودة',

      title: 'تصنيفات عيوب الجودة',

      description: 'إدارة مجموعات وتصنيفات العيوب (آفات زراعية، عيوب ميكانيكية، عيوب فسيولوجية).',

      total: 'إجمالي التصنيفات',

      active: 'نشط',

      addCategory: 'تصنيف جديد',

      editCategory: 'تعديل التصنيف',

      searchPlaceholder: 'البحث في التصنيفات...',

      code: 'كود التصنيف',

      nameAr: 'الاسم بالعربية',

      nameEn: 'الاسم بالإنجليزية',

      sortOrder: 'ترتيب العرض',

      status: 'الحالة',

      actions: 'الإجراءات',

      enabled: 'نشط',

      disabled: 'معطل',

      enable: 'تفعيل',

      disable: 'تعطيل',

      saved: 'تم حفظ التصنيف بنجاح',

      saveFailed: 'فشل حفظ التصنيف',

      loadFailed: 'فشل تحميل تصنيفات الجودة',

    },

    qualityCriteria: {

      eyebrow: 'إعدادات الجودة',

      title: 'دليل معايير وعيوب الجودة',

      description: 'إدارة معايير الفحص وعيوب الجودة ومعاملات الحساب الإحصائي.',

      total: 'إجمالي المعايير',

      active: 'نشط',

      addCriterion: 'معيار فحص جديد',

      editCriterion: 'تعديل المعيار',

      searchPlaceholder: 'البحث في المعايير...',

      code: 'الكود',

      autoGeneratedCode: 'كود يتم توليده تلقائياً',

      nameAr: 'الاسم بالعربية',

      nameEn: 'الاسم بالإنجليزية',

      category: 'التصنيف',

      categoryFilter: 'فلترة بالتصنيف',

      allCategories: 'جميع التصنيفات',

      inspectionStage: 'مرحلة الفحص',

      stageFilter: 'فلترة بالمرحلة',

      allStages: 'جميع المراحل',

      calculationKey: 'معامل الحساب (Key)',

      displayOrder: 'ترتيب العرض',

      status: 'الحالة',

      actions: 'الإجراءات',

      enabled: 'نشط',

      disabled: 'معطل',

      enable: 'تفعيل',

      disable: 'تعطيل',

      deleteConfirm: 'هل أنت متأكد من رغبتك في حذف هذا المعيار؟',

      deleted: 'تم حذف المعيار بنجاح',

      deleteFailed: 'فشل حذف المعيار',

      saved: 'تم حفظ المعيار بنجاح',

      saveFailed: 'فشل حفظ المعيار',

      loadFailed: 'فشل تحميل معايير الجودة',

      noCriteriaMatch: 'لا توجد معايير مطابقة للبحث',

      description: 'بيانات معايير الفحص',

    },

    itemCriteria: {

      eyebrow: 'إعدادات الجودة',

      title: 'ربط الأصناف بمعايير الجودة',

      description: 'تحديد وتخصيص معايير الفحص المطلوبة لكل صنف ومحصول.',

      selectStage: 'المرحلة',

      selectStageTitle: '١. اختر مرحلة الفحص',

      selectStageDesc: 'اختر مرحلة الفحص المراد إعداد معاييرها.',

      selectItemGroup: 'مجموعة الأصناف',

      selectItemGroupTitle: '٢. اختر مجموعة الأصناف',

      selectItemGroupDesc: 'اختر مجموعة الأصناف لفلترة المواد.',

      selectItemGroupWarning: 'يرجى اختيار مجموعة أصناف أولاً.',

      selectItemTitle: '٣. اختر الصنف / المحصول',

      selectItemDesc: 'اختر الصنف المطلوب لضبط معايير فحصه.',

      items: 'الأصناف',

      noItems: 'لا توجد أصناف متاحة',

      itemsLoadFailed: 'فشل تحميل الأصناف',

      itemGroupsLoadFailed: 'فشل تحميل مجموعات الأصناف',

      mappingsLoadFailed: 'فشل تحميل روابط المعايير',

      criteria: 'معايير الفحص',

      criteriaSearch: 'بحث في المعايير',

      criteriaSearchPlaceholder: 'البحث عن معيار بالاسم أو الكود...',

      categoryFilter: 'التصنيف',

      allCategories: 'جميع التصنيفات',

      selectionFilter: 'حالة التحديد',

      selectionAll: 'الكل',

      selectionSelected: 'المحدد فقط',

      selectionUnselected: 'غير المحدد فقط',

      selected: 'محدد',

      notSelected: 'غير محدد',

      selectedCount: 'المعايير المحددة',

      saveMappings: 'حفظ الروابط والمعايير',

      saved: 'تم حفظ روابط المعايير بنجاح',

      saveFailed: 'فشل حفظ الروابط',

      noCriteriaTitle: 'لا توجد معايير متاحة',

      noCriteriaDesc: 'لا توجد معايير نشطة لهذه المرحلة.',

      noCriteriaMatchTitle: 'لا توجد معايير مطابقة',

      noCriteriaMatchDesc: 'لا توجد معايير مطابقة لشروط الفلترة.',

      itemSearchPlaceholder: 'البحث في الأصناف...',

      stage: 'المرحلة',

      itemGroup: 'مجموعة الأصناف',

    },

    quality: {

      stepTrucks: 'السيارات والشاحنات',

      addTruck: '+ إضافة سيارة',

      addFirstBatch: '+ إضافة أول تشغيلة',

      addAnotherBatch: '+ إضافة تشغيلة أخرى',

      addedOperationsTitle: 'عمليات التشغيلات المسجلة',

      batchesProgress: (done, total) => `تم فحص ${done} من أصل ${total} تشغيلة`,

      completedInspections: 'الفحوصات المكتملة',

      remainingInspections: 'الفحوصات المتبقية',

      totalTrucksLabel: 'إجمالي السيارات',

      totalBatchesLabel: 'إجمالي التشغيلات',

      totalOperationsCount: (n) => `${n} عملية`,

      contractorsLoading: 'جارٍ تحميل المقاولين...',

      contractorsEmpty: 'لا يوجد مقاولون',

      contractorsLoadFailed: 'فشل تحميل قائمة المقاولين',

      contractorSelectDesc: 'اختر المقاول لهذه الشاحنة',

      selectContractorFirst: 'يرجى اختيار المقاول أولاً',

      noPendingScaleDrafts: 'لا توجد مسودات ميزان مغلقة بانتظار الاستلام.',

      contractorSearchPlaceholder: 'البحث عن مقاول بالاسم...',

      farmSearchPlaceholder: 'البحث عن مزرعة بالاسم...',

      selectFarmFirst: 'يرجى اختيار المزرعة / المنشأ أولاً',

      selectItemWarning: 'يرجى تحديد الصنف لكافة التشغيلات',

      searchingBatchERP: 'جارٍ التحقق من التشغيلة في النظام...',

      noActiveTrucks: 'لا توجد شاحنات مضافة في جلسة الفحص الحالية',

      noActiveDefects: 'لا توجد عيوب مسجلة',

      noDefectsInCat: 'لا توجد عيوب مسجلة في هذا التصنيف',

      recordedDefects: 'العيوب المسجلة',

      leftSideDefects: 'الآفات والعيوب الزراعية',

      rightSideDefects: 'العيوب الميكانيكية والفسيولوجية',

      tabPests: 'الآفات الزراعية',

      tabMechanical: 'العيوب الميكانيكية',

      tabPhysiological: 'العيوب الفسيولوجية والجودة',

      returnToVehicleDetails: '← العودة لتفاصيل السيارة',

      reviewCollectedInfo: 'مراجعة ملخص وإحصائيات الفحص',

      reviewResultsAction: 'عرض لوحة النتائج الفنية ←',

      startNewVehicleInspection: '+ بدء فحص سيارة جديدة',

      openOperationAction: (label) => label || 'بدء الفحص الفني',

      operationsEmptyTitle: 'لا توجد تشغيلات مسجلة',

      operationsEmptyDesc: 'لم يتم تسجيل أي عمليات تشغيلات لهذه الشاحنة بعد.',

      printWindowBlocked: 'تم حظر النافذة المنبثقة من قبل المتصفح. يرجى السماح بالنوافذ المنبثقة للطباعة.',

      dashboardDesc: 'استعراض المؤشرات الإحصائية للجودة وتوزيع العيوب والقرار الفني النهائي.',

      colTruckNumber: 'رقم السيارة',

      colContractor: 'المقاول',

      colFarmVendor: 'المزرعة / المورد',

      totalQuantity: 'إجمالي الكمية',

      warehouseCode: (code) => `مخزن ${code}`,

      statusRejected: 'مرفوض',

      filterTruckNumber: 'رقم السيارة',

      filterContractor: 'المقاول',

      filterFarmVendor: 'المزرعة / المورد',

      filterProduct: 'المنتج / الصنف',

      filterInspector: 'المفتش',

      filterDateFrom: 'من تاريخ',

      filterDateTo: 'إلى تاريخ',

      grpoDraftOpenFailed: 'فشل فتح مسودة الاستلام',

      backToTruck: 'الرجوع للسيارة',

      binLocation: 'الخلية التخزينية',

      binLocationRequired: 'الخلية التخزينية مطلوبة',

      checkGrpoPostingReadiness: 'التحقق من جاهزية المستند',

      continueBtn: 'متابعة',

      delete: 'حذف',

      deleteFailed: 'فشل حذف التقرير',

      discountPercent: 'نسبة الخصم %',

      discountPercentCannotBeNegative: 'لا يمكن أن تكون نسبة الخصم سالبة',

      documentDate: 'تاريخ المستند',

      documentDateRequired: 'تاريخ المستند مطلوب',

      dueDate: 'تاريخ الاستحقاق',

      dueDateRequired: 'تاريخ الاستحقاق مطلوب',

      expiryDate: 'تاريخ الصلاحية',

      grpoApproveFailed: 'فشل اعتماد مسودة الاستلام',

      grpoComments: 'ملاحظات الاستلام',

      grpoDocumentNotPosted: 'مستند الاستلام غير مسجل بعد',

      grpoDraftApprovedForPosting: 'تم اعتماد مسودة الاستلام للتسجيل',

      grpoDraftLoadFailed: 'فشل تحميل مسودة الاستلام',

      grpoDraftNotFound: 'مسودة الاستلام غير موجودة',

      grpoDraftSaveFailed: 'فشل حفظ مسودة الاستلام',

      grpoDraftSaved: 'تم حفظ مسودة الاستلام بنجاح',

      grpoDraftStatus: 'حالة مسودة الاستلام',

      grpoDraftPostedSuccess: 'تم تسجيل مستند الاستلام بنجاح.',

      grpoHeaderDesc: 'بيانات المورد والمستند',

      grpoHeaderInfo: 'البيانات الأساسية للمستند',

      grpoItemDetails: 'المستودع والتسعير',

      grpoItemDetailsDesc: 'بيانات الصنف والكمية والتسعير ومراكز التكلفة',

      grpoPostFailed: 'فشل تسجيل مستند الاستلام',

      grpoPostedFinalDesc: 'تم تسجيل مستند استلام البضاعة بنجاح.',

      grpoPostedFinalTitle: 'تم تسجيل مستند الاستلام',

      grpoPostedToSap: 'تم تسجيل المستند',

      grpoPostingReadinessReady: 'جاهز للتسجيل',

      grpoPreviewFailed: 'فشل معاينة مستند الاستلام',

      grpoQuantity: 'كمية الاستلام',

      grpoReviewPostingDesc: 'مراجعة كافة الحقول والبيانات قبل تسجيل مستند الاستلام',

      grpoReviewPostingTitle: 'مراجعة وتسجيل مستند الاستلام',

      grpoStatuses: {

        DRAFT: 'مسودة',

        PENDING_REVIEW: 'في انتظار المراجعة',

        APPROVED_FOR_POSTING: 'معتمدة للترحيل',

        POSTED: 'تم الترحيل',

        POSTING_FAILED: 'فشل الترحيل',

        CANCELLED: 'ملغاة',

      },

      grpoSteps: {

        header: 'بيانات المورد والمستند',

        item: 'المستودع والتسعير',

        warehouse: 'المخزن والخلية',

        operational: 'التشغيل والوزن',

        batches: 'بيانات التشغيلات والخواص',

        review: 'المراجعة والترحيل إلى SAP',

        batch: 'التشغيل والوزن',

        manual: 'بيانات الاستلام اليدوي',

        manualItemWarehouse: 'المستودع والتسعير والمخزن والخلية',

        itemAndPricingSection: 'بيانات الصنف والتسعير',

        warehouseAndBinSection: 'المخزن والخلية التخزينية',

      },

      manualSteps: {

        vehicle: 'الشحنة والحاوية',

        supplier: 'المورد',

        product: 'الصنف والخامة',

        warehouse: 'المخزن والخلية',

        operational: 'سياق التشغيل',

        batches: 'بيانات التشغيلات والخواص',

        review: 'المراجعة والإنشاء',

        batch: 'بيانات التشغيلة والتواريخ',

      },

      batchDataTitle: 'بيانات وخواص التشغيلات',

      batchDataDesc: 'إعداد أرقام التشغيلات وتوزيع الكميات المستلمة وأماكن التخزين وخواص الباتشات.',

      batchLabel: (n) => `تشغيلة #${n}`,

      totalRequiredQty: 'الكمية المطلوبة',

      allocatedQty: 'الكمية الموزعة',

      remainingBalance: 'المتبقي للتوزيع',

      quantitiesBalanced: 'تم توزيع كامل الكمية بدقة ويمكن المتابعة.',

      quantityMismatch: (diff) => `الكمية الموزعة لا تتطابق مع الكمية المطلوبة (الفارق: ${diff}).`,

      addBatch: '＋ إضافة تشغيلة',

      duplicateBatch: '⧉ تكرار',

      removeBatch: '✕ حذف',

      editBatch: 'تعديل التشغيلة',

      doneBatch: 'تأكيد التشغيلة',

      basicAndBin: 'بيانات التشغيلة',

      batchProperties: 'خواص التشغيلة',

      batchSummary: 'ملخص التشغيلة',

      batchBreakdown: 'تفاصيل توزيع التشغيلات',

      noBatchesConfigured: 'لا توجد تشغيلات مضافة.',

      batchAttrs: {

        size: 'الحجم',

        brand: 'الماركة',

        category: 'الفئة',

        packing: 'التعبئة',

        season: 'الموسم',

        extraSpec: 'مواصفة إضافية',

        vendor: 'المورد',

        part: 'الجزء',

        company: 'الشركة',

        number: 'الرقم',

        details: 'تفاصيل وملاحظات',

        batchAttribute1: 'خاصية التشغيلة 1',

        batchAttribute2: 'خاصية التشغيلة 2',

      },

      manualStepVehicleTitle: 'بيانات الشحنة والحاوية',

      manualStepVehicleDesc: 'أدخل رقم الحاوية / السيارة، وعدد العبوات، وأي ملاحظات تشغيلية اختيارية.',

      manualStepSupplierTitle: 'المورد',

      manualStepSupplierDesc: 'اختر المورد أو المزرعة من بيانات SAP.',

      manualStepProductTitle: 'تفاصيل الصنف والخامة',

      manualStepProductDesc: 'اختر مجموعة الأصناف والصنف من SAP. يتم تحديد وحدة القياس تلقائياً.',

      manualStepWarehouseTitle: 'المخزن والخلية',

      manualStepWarehouseDesc: 'اختر مستودع الاستلام ومكان التخزين (الخلية).',

      manualStepBatchTitle: 'بيانات التشغيلة والتواريخ',

      manualStepBatchDesc: 'أدخل رقم التشغيلة يدوياً وحدد تاريخ الإنتاج وتاريخ الدخول.',

      manualStepReviewTitle: 'مراجعة وتأكيد الاستلام اليدوي',

      manualStepReviewDesc: 'تحقق من كافة بيانات الاستلام المدخلة قبل إنشاء مسودة الاستلام.',

      containerNumber: 'رقم الحاوية',

      containerNumberPlaceholder: 'أدخل رقم الحاوية / السيارة...',

      containerNumberRequired: 'رقم الحاوية مطلوب.',

      noPacked: 'عدد العبوات',

      noPackedPlaceholder: '0',

      noPackedRequired: 'عدد العبوات مطلوب.',

      invalidNoPacked: 'عدد العبوات يجب أن يكون رقماً صحيحاً غير سالب.',

      itemGroupRequired: 'مجموعة الأصناف مطلوبة',

      batchAvailable: 'رقم التشغيلة متاح في SAP',

      carNumberRequired: 'رقم السيارة مطلوب للاستلام اليدوي',

      grpoManualStepTitle: 'بيانات الاستلام اليدوي',

      grpoManualStepDesc: 'بيانات هوية الشحنة وتفاصيل الصنف للاستلام اليدوي.',

      itemCodeOrNameRequired: 'كود الصنف أو اسم الصنف مطلوب',

      inspectAnotherBatch: 'فحص تشغيلة أخرى',

      itemCodeRequired: 'كود الصنف مطلوب',

      itemNameRequired: 'اسم الصنف مطلوب',

      landingSubtitle: 'اختر مرحلة الفحص المطلوبة أو قم بإدارة معايير وإعدادات الجودة',

      landingTitle: 'مركز إدارة ومراقبة الجودة',

      location: 'الموقع',

      locationOptional: 'الموقع (اختياري)',

      locationPlaceholder: 'كود الموقع / البعد 1 الاختياري',

      selectLocationOptional: '-- اختر الموقع (اختياري) --',

      general: 'عام',

      generalOptional: 'عام (اختياري)',

      generalPlaceholder: 'كود عام / البعد 2 الاختياري',

      selectGeneralOptional: '-- اختر مركز التكلفة العام (اختياري) --',

      loadingCostCenters: 'جاري تحميل مراكز التكلفة من SAP...',

      noCostCenters: 'لا توجد مراكز تكلفة متاحة',

      costCenterLoadFailed:
        'فشل تحميل مراكز التكلفة من SAP. سيتم الاحتفاظ بالتغييرات. أعد المحاولة للتحميل.',

      loadBinsFailed: 'فشل تحميل الخلايا التخزينية',

      loadWarehousesFailed: 'فشل تحميل المخازن',

      loadingBinLocations: 'جاري تحميل الخلايا...',

      vendorRefNo: 'رقم مرجع المورد',

      vendorRefNoPlaceholder: 'أدخل رقم مرجع المورد...',

      journalRemark: 'ملاحظة القيد',

      journalRemarkPlaceholder: 'أدخل ملاحظة القيد...',

      manufacturingDate: 'تاريخ الإنتاج',

      manufacturingDateRequired: 'تاريخ الإنتاج مطلوب',

      newTruckDetails: 'بيانات سيارة جديدة',

      noBatchesAdded: 'لم يتم إضافة أي تشغيلات بعد',

      numSamples: 'عدد العينات',

      postGrpoToSap: 'تسجيل مستند الاستلام',

      confirmAndPostGrpoToSap: 'تأكيد الاستلام وإرسال إلى SAP',

      printGrpoDocument: 'طباعة مستند الاستلام',

      postedAt: 'تاريخ الترحيل',

      postedDeleteError: 'لا يمكن حذف تقرير تم ترحيله بالفعل',

      postingDate: 'تاريخ الترحيل',

      postingDateRequired: 'تاريخ الترحيل مطلوب',


      purchaseGrpoDocumentTitle: 'مستند الاستلام',

      purchaseGrpoDraftTitle: 'مسودة مستند الاستلام',

      purchaseGrpoKicker: 'عمليات الاستلام',

      quantity: 'الكمية',

      quantityMustBeGreaterThanZero: 'يجب أن تكون الكمية أكبر من الصفر',

      quantityRequired: 'الكمية مطلوبة',

      receivingButton: 'بدء فحص الاستلام الخام ←',

      receivingSubtitle: 'فحص شاحنات وتشغيلات الخام الواردة للمصنع',

      receivingTitle: 'فحص استلام الخام (Receiving)',

      scaleDraftNumber: 'رقم مسودة الميزان',

      scaleItem: 'الصنف',

      scalePendingDrafts: 'مسودات الميزان الجاهزة للاستلام',

      scalePendingDraftsDesc: 'يمكن بدء عملية الاستلام من هنا، مع تعبئة بيانات السيارة والمورد والصنف والوزن مسبقًا.',

      scaleSupplier: 'المورد',

      scaleVehicleTruck: 'السيارة / الشاحنة',

      scaleWeight: 'الوزن',

      kgUnit: 'كجم',

      reloadDraft: 'إعادة تحميل المسودة',

      sapDocEntry: 'رقم المرجع',

      sapDocNum: 'رقم المستند بـ SAP (DocNum)',

      sapStatus: 'حالة SAP',

      selectWarehouse: '— اختر المخزن —',

      selectWarehouseFirst: 'يرجى اختيار المخزن أولاً',

      selectBinLocation: '— اختر الخلية التخزينية —',

      title: 'فحص الجودة',

      desc: 'إجراء فحوصات الجودة وتسجيل العيوب والآفات للتشغيلات.',

      headerKicker: 'إيجاست لإدارة الجودة',

      start: 'بدء الفحص الفني',

      startBtn: 'بدء الفحص الفني',

      stepBatch: 'البحث عن التشغيلة',

      stepInfo: 'بيانات الفحص',

      stepFarm: 'المزرعة / المنشأ',

      stepCount: 'إعداد العينات',

      stepSamples: 'فحص العينات',

      stepReview: 'المراجعة والتدقيق',

      stepResults: 'لوحة النتائج',

      stepPrint: 'طباعة التقرير',

      stepDone: 'طباعة التقرير',

      catPests: 'الآفات الزراعية والعيوب الحشرية (Pests)',

      catMechanical: 'العيوب الميكانيكية (Mechanical)',

      catOthers: 'العيوب الفسيولوجية',
      catGrades: 'درجات الجودة',

      colStatus: 'الحالة',

      colBatch: 'رقم التشغيلة',

      colItem: 'كود الصنف',

      colProduct: 'اسم المنتج',

      colDate: 'التاريخ',

      colInspector: 'المفتش',

      colDecision: 'القرار',

      colDefects: 'العيوب',

      colActions: 'العمليات',

      loadFailed: 'فشل تحميل تقارير الفحص.',

      rejectTitle: 'رفض تقرير الفحص رقم ',

      rejectReason: 'سبب الرفض',

      rejectPlaceholder: 'أدخل سبب رفض تقرير الفحص...',

      confirmReject: 'تأكيد الرفض',

      rejecting: 'جاري الرفض...',

      approveSuccess: 'تم اعتماد تقرير الفحص وترحيله بنجاح إلى SAP.',

      rejectSuccess: 'تم رفض تقرير الفحص بنجاح.',

      deleteSuccess: 'تم حذف تقرير الفحص بنجاح.',

      savedDraft: 'تم حفظ المسودة بنجاح.',

      resetConfirm: 'هل أنت متأكد من إعادة التعيين؟ سيتم مسح كافة البيانات المدخلة.',

      totalSamples: 'إجمالي العينات المفحوصة',

      totalDefects: 'إجمالي كمية العيوب',

      commonDefect: 'العيب الأكثر شيوعاً',

      qaDecision: 'قرار الجودة النهائي',

      averageDefects: 'متوسط العيوب / عينة',

      quarantineViolation: 'مخالفة عيوب حجرية',

      quarantineViolationDesc: 'تم اكتشاف عفن في فحص العينة.',

      excelMatrix: 'ورقة ملخص الفحص الإحصائي (Excel QA Sheet)',

      pctBruisesCuts: 'متوسط نسبة الجروح و الكدمات',

      pctHighCut: 'متوسط نسبة القص العالى تصل إلى',

      wasteTotal: 'إجمالي الهدر / Waste Total (AF)',

      qualityTotal: 'إجمالي الجودة / Quality Total (AG)',

      grandTotal: 'الإجمالي العام / Grand Total (AH)',

      pass: 'مقبول',

      fail: 'مرفوض',

      approved: 'معتمد',

      rejected: 'مرفوض',

      draftSaved: 'تم حفظ المسودة',

      draftAutoSaved: 'مسودة محفوظة تلقائياً',

      printReport: 'طباعة التقرير',

      exportJson: 'تصدير JSON',

      postToSap: 'اعتماد وترحيل',

      posting: 'جاري الترحيل...',

      rejectionReason: 'سبب الرفض',

      comments: 'تعليقات',

      notes: 'ملاحظات',

      searchPlaceholder: 'البحث برقم التشغيلة...',

      filterStatus: 'تصفية حسب الحالة',

      additionalNotes: 'ملاحظات وشروط استلام الشحنة',

      approve: 'قبول واعتماد الشحنة وترحيلها',

      approveConfirm: 'هل أنت متأكد من رغبتك في اعتماد وترحيل تقرير فحص الجودة هذا إلى SAP؟',

      approveError: 'حدث خطأ أثناء اعتماد وترحيل تقرير الفحص.',

      approveFailed: 'فشل ترحيل تقرير الفحص.',

      batchFound: 'تم تحميل تفاصيل التشغيلة بنجاح.',

      batchNotFoundErr: 'رقم التشغيلة غير مسجل بنظام الإنتاج المحلي أو SAP. لا يمكن متابعة الفحص الفني بدون رقم تشغيلة صالح.',

      batchNumber: 'رقم التشغيلة',

      batchRequired: 'رقم التشغيلة مطلوب.',

      breakdown: 'تفصيل العيوب',

      carNumber: 'رقم السيارة',

      colInspectionId: 'رقم الفحص',

      confirmSaveReport: 'تأكيد وحفظ التقرير',

      contractorName: 'اسم المقاول',

      contractor: 'المقاول',

      cropName: 'الخام / المحصول',

      dataClerkName: 'اسم مدخل البيانات',

      decreaseSamples: 'تقليل العينات',

      defectCodeCategory: 'تصنيف العيب',

      editInspection: 'تعديل الفحص',

      enterBatchNumber: 'الرجاء إدخال رقم التشغيلة.',

      excelMatrixDesc: 'المؤشرات الإحصائية ونسب تصنيف الجودة العامة للتشغيلة.',

      farmOrigin: 'اسم المزرعة',

      farm: 'المزرعة / المنشأ',

      finishInspection: 'إنهاء الفحص وعرض النتائج',

      increaseSamples: 'زيادة العينات',

      infoDesc: 'إدخال البيانات الأساسية للشحنة والمورد وكود الصنف لربط التقرير.',

      inspectingSample: 'فحص عينة عشوائية',

      inspectionDate: 'تاريخ الفحص',

      inspectorName: 'اسم المفتش المسؤول',

      inspectorPlaceholder: 'اسم مفتش الجودة المسؤول عن الفحص',

      inspectorRequired: 'اسم المفتش المسؤول مطلوب.',

      itemCode: 'كود الصنف',

      loadingReports: 'جاري تحميل تقارير الفحص...',

      nextSample: 'العينة التالية ←',

      noDefectsRecorded: 'لا توجد عيوب مسجلة',

      noReports: 'لم يتم العثور على تقارير فحص الجودة.',

      notesPlaceholder: 'أية ملاحظات إضافية بخصوص حالة التعبئة والتغليف، الحاوية، الرطوبة، درجة الحرارة...',

      productName: 'اسم المنتج',

      rawMaterialType: 'نوع الخام',

      refresh: 'تحديث',

      refreshing: 'جاري التحديث...',

      reject: 'رفض',

      rejectFailed: 'فشل رفض تقرير الفحص.',

      rejectReasonRequired: 'سبب الرفض مطلوب.',

      releaseWarehouseLabel: 'مخزن الإفراج',

      releaseWarehouseDefault: '— اختر مخزن الإفراج —',

      returnHome: 'العودة للرئيسية',

      backToReview: 'العودة لمراجعة الجودة',

      reviewDashboardTitle: 'لوحة مراجعة واعتماد تقارير فحص الجودة',

      reviewDesc: 'الرجاء تدقيق ومراجعة بيانات عيوب العينات قبل حفظ واعتماد التقرير.',

      sampleCountQuestion: 'إجمالي عدد عينات الفحص الإحصائي',

      sampleDefectsTotal: 'إجمالي كمية عيوب العينة',

      sampleEntryDesc: 'تسجيل كميات العيوب المكتشفة في كل عينة مفحوصة',

      sampleLabel: (id) => `عينة ${id}`,

      sampleNumber: 'العينة',

      sampleOf: (current, total) => `العينة ${current} من أصل ${total}`,

      sampleSetupDesc: 'إعداد وتحديد حجم عينة الفحص العشوائية لتقرير مراقبة الجودة.',

      sampleSetupHint: 'سيتم إنشاء شاشات إدخال عيوب منفصلة لكل عينة بصورة ديناميكية لتسهيل عملية الفحص.',

      saveSuccess: 'تم حفظ تقرير فحص الجودة بنجاح.',

      saveSuccessTitle: 'تم حفظ الفحص بنجاح',

      saveSuccessDesc: 'تم حفظ تقرير فحص الجودة الفني في النظام.',

      searchDesc: 'الرجاء البحث عن رقم التشغيلة للتحقق من وجودها بالإنتاج أو SAP لبدء الفحص الفني.',

      searchTitle: 'البحث عن التشغيلة',

      searching: 'جاري البحث والتحقق...',

      startDefects: 'بدء إدخال العيوب ←',

      startNewInspection: 'بدء فحص جديد',

      statusAll: 'الكل',

      statusFailed: 'فشل الترحيل',

      statusPendingReview: 'قيد المراجعة',

      statusPosted: 'تم الترحيل لـ SAP',

      statusCompleted: 'مكتمل',

      statusInProgress: 'قيد التنفيذ',

      statusNotStarted: 'لم يبدأ',

      submitFailed: 'فشل في حفظ وإرسال تقرير الفحص.',

      submitNetworkError: 'فشل الاتصال بالخادم لإرسال تقرير الفحص.',

      submitSuccess: 'تم حفظ تقرير فحص الجودة بنجاح وهو بانتظار المراجعة والاعتماد.',

      submitting: 'جاري الحفظ والترحيل...',

      supplierName: 'اسم المورد',

      totalReports: 'إجمالي تقارير الجودة',

      unit: 'وحدة',

      unitOfMeasure: 'وحدة القياس',

      unitPrice: 'سعر الوحدة',

      unitPriceRequired: 'سعر الوحدة مطلوب',

      uomRequired: 'وحدة القياس مطلوبة',

      taxCode: 'كود الضريبة',

      taxCodeRequired: 'كود الضريبة مطلوب',

      selectTaxCode: 'اختر كود الضريبة',

      loadingTaxCodes: 'جاري تحميل أكواد الضريبة...',

      loadTaxCodesFailed: 'فشل تحميل أكواد الضريبة',

      vendorCardCode: 'كود المورد',

      vendorCardCodeRequired: 'كود المورد مطلوب',

      vendorName: 'المورد / المزرعة',

      vendorNameRequired: 'اسم المورد مطلوب',

      warehouseRequired: 'المخزن مطلوب',

      viewDetails: 'عرض التفاصيل',

      viewReportTitle: 'عرض التقرير',

      viewResultsDashboard: 'لوحة النتائج الفنية',

      truckNumber: 'رقم السيارة',

      truckNumberRequired: 'رقم السيارة مطلوب',

      newTruck: 'سيارة جديدة',

      editTruck: 'تعديل بيانات السيارة',

      editTruckDetails: 'تعديل تفاصيل السيارة',

      editTruckDetailsTitle: 'تفاصيل السيارة',

      deleteTruckCard: 'حذف بطاقة السيارة',

      confirmRemoveTruck: 'هل أنت متأكد من رغبتك في إزالة هذه السيارة وتشغيلاتها؟',

      truckNotFound: 'السيارة غير موجودة',

      truckDetailsTitle: 'تفاصيل السيارة',

      selectItem: '— اختر الصنف —',

      autoGenerated: 'توليد تلقائي',

      continueInspection: 'استكمال الفحص',

      startInspection: 'بدء الفحص',

      editBatchNumber: 'تعديل رقم التشغيلة',

      deleteBatch: 'حذف التشغيلة',

      confirmRemoveBatch: 'هل أنت متأكد من حذف هذه التشغيلة؟',

      addBatch: 'إضافة تشغيلة',

      batchInfoDesc: 'بيانات التشغيلة والوزن',

      admissionDate: 'تاريخ الدخول',

      admissionDateRequired: 'تاريخ الدخول مطلوب',

      approveGrpoForPosting: 'اعتماد مسودة الاستلام',

      validationErrorsFound: 'يرجى تصحيح أخطاء الإدخال قبل المتابعة',

      selectedBin: 'خلية التخزين المحددة',

      warehouseBinDesc: 'تحديد المخزن والخلية',

      truckLabel: 'السيارة',

      trucksBreakdown: 'تفصيل السيارات',

      defects: {

        acarus: 'اكاروس',

        scale_insect: 'حشرة قشرية',

        spray_marks: 'أثار رش',

        citrus_rust: 'صدأ موالح',

        thrips: 'تربس',

        vegetable_defects: 'خضار',

        gummosis: 'تصمغ',

        oil_spots: 'بقع زيتية',

        sunburn: 'لسعة الشمس',

        sooty_mold: 'فطر هبابي',

        mealybug: 'بق دقيقى',

        tearing: 'تنتيش',

        high_cut: 'قص عالى',

        bruises: 'كدمات',

        cuts: 'جروح',

        under_size: 'اندر',

        venting: 'تنفيس',

        fruit_fly: 'ذبابة',

        creasing: 'تبحير',

        fall_drop: 'سقط',

        mutations: 'طفرات',

        navel_blight: 'فتق سرة',

        softness: 'ليونه',

        molds: 'اعفان',

        grade_1: 'درجة اولى',

        grade_2: 'درجة ثانيه',

      },

      decisions: {

        'Accepted': 'مقبول تماماً (شحنة ممتازة)',

        'Conditionally Accepted': 'قبول مشروط (إعادة فرز)',

        'Rejected (Tolerable Boundary Exceeded)': 'مرفوض (تجاوز حد القبول)',

        'Rejected (Quarantine Defects)': 'مرفوض قطعيّاً (عيوب حجرية)'

      },

      batchExistsInSap: 'رقم التشغيلة موجود بالفعل في SAP لهذا الصنف.',

      batchChecking: 'جارٍ التحقق من التشغيلة في SAP...',

      scaleTicket: 'تذكرة الميزان',

      selectScaleTicket: 'اختر تذكرة وزن من الميزان (اختياري)...',

      selectSupplier: 'اختر المورد أو المزرعة...',

      selectContractor: 'اختر المقاول (اختياري)...',

      farmFilterAll: 'الكل',

      farmFilterCompany: 'مزارع الشركة',

      farmFilterSuppliers: 'موردين خام',

      selectItemGroup: 'اختر مجموعة الأصناف...',

      itemGroup: 'مجموعة الأصناف',

      manualTruckNumber: 'رقم السيارة / الشاحنة',

      selectBin: 'اختر مكان التخزين (اختياري)...',

    },

    grpo: {

      title: 'الاستلام',

      subtitle: 'إدارة استلام البضائع من أوامر الشراء للشحنات الواردة',

      pendingShipments: 'الشحنات المعلقة',

      pendingShipmentsDesc: 'الشحنات الواردة بانتظار توثيق عملية الاستلام',

      noPendingShipments: 'لا توجد شحنات استلام معلقة',

      noPendingShipmentsDesc: 'تم توثيق جميع الشحنات الواردة أو لا توجد شحنات مؤهلة حالياً.',

      openGrpo: 'فتح الاستلام',

      backToPending: 'العودة إلى الشحنات المعلقة',

      kicker: 'استلام بضائع من أمر شراء',

      searchPlaceholder: 'بحث برقم التشغيلة، السيارة، المورد، أو الصنف...',

      refresh: 'تحديث',

      batchNumber: 'رقم التشغيلة / الأمر',

      vehicleTruck: 'السيارة / الشاحنة',

      supplier: 'المورد',

      item: 'المنتج / الصنف',

      quantity: 'الكمية',

      warehouse: 'المخزن',

      inspectionDate: 'تاريخ الفحص',

      scaleDate: 'تاريخ الوزن',

      scaleDraftNumber: 'تذكرة الميزان',

      sourceScale: 'الميزان',

      sourceScaleDesc: 'شحنة موزونة مباشرة من الميزان البسكول',

      sourceQuality: 'فحص الجودة',

      sourceQualityDesc: 'شحنة مفحوصة من الجودة',

      certifiedWeight: 'الوزن الصافي المعتمد',

      status: 'الحالة',

      statusDraft: 'مسودة استلام',

      statusApprovedForPosting: 'معتمد للترحيل',

      statusPostingFailed: 'فشل الترحيل',

      statusPosted: 'تم تسجيل المستند',

      statusReady: 'جاهز للاستلام',

      openFailed: 'فشل في فتح مسودة الاستلام',

      deleteConfirmTitle: 'حذف مسودة الاستلام',

      confirmDelete: 'هل أنت متأكد من رغبتك في حذف مسودة الاستلام هذه؟ لا يمكن التراجع عن هذا الإجراء.',

      draftDeleted: 'تم حذف مسودة الاستلام بنجاح.',

      deleteFailed: 'فشل حذف مسودة الاستلام.',

      loading: 'جارٍ تحميل الشحنات المعلقة...',

      errorLoading: 'تعذر تحميل الشحنات المعلقة',

      countShipments: (n) => `${n} شحنة معلقة`,

      reviewTitle: 'مراجعة الاستلام',

      reviewSubtitle: 'عرض ومراجعة مستندات الاستلام المكتملة',

      reviewStep: 'المراجعة والتسجيل',

      documentStatus: 'حالة المستند',

      referenceNumber: 'رقم المرجع',

      manualSupplierDesc: 'اختر المورد أو المزرعة من السجلات المتاحة.',

      manualProductDesc: 'اختر مجموعة الأصناف والصنف. يتم تحديد وحدة القياس تلقائياً.',

      batchAlreadyRegistered: 'رقم التشغيلة مسجل بالفعل للصنف المحدد.',

      batchChecking: 'جارٍ التحقق من رقم التشغيلة...',

      noCompletedGrpos: 'لا توجد مستندات استلام مكتملة',

      noCompletedGrposDesc: 'لم يتم تسجيل أي مستندات استلام حتى الآن.',

      countCompletedGrpos: (n) => `${n} مستند استلام مكتمل`,

      viewDocument: 'عرض مستند الاستلام',

      grpoNumber: 'رقم المستند',

      postedDate: 'تاريخ الترحيل',

      sapDocInfo: 'رقم المرجع',

      backToReview: 'العودة إلى مراجعة الاستلام',

      manualReceiving: 'استلام يدوي',

      manualReceivingTitle: 'إنشاء طلب استلام يدوي',

      manualReceivingDesc: 'إدخال تفاصيل الشحنة والأصناف للاستلام اليدوي.',

      manualBadge: 'يدوي',

      manualBadgeDesc: 'طلب استلام يدوي',

      carNumber: 'رقم السيارة / الشاحنة',

      carNumberPlaceholder: 'مثال: 1234 أ ب ج',

      vendorName: 'اسم المورد / الشركة',

      vendorNamePlaceholder: 'مثال: شركة الأمل للتوريدات',

      vendorCardCode: 'كود المورد (اختياري)',

      vendorCardCodePlaceholder: 'مثال: V10001',

      itemCode: 'كود الصنف (اختياري)',

      itemCodePlaceholder: 'مثال: RM-TOMATO-01',

      itemName: 'اسم / وصف الصنف',

      itemNamePlaceholder: 'مثال: طماطم فرز أول',

      quantityLabel: 'الكمية',

      uom: 'وحدة القياس',

      warehouseSelect: 'المخزن المستلم',

      selectWarehouse: 'اختر المخزن...',

      batchNumberInput: 'رقم التشغيلة / الأمر',

      batchNumberPlaceholder: 'مثال: B-2026-001',

      notesLabel: 'ملاحظات (اختياري)',

      notesPlaceholder: 'أي ملاحظات إضافية بخصوص الشحنة...',

      submitManualReceiving: 'إنشاء وفتح الاستلام',

      creatingManualReceiving: 'جارٍ إنشاء الاستلام...',

      manualReceivingSuccess: 'تم إنشاء طلب الاستلام بنجاح، جارٍ فتح مسودة الاستلام...',

      validationError: 'يرجى ملء جميع الحقول المطلوبة بشكل صحيح',

      continuousWorkflow: 'منظومة الاستلام المتكاملة',

      phase1Badge: 'المرحلة 1: الاستلام اليدوي',

      phase2Badge: 'المرحلة 2: سند الاستلام والترحيل',

      phase1Kicker: 'المرحلة 1 من 2 (الاستلام اليدوي)',

      phase2Kicker: 'المرحلة 2 من 2 (مراجعة مستند الاستلام)',

      phase1: 'المرحلة الأولى',

      phase1Completed: 'المرحلة الأولى مكتملة',

      phase2: 'المرحلة الثانية',

      steps1to6: 'الخطوات 1 – 6',

      steps7to10: 'الخطوات 7 – 10',

      steps7to11: 'الخطوات 7 – 11',

      steps7to12: 'الخطوات 7 – 12',

      manualPhaseTitle: 'الاستلام اليدوي',

      manualIntakePhaseBadge: 'الاستلام اليدوي',

      steps1to10: 'الخطوات 1 – 10',

      continuousStepProgress: (arg) => {

        const step = typeof arg === 'object' && arg !== null ? arg.step || 1 : (arg || 1);

        return `الخطوة الحالية: ${step} من 10 (الاستلام اليدوي وتسجيل المستند)`;

      },

      phase1Title: 'إدخال بيانات الاستلام اليدوي',

      phase2Title: 'مراجعة مستند الاستلام وتسجيله',

      phase1DescActive: (arg) => {

        const step = typeof arg === 'object' && arg !== null ? arg.step || 1 : (arg || 1);

        return `الخطوة الحالية: ${step} من 6 (بيانات الاستلام)`;

      },

      phase2DescActive: (arg) => {

        const step = typeof arg === 'object' && arg !== null ? arg.step || 7 : (arg || 7);

        return `الخطوة الحالية: ${step} من 10 (المراجعة المالية والترحيل)`;

      },

      phase2DescUpcoming: 'المرحلة التالية بعد مراجعة بيانات الاستلام وإنشاء المسودة.',

      submitManualAndProceedToGrpo: 'إنشاء المسودة والمتابعة إلى مراجعة الاستلام',

      manualIntakeNotice: 'تم حفظ بيانات الاستلام اليدوي بنجاح. راجع بنود المستند والتسعير والمستودع أدناه قبل التسجيل النهائي.',

      reviewPhase1Prompt: 'بعد مراجعة وتأكيد بيانات الاستلام، ستتابع إلى الخطوة 8 لإدخال بيانات التشغيل والتواريخ.',

    },

    shippingReceiving: {

      eyebrow: 'العمليات اللوجستية',

      title: 'الشحن والاستلام',

      subtitle: 'إدارة عمليات الشحن والاستلام واستلام البضائع والتسليم.',

      grpoTitle: 'الاستلام',

      grpoSubtitle: 'إدارة عمليات استلام البضائع والشحنات الواردة.',

      openGrpo: 'فتح الاستلام →',

      shippingDeliveryTitle: 'الشحن',

      shippingDeliverySubtitle: 'إدارة عمليات الشحن والتسليم للمزارع والموردين.',

      openShippingDelivery: 'فتح الشحن →',

    },

    shippingDelivery: {

      eyebrow: 'العمليات اللوجستية',

      title: 'الشحن والتسليم',

      subtitle: 'إدارة عمليات الشحن والتسليم والشحنات الصادرة للعملاء.',

      placeholderTitle: 'وحدة الشحن والتسليم',

      placeholderDesc: 'يتم حالياً تجهيز مسار عمل الشحن والتسليم. ستتوفر وظائف إدارة التسليم والشحن قريباً.',

      backToModule: 'العودة إلى الشحن والاستلام',

    },

    customizationDelivery: {

      printTotalQuantity: 'إجمالي الكمية',
      printTotalAmount: 'إجمالي القيمة',
      printSapCreated: 'تم إنشاء المستند في SAP Business One',
      printLineDetails: 'بنود المستند',
      checkingPosting: 'جاري التحقق من حالة المستند في SAP. لن تتم إعادة الترحيل.',
      checkPosting: 'التحقق من حالة المستند',
      pagination: 'صفحات المستندات',
      pageCounts: 'أعداد وحالات التسليم تخص الصفحة الحالية. استخدم التالي لاستعراض بقية الأوامر.',
      scrollTable: 'مرّر الجدول أفقيًا لعرض جميع حقول الأصناف',

      eyebrow: 'عمليات المبيعات',

      title: 'التخصيص والتسليم',

      subtitle: 'إدارة دورة البيع من عرض السعر حتى التسليم',

      quotationsTitle: 'عروض الأسعار',

      quotationsSubtitle: 'إنشاء وإدارة عروض الأسعار',

      createQuotation: 'إنشاء عرض سعر →',

      openQuotations: 'فتح عروض الأسعار →',

      ordersTitle: 'أوامر البيع',

      ordersSubtitle: 'تحويل عروض الأسعار المعتمدة إلى أوامر بيع',

      salesQuotationsReviewTitle: 'مراجعة عروض الأسعار',

      salesQuotationsReviewEyebrow: 'المرحلة ١: عروض أسعار البيع',

      salesQuotationsReviewSubtitle: 'مراجعة عروض أسعار البيع ومتابعة حالات دورة الاعتماد.',

      allQuotations: 'كل عروض الأسعار',

      noQuotationsFound: 'لا توجد عروض أسعار بيع',

      noQuotationsDesc: 'لا توجد مسودات عروض أسعار تطابق الفلاتر المحددة.',

      salesOrdersReviewTitle: 'مراجعة أوامر البيع',

      salesOrdersReviewEyebrow: 'المرحلة ٢: أوامر البيع',

      salesOrdersReviewSubtitle: 'مراجعة أوامر البيع المنشأة من عروض الأسعار المعتمدة.',

      deliveryReviewTitle: 'مراجعة التسليمات',

      deliveryReviewSubtitle: 'مراجعة مستندات التسليم المكتملة والمنشأة من أوامر البيع.',

      deliveryReviewAnalyticsSubtitle: 'تحليل التسليمات المرحلة حسب التاريخ والعميل وأمر البيع والصنف.',

      reportFilters: 'فلاتر التقرير',

      dateFrom: 'من تاريخ',

      dateTo: 'إلى تاريخ',

      allCustomers: 'كل العملاء',

      allSalesOrders: 'كل أوامر البيع',

      allItems: 'كل الأصناف',

      item: 'الصنف',

      applyFilters: 'تطبيق الفلاتر',

      resetFilters: 'إعادة ضبط الفلاتر',

      appliedFilters: 'الفلاتر المطبقة',

      filter_dateFrom: 'من تاريخ',

      filter_dateTo: 'إلى تاريخ',

      filter_customer: 'العميل',

      filter_salesOrder: 'أمر البيع',

      filter_item: 'الصنف',

      printReport: 'طباعة التقرير',

      printDelivery: 'طباعة التسليم',

      printQuotation: 'طباعة عرض السعر',

      printSalesOrder: 'طباعة أمر البيع',

      printDocument: 'طباعة المستند',

      deliveryReport: 'تقرير التسليمات',

      deliveryDocument: 'مستند التسليم',

      quotationDocument: 'عرض سعر المبيعات',

      salesOrderDocument: 'أمر بيع المبيعات',

      reportGeneratedAt: 'تاريخ ووقت إنشاء التقرير',

      uom: 'الوحدة',

      quantity: 'الكمية',

      unitPrice: 'سعر الوحدة',

      lineTotal: 'الإجمالي',

      deliverySummary: 'ملخص التسليمات',

      summary_deliveries: 'التسليمات',

      summary_quantity: 'الكمية المسلمة',

      summary_customers: 'العملاء',

      summary_salesOrders: 'أوامر البيع',

      summary_items: 'الأصناف',

      byCustomer: 'حسب العميل',

      byItem: 'حسب الصنف',

      bySalesOrder: 'حسب أمر البيع',

      byDate: 'حسب التاريخ',

      deliveryDetails: 'تفاصيل التسليمات',

      allPostedDeliveries: 'كل التسليمات المرحلة',

      filteredDeliveryDetails: 'تفاصيل التسليمات المفلترة',

      noMatchingDeliveries: 'لا توجد تسليمات مرحلة تطابق الفلاتر المطبقة.',

      deliveryReviewSearch: 'بحث برقم التسليم أو أمر البيع أو العميل أو الصنف...',

      deliveryReviewEmpty: 'لا توجد تسليمات مكتملة',

      deliveryReviewEmptyDescription: 'ستظهر مستندات التسليم المكتملة هنا بعد إنشائها بنجاح.',

      deliveryNumber: 'رقم التسليم',

      deliveryDocEntry: 'رقم SAP الداخلي للتسليم',

      sourceSalesOrder: 'أمر البيع',

      customer: 'العميل',

      items: 'الأصناف',

      deliveredQuantity: 'الكمية المسلمة',

      deliveryStatus: 'الحالة',

      deliveryDate: 'تاريخ التسليم',

      deliveryCreated: 'تم إنشاء التسليم',

      deliveryReviewReadOnly: 'تُعرض مستندات التسليم المكتملة في وضع القراءة فقط.',

      openOrders: 'فتح أوامر البيع →',

      customizationTitle: 'التخصيص',

      customizationSubtitle: 'مراجعة عروض أسعار العملاء وبنودها.',

      openCustomization: 'فتح التخصيص →',

      customizationListSubtitle: 'عروض الأسعار المسجلة في SAP. افتح أي مستند لعرض بنوده.',

      deliveryTitle: 'التسليم',

      deliverySubtitle: 'مراجعة أوامر بيع العملاء وبنودها.',

      openDelivery: 'فتح التسليم →',

      deliveryListSubtitle: 'أوامر البيع المسجلة في SAP. افتح أي مستند لعرض بنوده.',

      detailSubtitle: 'تفاصيل المستند كما هي مسجلة في SAP.',

      readOnlyNote: 'للقراءة فقط. لا يمكن لهذه الوحدة إنشاء أو تعديل المستندات في SAP.',

      noDocuments: 'لا توجد مستندات',

      noQuotations: 'لا توجد عروض أسعار لعرضها.',

      noOrders: 'لا توجد أوامر بيع لعرضها.',

      emptyFiltered: 'لا توجد مستندات مطابقة للمرشحات المحددة.',

      noItems: 'لا يحتوي هذا المستند على بنود.',

      moreAvailable: 'توجد مستندات أخرى. قم بتضييق المرشحات لعرضها.',

      section: {

        summary: 'المستند',

        items: 'البنود',

      },

      status: {

        open: 'مفتوح',

        closed: 'مغلق',

        paid: 'مدفوع',

        delivered: 'تم التسليم',

      },

      filters: {

        status: 'الحالة',

        allStatuses: 'كل الحالات',

        dateFrom: 'من',

        dateTo: 'إلى',

        clear: 'مسح المرشحات',

      },

      columns: {

        documentNumber: 'رقم المستند',

        customer: 'العميل',

        status: 'الحالة',

        currency: 'العملة',

        quotationDate: 'تاريخ عرض السعر',

        validUntil: 'صالح حتى',

        orderDate: 'تاريخ الطلب',

        dueDate: 'تاريخ الاستحقاق',

        documentDate: 'تاريخ المستند',

        line: 'السطر',

        item: 'الصنف',

        description: 'الوصف',

        quantity: 'الكمية',

        unit: 'الوحدة',

        warehouse: 'المخزن',

        location: 'الموقع',

        unitPrice: 'سعر الوحدة',

        lineTotal: 'إجمالي السطر',

      },

      workflow: {

        customizeQuotation: 'تخصيص عرض السعر',

        createDelivery: 'إنشاء إذن تسليم',

        draftTitle: 'مسودة التخصيص',

        deliveryDraftTitle: 'مسودة التسليم',

        customizedQuantity: 'الكمية المخصصة',

        customizedPrice: 'سعر الوحدة المخصص',

        specification: 'المواصفات',

        brand: 'العلامة التجارية',

        packaging: 'التعبئة والتغليف',
        notes: 'الملاحظات',
        sourceQuotation: 'عرض السعر المصدر',

        saveDraft: 'حفظ التغييرات',

        submitReview: 'إرسال للمراجعة',

        approve: 'اعتماد',

        reject: 'رفض',

        syncQuotation: 'تحديث عرض السعر في SAP',

        customerApproval: 'موافقة العميل',

        recordCustomerApproval: 'تسجيل موافقة العميل',

        approvalType: 'نوع إثبات الموافقة',

        referenceNumber: 'رقم أمر الشراء / المرجع',

        contactPerson: 'المسؤول لدى العميل',

        createOrder: 'إنشاء أمر البيع',

        salesOrderCreated: 'تم إنشاء أمر البيع في SAP',

        deliveryCreated: 'تم إنشاء إذن التسليم في SAP',

        postDelivery: 'ترحيل إذن التسليم إلى SAP',

        batches: 'التشغيلات ومواقع التخزين',

        batchNumber: 'رقم التشغيلة',

        binCode: 'موقع التخزين',

        allocatedQuantity: 'الكمية المخصصة',

        addBatch: 'إضافة تشغيلة',

        orderQuantity: 'كمية الطلب',

        openQuantity: 'الكمية المتبقية',

        deliveryQuantity: 'كمية التسليم',

        notes: 'ملاحظات',

        rejectionReason: 'سبب الرفض',

        relationshipMapInfo: 'مرتبط أصلياً في خريطة العلاقات بـ SAP Business One',

        poApproval: 'أمر شراء من العميل',

        signedDocApproval: 'عرض سعر موقع',

        emailApproval: 'تأكيد كتابي بالبريد الإلكتروني',

        unselectedNotice: 'البنود غير المحددة تظل مفتوحة في عرض السعر في SAP ولن يتم تضمينها في أمر البيع.',

        viewOrder: 'عرض أمر البيع',

        viewQuotation: 'عرض عرض السعر',

        sourceQuotation: 'عرض السعر المصدر',

        costingDimensions: 'أبعاد مراكز التكلفة (تكلفة البضاعة المباعة)',

        deliveryHistory: 'سجل أذون التسليم',

        createAnotherDelivery: 'إنشاء إذن تسليم آخر',

        confirmLinesForOrder: 'تأكيد البنود للطلب',

        diffOriginal: 'الأصلي',

        diffCustomized: 'المخصص',

        freeText: 'نص حر',

        actions: 'إجراءات',

        customize: 'تخصيص',

        deliver: 'تسليم',

        openQty: 'الكمية المفتوحة',

        deliveredQty: 'الكمية المسلمة',

        lineStatus: 'حالة السطر',

        statusOpen: 'مفتوح',

        statusClosed: 'مغلق',

        batchSumMismatch: 'مجموع كميات التشغيلات يجب أن يطابق كمية التسليم',

        relationshipChain: 'سلسلة علاقات SAP الأصلية',

      },

      wizard: {

        step1Customer: 'العميل',

        step2Items: 'الأصناف',

        step3Commercial: 'البيانات التجارية والمستودع',

        step4Logistics: 'الخدمات اللوجستية',

        step5Specs: 'المواصفات والتخصيص',

        step6Review: 'المراجعة والتحقق',

        step7Confirm: 'التأكيد والإنشاء',

        delivStep1Order: 'بيانات أمر البيع',

        delivStep2Quantities: 'كميات التسليم',

        delivStep3Batches: 'تخصيص التشغيلات',

        delivStep4Bins: 'مواقع التخزين',

        delivStep5Dimensions: 'مراكز التكلفة',

        delivStep6Review: 'المراجعة والتسليم',

      },

      workflowGuidanceNote: 'متصل بطبقة خدمات SAP Business One. اختر مستنداً لبدء أو متابعة سير عمل التخصيص والتسليم.',

    },

    purchaseQuotation: {

      kicker: 'عمليات الشحن',

      title: 'الشحن',

      desc: 'إنشاء وإدارة مستندات الشحن وعمليات التسليم.',

      newQuotation: 'مستند شحن جديد',

      searchPlaceholder: 'البحث باسم المورد أو رقم المستند أو رقم المرجع...',

      records: 'سجلات',

      postedRecords: 'سجلات مرحلة',

      noQuotations: 'لم يتم العثور على مستندات شحن',

      noQuotationsDesc: 'ابدأ بإنشاء مستند شحن جديد.',

      noPostedRecords: 'لا توجد مستندات شحن مكتملة',

      noPostedRecordsDesc: 'ستظهر مستندات الشحن المكتملة هنا.',

      vendor: 'المورد',

      vendorCardCode: 'كود المورد',

      vendorName: 'اسم المورد',

      vendorRefNo: 'رقم مرجع المورد',

      currency: 'العملة',

      groupNo: 'رقم المجموعة',

      postingDate: 'تاريخ الترحيل',

      validUntil: 'صالح حتى',

      documentDate: 'تاريخ المستند',

      requiredDate: 'التاريخ المطلوب',

      buyerCode: 'المشتري / المندوب',

      ownerCode: 'المالك',

      journalRemark: 'ملاحظة القيد',

      remarks: 'ملاحظات',

      shipToAddress: 'عنوان الشحن والتسليم',

      payToAddress: 'عنوان الدفع / الفاتورة',

      totalBeforeDiscount: 'الإجمالي قبل الخصم',

      discountPct: 'نسبة خصم المستند %',

      discountAmount: 'مبلغ الخصم',

      freight: 'مصاريف الشحن',

      taxTotal: 'إجمالي الضريبة',

      rounding: 'التقريب',

      totalPaymentDue: 'إجمالي المبلغ المستحق',

      itemsCount: 'عدد الأصناف',

      items: 'أصناف',

      openDoc: 'فتح المستند',

      docTitle: 'مستند الشحن',

      headerInfo: 'البيانات الأساسية للمستند',

      saveDraft: 'حفظ كمسودة',

      approveAndPreview: 'اعتماد ومعاينة المستند',

      confirmPostToSap: 'تأكيد وتسجيل المستند',

      postingToSap: 'جارٍ تسجيل المستند...',

      cancelQuotation: 'إلغاء مستند الشحن',

      deleteConfirmTitle: 'حذف مسودة الشحن',

      confirmDelete: 'هل أنت متأكد من رغبتك في حذف مسودة الشحن هذه؟ لا يمكن التراجع عن هذا الإجراء.',

      draftDeleted: 'تم حذف مسودة الشحن بنجاح.',

      deleteFailed: 'فشل حذف مسودة الشحن.',

      draftCreated: 'تم إنشاء مسودة شحن جديدة.',

      draftSaved: 'تم حفظ المسودة بنجاح.',

      approvedForPosting: 'تم اعتماد مستند الشحن للتسجيل.',

      postSuccess: 'تم تسجيل المستند بنجاح!',

      cancelledSuccess: 'تم إلغاء مستند الشحن.',

      confirmCancel: 'هل أنت متأكد من رغبتك في إلغاء مستند الشحن هذا؟',

      loadFailed: 'فشل تحميل مسودة الشحن.',

      createFailed: 'فشل إنشاء مسودة الشحن.',

      saveFailed: 'فشل حفظ المسودة.',

      approvalFailed: 'فشل اعتماد المسودة للترحيل.',

      postFailed: 'فشل تسجيل المستند.',

      cancelFailed: 'فشل إلغاء المسودة.',

      errorLoading: 'فشل تحميل سجلات الشحن.',

      status_DRAFT: 'مسودة',

      status_PENDING_REVIEW: 'قيد المراجعة',

      status_APPROVED_FOR_POSTING: 'معتمد للترحيل',

      status_POSTED: 'مرحّل',

      status_POSTING_FAILED: 'فشل الترحيل',

      status_CANCELLED: 'ملغى',

      statusDraft: 'مسودة',

      statusApprovedForPosting: 'معتمد للترحيل',

      statusPostingFailed: 'فشل الترحيل',

      statusPosted: 'مرحّل',

      statusCancelled: 'ملغى',

      reviewTitle: 'ملخص ومراجعة الشحن',

      sapPayloadPreview: 'معاينة بيانات المستند',

      financialTotals: 'الإجماليات المحسوبة للمستند',

      documentOverview: 'نظرة عامة على المستند',

      financialSummary: 'الملخص المالي',

      documentLines: 'سطور المستند',

      sapVerification: 'التحقق من المستند',

      verifyWithSap: 'التحقق من المستند',

      readyToPost: 'جاهز للتسجيل',

      readyToPostDesc: 'مستند الشحن جاهز للتسجيل.',

      sapVerificationSuccess: 'تم التحقق من المستند بنجاح وهو جاهز للتسجيل.',

      clickVerifyPrompt: 'اضغط "التحقق من المستند" قبل التسجيل النهائي.',

      developerDetails: 'تفاصيل المستند التقنية',

      reviewLogTitle: 'مستندات الشحن المكتملة',

      reviewLogDesc: 'أرشيف لجميع مستندات الشحن المكتملة بنجاح.',

      sapDocNum: 'رقم المستند',

      postedBy: 'تم الترحيل بواسطة',

      itemNo: 'رقم الصنف',

      itemDesc: 'وصف الصنف',

      quotedDate: 'التاريخ المعروض (ShipDate)',

      quotedQty: 'الكمية المعروضة',

      requiredQty: 'الكمية المطلوبة',

      uom: 'وحدة القياس',

      unitPrice: 'سعر الوحدة',

      discPct: 'خصم %',

      warehouse: 'المستودع',

      location: 'الموقع',

      costCenter: 'مركز التكلفة العام (General)',

      lineTotal: 'إجمالي السطر',

      addLine: 'إضافة صنف جديد',

      removeLine: 'حذف السطر',

      pendingQuotations: 'مستندات الشحن والتسليم',

      vendorRequired: 'يرجى اختيار مورد للمتابعة.',

      vendorSearchPlaceholder: 'البحث عن مقاول بالاسم...',

      selectedVendor: 'المورد المحدد',

      vendorsFound: 'مورد متاح',

      noVendorsFound: 'لا يوجد موردون يطابقون بحثك.',

      selectVendorPrompt: 'اختر المورد من القائمة أدناه للمتابعة في إعداد مستند الشحن.',

      changeVendor: 'تغيير المورد',

      selectedItem: 'الصنف المحدد',

      itemRequiredPrompt: 'يرجى اختيار صنف من القائمة أدناه.',

      itemRequired: 'يرجى اختيار رقم الصنف (Item No.) لجميع السطور للمتابعة.',

      searchItemPlaceholder: 'البحث عن صنف بالكود أو الاسم...',

      noItemsFound: 'لم يتم العثور على أصناف مطابقة.',

      itemGroup: 'مجموعة الأصناف',

      selectItemGroup: 'اختر مجموعة الأصناف',

      selectItemGroupPrompt: 'اختر مجموعة الأصناف أعلاه لعرض عناصرها، أو استخدم البحث.',

      group: 'المجموعة',

      sectionItemGroup: '١. مجموعة الأصناف',

      sectionItem: '٢. الصنف',

      sectionItemDetails: '٣. تفاصيل الصنف والكميات',

      selectItemGroupFirst: 'يرجى اختيار مجموعة الأصناف أولاً.',

      selectItemFirst: 'يرجى اختيار صنف أعلاه لتحديد الكميات والتفاصيل.',

      availableSapItems: 'الأصناف المتاحة',

      lockedToVendorCurrency: 'مُثبت على عملة المورد',

      multiCurrency: 'متعدد العملات (اختر)',

      itemGroupStepDesc: 'اختر مجموعة الأصناف لكل سطر شحن لتحميل الأصناف المطابقة.',

      itemStepDesc: 'اختر الصنف المطلوب من قائمة الأصناف لكل سطر شحن.',

      itemDetailsStepDesc: 'تحديد الكميات المعروضة والمطلوبة والتواريخ والأسعار لكل صنف محدد.',

      itemGroupRequired: 'يرجى اختيار مجموعة الأصناف لجميع السطور للمتابعة.',

      invalidQuantities: 'يرجى إدخال كميات صحيحة لجميع السطور للمتابعة.',

      vehicleNumber: 'رقم العربية',

      vehicleNumberPlaceholder: 'أدخل رقم العربية / الشاحنة...',

      invalidVehicleNumber: 'رقم العربية لا يمكن أن يتجاوز 11 حرفاً.',

      containerQuantity: 'كمية الكونتينر',

      invalidContainerQty: 'كمية الكونتينر يجب أن تكون رقماً صحيحاً غير سالب.',

      vehicleAndContainer: 'بيانات العربية والكونتينر',

      vehicleAndContainerDesc: 'تحديد رقم العربية وكمية الحاوية / الكونتينر الخاصة بالشحنة.',

      steps: {

        vehicle: 'بيانات العربية والكونتينر',

        vendor: 'المورد',

        header: 'بيانات وتواريخ المستند',

        itemGroup: 'مجموعة الأصناف',

        item: 'الصنف',

        itemDetails: 'تفاصيل الصنف',

        contents: 'الأصناف والكميات',

        logistics: 'اللوجستيات ومراكز التكلفة',

        financial: 'البيانات المالية والملاحظات',

        review: 'المراجعة والترحيل',

      },

      tabs: {

        contents: 'المحتويات',

        logistics: 'اللوجستيات',

        accounting: 'المحاسبة',

        attachments: 'المرفقات',

      },

      attachmentsDesc: 'لا توجد مرفقات ملفات مرتبطة بمستند الشحن هذا.',

    },

  },

};



