# مراجعة ما قبل النشر — receipt_from_production

التاريخ: 20 أكتوبر 2026. المرجعان: [تقرير الاستقرار](STABILITY_REMEDIATION_REPORT_AR.md)، و[سجل الإخفاقات الأصلية](STABILITY_FAILURE_ROOT_CAUSES_AR.md).

## الحكم: غير جاهز للنشر حاليًا

إصلاحات الاستقرار نجحت مجددًا على PostgreSQL، والـmigrations قابلة للتطبيق والرجوع في قاعدة اختبار. لكن فحص الواجهة الأوسع ليس ناجحًا: اختبار مراجعة التحويل يتوقف عند استيراد ملف محذوف، وESLint وفحص الترجمة يفشلان، وثبتت أخطاء ReferenceError إضافية في كود الواجهة. لذلك لا يكفي اعتماد نتائج Django والبناء وحدهما للسماح بالنشر.

هذه **مراجعة وتحقق فقط**. لم أعدّل كود التطبيق أو الموديلات أو الاختبارات الأصلية أو migrations أو الملف التنفيذي. لم تُطبق migrations على قاعدة التشغيل، ولم يحدث نشر أو اعتماد أو ترحيل أو كتابة أعمال إلى SAP. أضفت أدوات وأدلة المراجعة داخل `scratch/predeploy/` وهذا التقرير فقط، مع استخدام قواعد اختبار مستقلة. رُصدت تعديلات متزامنة أخرى في الواجهة أثناء المراجعة؛ فُصلت أدناه ولم تُرجَع أو تُنسب إلى مهمة الاستقرار.

## نطاق تغييرات مهمة الاستقرار

قورنت حالة Git الحالية ببيان تسليم الاستقرار وبصماته؛ **كل ملفات البيان الثلاثين مطابقة**. راجعت الحالة غير المجهزة والمجهزة في Git، وفرق المهمة عن snapshot بدايتها. الاعتماد على `git diff HEAD` وحده لا يكفي: ملفات التطبيق والـmigrations المطلوبة كثيرة منها غير متتبعة أصلًا، وهي موجودة على القرص ولكن لن تدخل إصدارًا مبنيًا من Git ما لم تُضمَّن عمدًا. لم أعمل staging أو commit أو reset أو checkout أو حذف لتعديلات المستخدم.

تتوزع ملفات الاستقرار إلى **4 ملفات تطبيق/موديل، و2 migration، و18 ملف اختبار، و3 أدوات، و3 تقارير**. القائمة الكاملة أدناه؛ «موجود» يعني أنه كان موجودًا في snapshot بداية الاستقرار، حتى لو كان Git يعتبره untracked.

| File | Category | Existed at stability start |
|---|---|---|
| `backend/api/models_delivery.py` | application/model | yes |
| `backend/api/services/delivery_posting_service.py` | application/model | yes |
| `backend/scale/release.py` | application/model | new |
| `backend/scale/services/deployment_service.py` | application/model | yes |
| `docs/APPLICATION_PERFORMANCE_IMPLEMENTATION_AR.md` | documentation | yes |
| `docs/STABILITY_FAILURE_ROOT_CAUSES_AR.md` | documentation | new |
| `docs/STABILITY_REMEDIATION_REPORT_AR.md` | documentation | new |
| `backend/api/migrations/0065_delivery_one_active_order.py` | migration | new |
| `backend/api/migrations/0066_alter_transferwarehouserule_stage.py` | migration | new |
| `backend/audit_stability_failures.py` | review tool | new |
| `backend/measure_sap_readonly.py` | review tool | new |
| `backend/run_stability_tests.py` | review tool | new |
| `backend/api/tests.py` | test | yes |
| `backend/api/tests_cold_storage_outbound_api.py` | test | yes |
| `backend/api/tests_cold_storage_outbound_e2e.py` | test | yes |
| `backend/api/tests_delivery_creation_concurrency.py` | test | new |
| `backend/api/tests_delivery_workflow.py` | test | yes |
| `backend/api/tests_pending_transfer_posting_concurrency.py` | test | yes |
| `backend/api/tests_persisted_transfer_policy.py` | test | yes |
| `backend/api/tests_physical_transfer.py` | test | yes |
| `backend/api/tests_production_issue.py` | test | yes |
| `backend/api/tests_sales_quotation_currency.py` | test | yes |
| `backend/api/tests_sales_scope_regressions.py` | test | yes |
| `backend/api/tests_stage2_policy_positions.py` | test | yes |
| `backend/api/tests_transfer_policy.py` | test | yes |
| `backend/api/tests_transfer_policy_authority.py` | test | yes |
| `backend/api/tests_transfer_policy_migration.py` | test | yes |
| `backend/scale/tests.py` | test | yes |
| `backend/scale/tests_deployment.py` | test | yes |
| `backend/scale/tests_release_deployment.py` | test | yes |

الدليل: [مقارنة بيان التسليم](../scratch/predeploy/stability-delivery-check.json)، [حالة Git عند بداية المراجعة](../scratch/predeploy/git-status-before.txt)، [فرق الملفات المجهزة](../scratch/predeploy/git-staged-stat.txt)، [فرق المهمة بعد توحيد نهايات الأسطر للعرض فقط](../scratch/predeploy/stability-normalized.diff). لم تُوحَّد نهايات الأسطر في ملفات المصدر.

**تغييرات متزامنة خارج بيان الاستقرار:** فحص نهاية المراجعة رصد تغير `frontend/src/App.jsx` و`frontend/src/contexts/I18nContext.jsx` و`frontend/src/modules/transfer/components/ColdStorageMap.jsx` و`frontend/src/modules/transfer/pages/TransferPage.jsx`، وإضافة `frontend/src/components/common/ErrorBoundary.jsx`. تشمل إضافة ErrorBoundary حول المسارات، وحراسة لقيمة مسار الترجمة، وحراسات بيانات خريطة التخزين، واستيراد MapPin. لم تنتج من أوامر تعديل هذه المراجعة، ولم ألمسها. بقيت ملفات تسليم الاستقرار الثلاثون مطابقة لبصماتها. [فروق التغييرات المتزامنة](../scratch/predeploy/concurrent-changes.diff)، [فحص البصمات المؤرخ](../scratch/predeploy/final-integrity.json).

أُعيد **البناء فقط** بعد اكتشاف هذه التغييرات ونجح، exit 0؛ [السجل](../scratch/predeploy/build-current.log). الاختبارات الوظيفية السابقة لا تُعتمد تلقائيًا للتغييرات التي وصلت بعدها، ولم تُعد كل مجموعات الاختبارات على snapshot مجمدة من هذه الحالة الأحدث. يلزم تثبيت الإصدار وإعادة التحقق، وبخاصة التحويل والترجمة والمسارات والتعامل مع أخطاء العرض؛ وجود ErrorBoundary لا يغني عن التأكد من ظهور المحتوى الصحيح.

## migrations وبيانات قاعدة التشغيل المتاحة

الفحص اتصل بقاعدة PostgreSQL المكوّنة للمشروع في هذه البيئة، داخل transaction ينفذ `SET TRANSACTION READ ONLY`، وأكد الخادم `transaction_read_only=on`. هذه نتيجة القاعدة المتاحة هنا، وليست تأكيدًا على أي خادم نشر آخر لم يُحدد أو يُفحص.

- PostgreSQL **16.13**؛ آخر migration مطبق للتطبيق `api` هو `0064_quality_grade_category`.
- الخطة غير المطبقة تحتوي **0065 ثم 0066 فقط**؛ لا فروع متعارضة في graph.
- المسودات النشطة وقت الفحص: **0**؛ مجموعات الأوامر ذات أكثر من مسودة نشطة: **0**. لم تُحذف بيانات ولم تتغير حالات مسودات. يجب إعادة الفحص داخل نافذة النشر بعد إيقاف الكتابات لمنع سباق بين الفحص وإنشاء القيد.
- index الخاص بالقيد الجديد غير موجود حاليًا، كما يُتوقع قبل تطبيق 0065. وجود الكود الجديد وحده لا يفعّل الحماية الذرية في قاعدة التشغيل.

[نتائج الفحص للقراءة فقط](../scratch/predeploy/database-readonly.json).

| migration | الاعتماد | SQL على PostgreSQL | الأثر والرجوع |
|---|---|---|---|
| `0065_delivery_one_active_order` | `api.0064_quality_grade_category` | `CREATE UNIQUE INDEX delivery_one_active_order` على `sales_order_doc_entry` بشرط حالات DRAFT/PENDING_REVIEW/APPROVED/POSTING | يفرض قاعدة منع التكرار الموجودة بالخدمة. يرفض بيانات مكررة بدل تغييرها. الرجوع يزيل index فقط. |
| `0066_alter_transferwarehouserule_stage` | `api.0065_delivery_one_active_order` | **no-op** | يحدّث حالة choices التاريخية لتوافق Stage 4/5 الموجودة بالفعل في الموديل؛ لا SQL يغير الصفوف أو الصلاحيات على PostgreSQL. الرجوع يعيد حالة migration السابقة فقط. |

0065 يستخدم إنشاء index عاديًا داخل transaction، **وليس CONCURRENTLY**؛ إنشاء الفهرس قد يحجب INSERT/UPDATE/DELETE أثناء التنفيذ. لا يوجد تقدير زمني لنشره تحت حمل حقيقي. يلزم إيقاف الكتابات وميزانية انتظار أقفال معتمدة ومراقبتها، لا تشغيله عشوائيًا أثناء العمل.

أُنشئت قاعدة PostgreSQL محلية مستقلة باسم عشوائي `test_predeploy_*`، وجُرّبت الحالات التالية فعليًا:

1. الرجوع إلى 0064، وإنشاء صفين اختباريين نشطين لنفس الأمر: فشل 0065 بـIntegrityError، وبقي الصفان ولم تسجل migration كأنها نجحت.
2. معالجة **صف الاختبار فقط**، ثم تطبيق 0065 و0066: نجحا ورفض القيد إضافة مسودة نشطة منافسة.
3. الرجوع إلى 0064: أُزيل القيد دون تغيير صفوف الاختبار أو حالاتها؛ ثم أُعيد تطبيق 0065 و0066 بنجاح.
4. `makemigrations --check --dry-run`: `No changes detected`. أُزيلت قاعدة الاختبار بعد الانتهاء.

[سجل التجربة](../scratch/predeploy/migration-rehearsal.log)، [الخطوات المثبتة](../scratch/predeploy/migration-rehearsal.json)، [SQL 0065](../scratch/predeploy/0065_delivery_one_active_order.sql)، [رجوع 0065](../scratch/predeploy/0065_delivery_one_active_order-reverse.sql)، [SQL 0066](../scratch/predeploy/0066_alter_transferwarehouserule_stage.sql).

المحاولة الأولى لأداة التجربة توقفت قبل الاتصال بسبب تحميل متغيرات البيئة بعد قراءة بيانات الاتصال؛ صُححت أداة المراجعة فقط ثم أُعيدت التجربة بنجاح. [السجل الأول محفوظ](../scratch/predeploy/migration-rehearsal-initial.log)، ولا يُحسب اختبار migration ناجحًا.

## المشكلات المؤكدة والمتبقية

| الأولوية | المشكلة المثبتة | الأثر والتوصية قبل النشر |
|---|---|---|
| مانع | `frontend/src/components/delivery/DeliveryWorkflowPanel.jsx:531` يستخدم `lang` بينما hook في السطر 124 يسحب `t` فقط | أُعيد إنتاج **ReferenceError: lang is not defined** عند عرض مسودة DRAFT في المكون الحقيقي، بحالة محلية معلنة دون HTTP. المكون متصل بمسار تفاصيل التسليم. يلزم إصلاح محدد واختبار حالة المسودة في اللغتين؛ لم أعدّل التطبيق هنا. |
| متوسطة | `frontend/src/services/purchaseQuotationService.js:52`: `loadLocations()` يستدعي `loadCostCenters` دون binding محلي؛ إعادة التصدير في نهاية الملف ليست import | أُعيد إنتاج **ReferenceError: loadCostCenters is not defined** عند استدعائها. لم أجد مستهلكًا حاليًا لـ`loadLocations` في `frontend/src`؛ الأثر التشغيلي الفوري غير مثبت، لكن الدالة المصدرة معطلة ويجب معالجة العقد أو حذفها وفق قرار مستقل. |
| مانع تحقق | `frontend/scripts/test-transfer-review.mjs:47` يستورد `TransferReviewOperationsPage.jsx` غير الموجود | مجموعة Node تنتهي بكود 1. `App.jsx` يربط `/transfer-review` مباشرة بالصفحة الحالية، والمساران الفرعيان يحولان إليها. يلزم تحديث الاختبار للعقد الحالي مع الاحتفاظ بتغطية المراجعة، دون إنشاء صفحة وهمية. |
| مانع تحقق | ثلاثة اختبارات متصفح إضافية فشلت عند assertions | التفاصيل أدناه. يجب حسم توافق التوقعات والـfixtures مع الكود، والتحقق من سيناريو فقد ظهور الصنف والوصول لإجراء التسليم، قبل اعتبارها قديمة أو اعتبار الواجهة سليمة. لم تُغيّر توقعاتها لإنجاحها. |
| متوسطة | `npm run lint`: **76 error و12 warning** | ليست كلها أعطال runtime؛ منها إعداد Node globals وunused وReact hooks، ومنها خطآ الواجهة المثبتان أعلاه. التفاصيل كاملة في السجل، ولم يُستخدم `--fix` أو يُخفَ أي بند. |
| متوسطة | `npm run i18n:check` يفشل للمفتاح `grpo.openTimeoutRetrying` في اللغتين؛ استدعاؤه في `GRPOPage.jsx:106` | الدالة `t` الحالية لا تطبق النص الثاني كـfallback للمفتاح المفقود، فتُرجع اسم المفتاح. يلزم ترجمة صريحة واختبار رسالة مهلة GRPO. |
| منخفضة | `SalesQuotationCreatePage.jsx:868` يمرر `selectedLabel`؛ `SearchableSelect.jsx:88,368` لا يستهلكه وينشر `...rest` إلى MUI/DOM | يفسر تحذير React المثبت في الجولة السابقة وفي سجل Vite. التوصية إصلاح عقد الخصائص أو الاستدعاء مع الحفاظ على عرض الاختيار؛ لا يوجد دليل أنه يوقف العملية وحده. لم يُخفَ التحذير. |
| شرط إصدار | ملفات أساسية، منها ملفات الاستقرار، غير متتبعة في Git | يجب تجميد artifact كامل ومراجع يتضمن تعديلات المشروع السابقة اللازمة. لا تنشر HEAD أو patch الاستقرار وحده بافتراض احتوائه على التطبيق الحالي، ولا تستخدم `git add .` عشوائيًا مع ملفات البيئة والـscratch. |
| مانع اعتماد الحالة الأحدث | تغيرت ملفات واجهة أثناء المراجعة بعد بعض تشغيلات الاختبار | البناء الأحدث ناجح، لكن لا توجد إعادة كاملة على نسخة مجمدة تشمل تلك التغييرات. تُحفظ النتائج حسب توقيت وبصمة النسخة، لا تُقدّم كاعتماد شامل للكود المتغير. |

[إعادة إنتاج خطأي runtime](../scratch/predeploy/source-reproductions.json) تستخدم كود المكونات والخدمات نفسه، مع state وAuth/I18n fixtures معلنة، وتمنع أي HTTP. هذه إعادة إنتاج معزولة وليست ادعاء تجربة المسار كاملًا مع بيانات SAP.

عند مراجعة مسار Docker الموجود: `docker-compose.yml` و`backend/Dockerfile` يشغّلان Django بـ`runserver`، وسياق البناء هو `./backend`، ولا يوجد `backend/.dockerignore` بينما Dockerfile ينفذ `COPY . .`. لذلك تجاهل `backend/.env` الموجود في `.dockerignore` بجذر المشروع لا يحمي هذا السياق؛ ملف البيئة قد يدخل الصورة إذا بُنيت بهذه الملفات. كذلك ملف ScaleAgent خارج سياق backend ولا يوجد له mount في compose؛ يجب توفير مسار الملف المعتمد صراحة في artifact/التشغيل إذا اختير Docker. **لم تُبنَ صورة Docker أو تُختبر هذه التهيئة كنشر إنتاجي**؛ هذه ملاحظات على المسار الموجود، وليست افتراضًا أن خادم النشر يستخدمه.

## الاختبارات المنفذة ونتائجها

لا يوجد `npm test` في `frontend/package.json`، ولا runner واحد يجمع كل اختبارات المتصفح القديمة. اكتُشفت اختبارات Django في `api` و`scale`، واختبارات Node `.test.mjs` وscripts، وسكربتات متصفح مستقلة. فُصلت تلك الفئات بدل اعتبار البناء أو 75 حالة Node تغطية لكل الواجهة.

| التحقق | النتيجة الفعلية والدليل |
|---|---|
| Django: `backend/run_stability_tests.py --postgres`، مع اختبار Chrome مفعّل | **786 ناجحًا، صفر failure/error/skipped، وصفر HTTP غير متوقع**، exit 0، في 159.06 ثانية شاملة إعداد القاعدة وتنظيفها. [النتائج](../scratch/predeploy-backend-postgres.json)، [الأمر وكود الخروج](../scratch/predeploy/backend-command.json)، [السجل](../scratch/predeploy/backend.log). |
| Node: 5 ملفات `.test.mjs` و20 script معزولًا، بالتتابع | **75 حالة: 74 ناجحة وواحدة فاشلة، صفر skipped**، exit 1. [الأمر بكل الملفات](../scratch/predeploy/frontend-command.json)، [السجل](../scratch/predeploy/frontend.log). الفشل هو استيراد صفحة مراجعة التحويل المحذوفة، ولم تُلغَ assertions لتحويله إلى نجاح. |
| التوقيع والأزرار وتذكرة الميزان | **8 مجموعات ناجحة في الفاتح و8 في الداكن**، exit 0 لكل منهما؛ تشمل الاستعادة والمسح والتدوير/DPR ومقاسات اللمس ومعاينة قالب التذكرة الحقيقي ببيانات مصطنعة. [فاتح](../scratch/predeploy/signature-light/responsive-browser-regressions.json)، [داكن](../scratch/predeploy/signature-dark/responsive-browser-regressions.json). |
| طباعة المستندات | **36 PDF ناجحًا**: عروض البيع وأوامر البيع والتسليم × لغتين × 1/10/55 صفًا × طولي/عرضي A4. فُحصت الصفوف والإجماليات والمخزن وأرقام المستند المتكررة وخط Cairo داخل PDF. [النتائج](../scratch/predeploy/print/results.json)، [السجل](../scratch/predeploy/print.log). ليست تجربة طابعة فعلية. |
| تفاعلات متصفح مع APIs معزولة | **100 حالة ناجحة، صفر سيناريو فاشل**: اللغتان والوضعان، 390×320 و1440×900؛ التنقل وبطاقات مسودات الميزان وحوار أجهزته وأوامر البيع والتسليم وخطوات التحميل الأساسية ومعاينة الطباعة. [التفاصيل](../scratch/predeploy/interactions/predeploy-interactions.json). الكتابات خارج fixtures مرفوضة؛ اكتشاف الشحن له رد تجريبي فقط. |
| البناء `npm.cmd run build` | نجح، exit 0. [السجل](../scratch/predeploy/build.log). لا يحل محل أي اختبار فاشل. |
| `npm.cmd run lint` | فشل، exit 1، **88 بندًا: 76 error و12 warning**. [السجل](../scratch/predeploy/lint.log). |
| `npm.cmd run i18n:check` | فشل، exit 1، مفتاح واحد مفقود في العربية والإنجليزية. [السجل](../scratch/predeploy/i18n.log). |
| تجربة migrations والرجوع | 5 خطوات تحقق ناجحة، exit 0؛ التفاصيل في قسم migrations. |

**اختبارات المتصفح الإضافية: ثلاثة منفذة، صفر ناجح، ولا skipped.** [نتائج الخروج](../scratch/predeploy/extra-browser-results.json):

| الاختبار | التوقف الفعلي | التفسير وحدود الاستنتاج |
|---|---|---|
| `test-select-ux-browser.py:131` | يتوقع `at least 2` بينما المعروض `Search by name, description or code` | اختلاف نص مثبت. لا يثبت هذا assertion وحده أن الحد الأدنى للبحث لا يعمل؛ بقية السيناريو لم يكتمل. [السجل](../scratch/predeploy/test-select-ux-browser.py.log). |
| `test-master-search-workflow-ui.py:74` | لم يظهر `Fixture Fruit` بعد خطوة إضافة الصنف | فشل تفاعل حقيقي في الاختبار. السبب بين بيانات fixture/عقد الواجهة وسلوك اختيار الصنف **لم يُحسم** في المراجعة؛ لا يُصنف نجاحًا ولا يُرفض باعتباره قديمًا تلقائيًا. [السجل](../scratch/predeploy/test-master-search-workflow-ui.py.log). |
| `test-sales-order-independent-ui.py:81` | لم يظهر زر `Create Delivery Note in SAP` المتوقع | يحتاج مراجعة عقد سير التسليم والـfixture والوصول للإجراء. لم يُضغط زر ترحيل حقيقي ولم يحدث اتصال أعمال. [السجل](../scratch/predeploy/test-sales-order-independent-ui.py.log). |

المحاولة الأولى لهذه الثلاثة لم تصل إلى assertions بسبب عنوان محلي ثابت 5189؛ صُححت **نسخ أدوات المراجعة** إلى 5188، ثم أعيدت وظهرت الإخفاقات أعلاه. [المحاولة الأولى محفوظة](../scratch/predeploy/extra-initial/extra-browser-results.json). لم تتغير scripts الأصلية أو شروط النجاح.

الجولتان الأوليان لـDjango شغّلتا 786 اختبارًا: **785 ناجحًا واختبار متصفح واحد error**، دون skipped أو HTTP غير متوقع. لم تُهملا: [الأولى](../scratch/predeploy/backend-first.log)، [الثانية](../scratch/predeploy/backend-second.log). تشخيص المتصفح أثبت أن Vite يعيد `504 Outdated Optimize Dep` لملفات React ويترك body فارغًا؛ [الدليل](../scratch/predeploy/browser-bootstrap-diagnostic.json). أُعيد تشغيل Vite مع `--force` دون تعديل مصدر، ثم نجحت المجموعة الكاملة. لم يُعدّل اختبار الانتظار لإخفاء الخطأ، ولم يُعتبر تشغيل توقيع عالق نجاحًا.

### الاستلام والتحويل والميزان: ما الذي تغطيه النتائج؟

المجموعة النهائية تشمل 50 حالة في `api.tests` (الاستلام وGRPO وغيرها)، و41 لصرف الإنتاج، و14 للتحويل الفعلي، و5 لتزامن ترحيل التحويل و6 لتزامن إنشائه، و7 لسلامة وجهة المرحلة الثانية، و9 لـdestination bins، و15 للمرحلة الخامسة، و92 في `scale.tests` و37 للتغليف و4 لبصمة التنزيل. هذه الأعداد أجزاء من الـ786 وليست مجموعات إضافية تُجمع معها. [كل المجموعات وأعدادها](../scratch/predeploy/backend-module-counts.json).

اختبارات Node شملت GRPO navigation وخدمات صرف الإنتاج والتحويل الفيزيائي وbin ومواقع التخزين والمرحلة الخامسة ومراقب الميزان. لا تعني اختبارات الخدمة أو SSR تجربة كل خطوة لمس في معالج الاستلام، ولا يغطي نجاح تذكرة الميزان كل قوالب الطباعة الأخرى.

## ScaleAgent

أُعيد فحص الملف الموجود دون تشغيله أو استبداله أو تغيير expected hash:

```text
SHA-256: DF4A8921C03CAA8C52D4F10D50863ED5B4EA2B56DA7EC5B45DE716F2787B1163
FileVersion / ProductVersion: 1.0.1
Bytes: 20,580,447
Authenticode: NotSigned
```

يطابق pin المعتمد سابقًا من المستخدم، وتغطي اختبارات Django بصمة الملف الفعلي داخل ZIP ورفض الملف المختلف أو pin غير الصالح. [نتائج بيانات الملف](../scratch/predeploy/scaleagent.json). اعتماد البصمة ليس شهادة توقيع أو تدقيقًا أمنيًا لمحتوى executable، ولم تُجرب قراءات جهاز أو TCP/COM فعلي.

## أوامر التحقق التي شُغلت

من جذر المشروع، الأدوات التالية موجودة ضمن أدلة هذه المراجعة:

```powershell
.\.venv\Scripts\python.exe scratch/predeploy/inspect_database.py
.\.venv\Scripts\python.exe scratch/predeploy/rehearse_migrations.py
.\.venv\Scripts\python.exe scratch/predeploy/run_checks.py frontend
.\.venv\Scripts\python.exe scratch/predeploy/run_checks.py backend
```

الأداة الأخيرة تضبط قاعدة PostgreSQL اختبارية عشوائية و`QUOTATION_CURRENCY_BROWSER_URL=http://127.0.0.1:5188` وتشغّل `backend/run_stability_tests.py --postgres`. أداة Frontend تشغّل `node --test --test-concurrency=1` بالقائمة الكاملة المحفوظة في JSON، مع فصل اختبارات CDP عن Node runner. يُسجل exit code الحقيقي للـsubprocess، لا تُستنتج النتيجة من رسائل PowerShell stderr.

```powershell
cd frontend
npm.cmd run dev -- --host 127.0.0.1 --port 5188 --strictPort --force
npm.cmd run build
npm.cmd run lint
npm.cmd run i18n:check
```

بدأ Chrome مع profile جديد ومنفذ Debugging مستقل 9899، وتحققت جاهزيته من `/json/version` قبل اختبارات CDP. شُغلت نسخ مراجعة من scripts الموجودة؛ التغيير فيها محصور في **منفذ الخادم أو مسار إخراج الأدلة** دون تغيير assertions أو كود التطبيق. [بيان النسخ](../scratch/predeploy/browser-adapters.json).

```powershell
$env:AUDIT_ORIGIN='http://127.0.0.1:5188'
$env:AUDIT_CHROME_PORT='9899'
$env:AUDIT_THEME='light'
node scratch/predeploy/signature-light.mjs
$env:AUDIT_THEME='dark'
node scratch/predeploy/signature-dark.mjs
.\.venv\Scripts\python.exe scratch/predeploy/print-check.py
$env:VERIFY_ORIGIN='http://127.0.0.1:5188'
$env:VERIFY_SIZES='390x320,1440x900'
$env:VERIFY_OUTPUT='predeploy-interactions'
.\.venv\Scripts\python.exe scratch/predeploy/interactions-check.py
node scratch/predeploy/reproduce-source-findings.mjs
.\.venv\Scripts\python.exe scratch/predeploy/extra_browser_checks.py
```

## خطة نشر قابلة للرجوع — لم تُنفذ

1. **إغلاق الموانع أولًا:** إصلاح ReferenceError في شاشة التسليم، ومعالجة الدالة المعطلة واختبار التحويل القديم وفحص الترجمة وبنود lint، ثم إعادة الاختبارات المتأثرة والمجموعات العامة. توثيق أي استثناء معتمد بدل وصف فحص فاشل بأنه ناجح. معالجة `selectedLabel` مع اختبار بقاء الاختيار ظاهرًا.
2. **تجميد إصدار قابل للتكرار:** تحديد خادم وطريقة النشر ومسؤول القرار. إعداد artifact كامل ببصمة/معرّف إصدار، يشمل تعديلات المشروع السابقة المطلوبة والـmigrations والواجهة وملف ScaleAgent المعتمد. الاحتفاظ بالإصدار السابق وملف إعداداته الآمن منفصلًا. لا ترفع `.env` أو profiles أو سجلات `scratch` التي قد تحتوي بيانات اختبار إلى حزمة التشغيل.
3. **نسخة احتياطية وتجربة الاستعادة:** قبل النافذة، إعداد PostgreSQL backup معتمد، والتحقق من استعادته على قاعدة منفصلة؛ لم تُجرّب استعادة backup التشغيل في هذه المراجعة. حفظ نسخة إعدادات وملفات التشغيل اللازمة وفق سياسة المؤسسة. لا يكفي نجاح rollback لقيد تجريبي بدل تحقق الاستعادة.
4. **نافذة صيانة وموافقة صريحة:** إيقاف قبول كتابات التطبيق وكل worker يمكنه إنشاء/تغيير مسودات التسليم، وانتظار اكتمال المعاملات الجارية. إعادة فحص duplicates بالقراءة فقط على **قاعدة النشر المحددة**. إن ظهرت مجموعة مكررة، التوقف وإحالتها للمراجعة؛ لا حذف ولا تغيير حالات تلقائيًا. مراجعة `migrate --plan`، وموارد/أقفال PostgreSQL وحدود انتظار معتمدة.
5. **بعد الموافقة والإجراء المعتمد فقط:** تشغيل migrations بإصدار الكود الجديد في نافذة الصيانة؛ الأمر المخطط `python manage.py migrate api 0066_alter_transferwarehouserule_stage --noinput`. الخطة يجب أن تتضمن 0065 ثم 0066 فقط كما جرى فحصها، وإلا يُعاد تقييمها. **لم يُشغَّل هذا الأمر على التشغيل في المراجعة**.
6. **تحقق قبل فتح الكتابات:** تأكيد وجود index وشرطه وسجل migrations، ثم تشغيل artifact الجديد وإخراج فحوص قراءة للتنقل والمصادقة/الصلاحيات وقوائم التسليم والطباعة وتنزيل ZIP الميزان وبصمته. تبقى معاملات SAP الحقيقية خارج اختبار الشكل؛ أي UAT كتابة لاحق يحتاج إجراءً واعتمادًا مستقلين. فتح الخدمة تدريجيًا بعد قبول المسؤول.

### الرجوع

- عند فشل migration أو smoke test، تبقى الكتابات متوقفة. 0065 atomic: لا يُفترض تطبيقه من نجاح بدء الأمر؛ تُراجع نتيجة الأمر وسجل migrations ووجود index. لا استخدام `--fake` أو تعديل الصفوف لإجبار النجاح.
- الرجوع المفضل عند مشكلة كود فقط هو استعادة artifact السابق **مع إبقاء قيد منع التكرار إن ثبت توافق الإصدار السابق معه**. تظل الخدمة في الصيانة حتى التأكد من تعامل الإصدار السابق مع التعارضات؛ لا تُفتح الكتابات اعتمادًا على التخمين.
- إذا تقرر رجوع schema أيضًا، وبعد موافقة مستقلة ومراجعة graph الفعلي: الأمر المخطط `python manage.py migrate api 0064_quality_grade_category --noinput` يرجع 0066 ثم 0065. جُرّب ترتيب الرجوع في قاعدة الاختبار ولم يغير صفوفها، لكنه **يزيل حماية السباق**؛ لا يُعدّ إصدارًا تشغيليًا آمنًا تلقائيًا. تُراجع الحاجة لإصلاح أو استمرار الصيانة قبل فتح الكتابات.
- عند الحاجة لاستعادة backup: لا استعادة تلقائية بعد وجود عمليات تشغيل جديدة، خصوصًا إن قابلتها معاملات SAP؛ يلزم حصرها ومطابقتها واعتماد الاستعادة. لم تُنفذ restore أو rollback تشغيلي هنا.

## ما لم يُختبر صراحةً

- خادم النشر النهائي وإعداد خدمته ونسخة backup التشغيل واستعادتها، ونشر Docker أو reverse proxy/TLS أو حمل الأقفال تحت مستخدمين فعليين.
- ميزان فعلي، ملف ScaleAgent أثناء التشغيل، TCP/COM، هاند هيلد وباركود ولوحة مفاتيح وطابعة فعلية.
- كتابة مستندات أو اعتماد/ترحيل أو تغيير بيانات SAP؛ لم تُشغّل أدوات UAT الحية أو scratch scripts التي يمكن أن تنفذها.
- جميع الشاشات وكل خطوات الأعمال وكل الصلاحيات مع بيانات SAP الحقيقية. تفاعلات هذه المراجعة عينات محددة وfixtures؛ ليست إعادة لمصفوفة responsive الكاملة السابقة.
- كل قوالب استلام الإنتاج والباتشات والإيصالات والطباعة الحرارية أو مقاسات الورق؛ المنفذ هو تذكرة الميزان بالعينة و36 PDF للمستندات المذكورة.
- السكربتات القديمة `test-click-traceability.mjs` و`test-print-render.mjs` و`test_modal.mjs`: تعتمد عنوانًا/جلسة ثابتين ولا تضمن عزل الشبكة. استخدمت بدائل الطباعة والتفاعلات المعزولة دون الادعاء بتشغيل تلك الملفات.
- `test-transfer-policy-ui.py` يفترض وحدة/واجهة السياسات المحذوفة، و`test-master-search-live.py` و`test-sales-direct-pagination.py` غير معتمدة هنا كتجارب معزولة؛ لم تُشغّل. `test-master-search-backend.py` runner بديل لمجموعة فرعية مغطاة بالمجموعة النهائية، ولم يُشغّل منفصلًا. `test-sales-journey-browser.py` لم يُنفذ في هذه الجولة؛ نجاح 100 تفاعل لا يقوم مقام رحلته الكاملة.

فحص النهاية حفظ بصمات البداية والتغييرات المتزامنة وحالة Git اللاحقة؛ [دليل سلامة النطاق](../scratch/predeploy/final-integrity.json). لم يطرأ تعديل على ملفات تسليم الاستقرار الثلاثين، ولم تُحذف تعديلات موجودة. يتطلب الانتقال من هذا الحكم إلى السماح بالنشر معالجة الموانع وتجميد نسخة وإعادة فحوصها ثم موافقة النشر؛ التقرير نفسه ليس موافقة أو تنفيذًا للنشر.
